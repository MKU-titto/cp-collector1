#!/bin/bash
# ============================================================================
# Cyber Polygon — Client_Machine Agent Installer
# Installs cp-collector and all dependencies on a participant's Linux machine.
#
# Usage:
#   sudo bash install_client_machine.sh --event-id cyberpolygon-2026-spring
#
# Requirements: Debian/Ubuntu or Kali/Parrot, root privileges
# ============================================================================

set -euo pipefail

# === Colors ===
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

log_info()  { echo -e "${CYAN}[INFO]${NC}  $1"; }
log_ok()    { echo -e "${GREEN}[OK]${NC}    $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# === Banner ===
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║        Cyber Polygon — cp-collector installer       ║${NC}"
echo -e "${CYAN}║              Agent: Client_Machine                  ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""

# === Parse arguments ===
EVENT_ID=""
SKIP_BROWSER=0
SKIP_DEPS=0

while [[ $# -gt 0 ]]; do
    case $1 in
        --event-id)
            EVENT_ID="$2"
            shift 2
            ;;
        --skip-browser)
            SKIP_BROWSER=1
            shift
            ;;
        --skip-deps)
            SKIP_DEPS=1
            shift
            ;;
        -h|--help)
            echo "Usage: sudo bash $0 --event-id <event_id> [--skip-browser] [--skip-deps]"
            echo ""
            echo "Options:"
            echo "  --event-id      (Required) CTF event identifier"
            echo "  --skip-browser  Skip mitmproxy installation (no browser capture)"
            echo "  --skip-deps     Skip dependency installation"
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# === Validate ===
if [[ -z "$EVENT_ID" ]]; then
    log_error "Missing required parameter: --event-id"
    echo "Usage: sudo bash $0 --event-id cyberpolygon-2026-spring"
    exit 1
fi

if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (sudo)"
    exit 1
fi

log_info "Event ID: $EVENT_ID"

# ============================================================================
# Step 1: Create 'iron' user
# ============================================================================
log_info "Step 1/11: Creating user 'iron'..."

if id "iron" &>/dev/null; then
    log_warn "User 'iron' already exists, skipping creation"
else
    useradd -m -s /bin/bash -r iron
    passwd -l iron  # Lock password login
    log_ok "User 'iron' created (password login locked)"
fi

# ============================================================================
# Step 2: Isolate home directory
# ============================================================================
log_info "Step 2/11: Setting directory permissions..."

chmod 700 /home/iron
chown iron:iron /home/iron
log_ok "Directory /home/iron secured (700)"

# ============================================================================
# Step 3: Create directory structure
# ============================================================================
log_info "Step 3/11: Creating directory structure..."

mkdir -p /home/iron/logs
mkdir -p /home/iron/exports
mkdir -p /home/iron/files
chown -R iron:iron /home/iron
log_ok "Directories created: logs/, exports/, files/"

# ============================================================================
# Step 4: Generate identifiers
# ============================================================================
log_info "Step 4/11: Generating identifiers..."

# machine_id: hostname + sha256(MAC)[:8]
HOSTNAME_VAL=$(hostname)
MAC_ADDR=$(cat /sys/class/net/eth0/address 2>/dev/null || \
           ip link show eth0 2>/dev/null | awk '/ether/ {print $2}' || \
           cat /sys/class/net/$(ls /sys/class/net/ | grep -v lo | head -1)/address 2>/dev/null || \
           echo "00:00:00:00:00:00")
MAC_HASH=$(echo -n "$MAC_ADDR" | sha256sum | cut -c1-8)
MACHINE_ID="${HOSTNAME_VAL}_${MAC_HASH}"

# player_id: UUID
if command -v uuidgen &>/dev/null; then
    PLAYER_ID=$(uuidgen)
elif [[ -f /proc/sys/kernel/random/uuid ]]; then
    PLAYER_ID=$(cat /proc/sys/kernel/random/uuid)
else
    PLAYER_ID=$(python3 -c "import uuid; print(uuid.uuid4())" 2>/dev/null || echo "unknown-$(date +%s)")
fi

log_ok "machine_id: ${MACHINE_ID}"
log_ok "player_id:  ${PLAYER_ID}"

# ============================================================================
# Step 5: Install dependencies
# ============================================================================
if [[ $SKIP_DEPS -eq 0 ]]; then
    log_info "Step 5/11: Installing dependencies..."

    export DEBIAN_FRONTEND=noninteractive

    apt-get update -qq

    # Core dependencies
    PACKAGES=(
        libpcap-dev          # Network capture
        socat                # UNIX socket communication for shell hooks
        auditd               # Process audit (optional)
        libbpf-dev           # eBPF headers (bpf_helpers.h, bpf_tracing.h)
        bpfcc-tools          # eBPF utilities
        linux-headers-$(uname -r)  # Kernel headers for eBPF
    )

    # mitmproxy for browser capture
    if [[ $SKIP_BROWSER -eq 0 ]]; then
        PACKAGES+=(
            python3
            python3-pip
        )
    fi

    apt-get install -y -qq "${PACKAGES[@]}" 2>/dev/null || {
        log_warn "Some packages failed to install, attempting individually..."
        for pkg in "${PACKAGES[@]}"; do
            apt-get install -y -qq "$pkg" 2>/dev/null || log_warn "Failed: $pkg (non-critical)"
        done
    }

    # Install mitmproxy via pip
    if [[ $SKIP_BROWSER -eq 0 ]]; then
        pip3 install mitmproxy 2>/dev/null || {
            log_warn "mitmproxy pip install failed, trying pipx..."
            apt-get install -y -qq pipx 2>/dev/null && pipx install mitmproxy 2>/dev/null || {
                log_warn "mitmproxy installation failed — browser-watcher will be disabled"
                SKIP_BROWSER=1
            }
        }
    fi

    log_ok "Dependencies installed"
else
    log_warn "Step 5/11: Skipping dependency installation (--skip-deps)"
fi

# ============================================================================
# Step 6: Copy binaries
# ============================================================================
log_info "Step 6/11: Installing cp-collector binary..."

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BIN_SRC="${SCRIPT_DIR}/../bin/cp-collector"
EBPF_SRC="${SCRIPT_DIR}/../ebpf"

if [[ -f "$BIN_SRC" ]]; then
    install -m 755 "$BIN_SRC" /usr/local/bin/cp-collector
    log_ok "Binary installed: /usr/local/bin/cp-collector"
else
    log_warn "Binary not found at $BIN_SRC"
    log_warn "Build first with: make build"
    log_warn "Looking for pre-installed binary..."
    if ! command -v cp-collector &>/dev/null; then
        log_error "cp-collector binary not found. Build the project first."
        exit 1
    fi
fi

# Install eBPF objects
mkdir -p /usr/local/share/cp-collector/ebpf
if [[ -d "$EBPF_SRC" ]]; then
    find "$EBPF_SRC" -name "*.o" -exec cp {} /usr/local/share/cp-collector/ebpf/ \;
    log_ok "eBPF objects installed"
else
    log_warn "eBPF objects not found, some features may not work"
fi

# ============================================================================
# Step 7: Write config
# ============================================================================
log_info "Step 7/11: Writing configuration..."

BROWSER_ENABLED="true"
if [[ $SKIP_BROWSER -eq 1 ]]; then
    BROWSER_ENABLED="false"
fi

cat > /home/iron/config.yaml << ENDCONFIG
# Cyber Polygon cp-collector — auto-generated config
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# DO NOT EDIT MANUALLY during active CTF event

agent:
  type: "client_machine"
  version: "1.0"
  ctf_event_id: "${EVENT_ID}"
  machine_id: "${MACHINE_ID}"
  player_id: "${PLAYER_ID}"

storage:
  base_path: "/home/iron/logs"
  files_path: "/home/iron/files"
  max_size_gb: 10
  compression: true
  rotate_size_mb: 100
  flush_interval_ms: 1000

export:
  output_path: "/home/iron/exports"
  auto_export_on_stop: true
  encrypt: false

shell:
  enabled: true
  max_stdout_bytes: 65536
  max_stderr_bytes: 65536

net:
  enabled: true
  interfaces:
    - "eth0"
  capture_dns: true

browser:
  enabled: ${BROWSER_ENABLED}
  mitmproxy_port: 8080
  max_body_preview_bytes: 4096
  output_socket_path: "/home/iron/mitmproxy.sock"

fs:
  enabled: true
  watch_paths:
    - "/home"
    - "/tmp"
    - "/var/tmp"
    - "/opt"
  exclude_paths:
    - "/home/iron"
  max_preview_size_bytes: 2048
  copy_files: true

proc:
  enabled: true
  use_auditd: false
  poll_interval_ms: 500
ENDCONFIG

chown iron:iron /home/iron/config.yaml
chmod 600 /home/iron/config.yaml
log_ok "Config written: /home/iron/config.yaml"

# ============================================================================
# Step 8: Register systemd service
# ============================================================================
log_info "Step 8/11: Registering systemd service..."

SYSTEMD_SRC="${SCRIPT_DIR}/../systemd/cp-collector.service"
if [[ -f "$SYSTEMD_SRC" ]]; then
    cp "$SYSTEMD_SRC" /etc/systemd/system/cp-collector.service
else
    # Generate inline
    cat > /etc/systemd/system/cp-collector.service << 'ENDSERVICE'
[Unit]
Description=Cyber Polygon CTF Data Collector
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/cp-collector -config /home/iron/config.yaml
ExecStopPost=/usr/local/bin/cp-collector -config /home/iron/config.yaml -export
Restart=on-failure
RestartSec=5
CPUQuota=5%
MemoryMax=256M
StandardOutput=journal
StandardError=journal
SyslogIdentifier=cp-collector

[Install]
WantedBy=multi-user.target
ENDSERVICE
fi

systemctl daemon-reload
systemctl enable cp-collector.service
log_ok "Service registered and enabled"

# ============================================================================
# Step 9: Setup mitmproxy CA + iptables (browser-watcher)
# ============================================================================
if [[ $SKIP_BROWSER -eq 0 ]]; then
    log_info "Step 9/11: Configuring mitmproxy transparent proxy..."

    # Generate mitmproxy CA cert (run once to create ~/.mitmproxy/)
    timeout 5 mitmdump --mode transparent -p 18080 &>/dev/null &
    MITM_PID=$!
    sleep 2
    kill $MITM_PID 2>/dev/null || true
    wait $MITM_PID 2>/dev/null || true

    # Install CA certificate system-wide
    MITM_CERT="/root/.mitmproxy/mitmproxy-ca-cert.pem"
    if [[ -f "$MITM_CERT" ]]; then
        cp "$MITM_CERT" /usr/local/share/ca-certificates/mitmproxy-ca.crt
        update-ca-certificates 2>/dev/null || true

        # Install for Firefox (NSS)
        if command -v certutil &>/dev/null; then
            for profile in /home/*/.mozilla/firefox/*.default*; do
                if [[ -d "$profile" ]]; then
                    certutil -A -n "mitmproxy" -t "C,," -i "$MITM_CERT" -d "sql:$profile" 2>/dev/null || true
                fi
            done
        fi

        log_ok "mitmproxy CA certificate installed"
    else
        log_warn "mitmproxy CA cert not generated"
    fi

    # Setup iptables redirect for transparent proxy
    MITM_PORT=8080

    # Save current rules first
    iptables-save > /home/iron/iptables-backup.rules 2>/dev/null || true

    # Redirect HTTP/HTTPS to mitmproxy
    iptables -t nat -A OUTPUT -p tcp --dport 80 -m owner ! --uid-owner iron -j REDIRECT --to-port $MITM_PORT 2>/dev/null || true
    iptables -t nat -A OUTPUT -p tcp --dport 443 -m owner ! --uid-owner iron -j REDIRECT --to-port $MITM_PORT 2>/dev/null || true

    # Don't intercept iron's own traffic (avoid loops)
    iptables -t nat -I OUTPUT -m owner --uid-owner iron -j RETURN 2>/dev/null || true

    log_ok "iptables transparent proxy rules added (port 80,443 → $MITM_PORT)"
else
    log_warn "Step 9/11: Browser capture skipped"
fi

# ============================================================================
# Step 10: Install shell hooks
# ============================================================================
log_info "Step 10/11: Installing shell hooks..."

HOOKS_SRC="${SCRIPT_DIR}/hooks"

# Bash hook
if [[ -f "${HOOKS_SRC}/cp-collector-bash-hook.sh" ]]; then
    cp "${HOOKS_SRC}/cp-collector-bash-hook.sh" /etc/profile.d/cp-collector-hook.sh
else
    log_warn "Bash hook not found, generating inline..."
    # The hook will be generated from the repo source
fi
chmod 644 /etc/profile.d/cp-collector-hook.sh 2>/dev/null || true

# Zsh hook
if [[ -f "${HOOKS_SRC}/cp-collector-zsh-hook.zsh" ]]; then
    mkdir -p /etc/zsh/zshrc.d 2>/dev/null || true
    cp "${HOOKS_SRC}/cp-collector-zsh-hook.zsh" /etc/zsh/zshrc.d/cp-collector-hook.zsh 2>/dev/null || true
    # Also add to /etc/zshrc as fallback
    if [[ -f /etc/zsh/zshrc ]] && ! grep -q "cp-collector-hook" /etc/zsh/zshrc 2>/dev/null; then
        echo "" >> /etc/zsh/zshrc
        echo "# Cyber Polygon cp-collector hook" >> /etc/zsh/zshrc
        echo '[[ -f /etc/zsh/zshrc.d/cp-collector-hook.zsh ]] && source /etc/zsh/zshrc.d/cp-collector-hook.zsh' >> /etc/zsh/zshrc
    fi
fi

log_ok "Shell hooks installed"

# ============================================================================
# Step 11: Start service and verify
# ============================================================================
log_info "Step 11/11: Starting cp-collector..."

systemctl start cp-collector.service

# Wait a moment for startup
sleep 2

# Check status
if systemctl is-active --quiet cp-collector.service; then
    log_ok "cp-collector is running"
else
    log_error "cp-collector failed to start!"
    echo ""
    echo "Check logs with: journalctl -u cp-collector -n 50"
    exit 1
fi

# Verify socket exists (shell-watcher)
if [[ -S /home/iron/shell_watcher.sock ]]; then
    log_ok "Shell watcher socket active"
else
    log_warn "Shell watcher socket not yet available (may take a moment)"
fi

# ============================================================================
# Summary
# ============================================================================
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║          Installation complete!                     ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Event ID:    ${CYAN}${EVENT_ID}${NC}"
echo -e "  Machine ID:  ${CYAN}${MACHINE_ID}${NC}"
echo -e "  Player ID:   ${CYAN}${PLAYER_ID}${NC}"
echo ""
echo -e "  Config:      /home/iron/config.yaml"
echo -e "  Logs:        /home/iron/logs/"
echo -e "  Exports:     /home/iron/exports/"
echo ""
echo -e "  ${YELLOW}Commands:${NC}"
echo -e "    Status:    systemctl status cp-collector"
echo -e "    Logs:      journalctl -u cp-collector -f"
echo -e "    Export:    cp-collector -config /home/iron/config.yaml -export"
echo -e "    Stop:      systemctl stop cp-collector"
echo ""
echo -e "  ${YELLOW}⚠ Provide machine_id and player_id to the event organizer${NC}"
echo ""
