// SPDX-License-Identifier: GPL-2.0
// Cyber Polygon — cp-collector interactive-watcher eBPF program
//
// Hooks sys_read to capture stdin (fd=0) for target PIDs.
// Target PIDs are managed from userspace via the target_pids BPF map.

//go:build ignore

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

#define MAX_DATA_LEN 4096
#define MAX_PIDS 256

// Event structure sent to userspace via ring buffer
struct event {
    __u32 pid;
    __u32 tid;
    __u32 fd;
    __s64 ret;
    __u64 timestamp_ns;
    __u32 data_len;
    char comm[16];
    char data[MAX_DATA_LEN];
};

// Map: set of PIDs to monitor (key=pid, value=1 if active)
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, MAX_PIDS);
    __type(key, __u32);
    __type(value, __u8);
} target_pids SEC(".maps");

// Ring buffer for events
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024); // 256KB ring buffer
} events SEC(".maps");

// Temp storage for read args (fd, buf) between enter and exit
struct read_args {
    __u32 fd;
    char *buf;
};

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 4096);
    __type(key, __u64); // tid
    __type(value, struct read_args);
} active_reads SEC(".maps");

// --- sys_enter_read: capture args ---
SEC("tracepoint/syscalls/sys_enter_read")
int tracepoint__sys_enter_read(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;

    // Check if this PID is in our target set
    __u8 *val = bpf_map_lookup_elem(&target_pids, &pid);
    if (!val)
        return 0;

    // Only capture stdin (fd == 0)
    int fd = (int)ctx->args[0];
    if (fd != 0)
        return 0;

    // Save args for sys_exit_read
    __u64 tid = bpf_get_current_pid_tgid();
    struct read_args args = {
        .fd = fd,
        .buf = (char *)ctx->args[1],
    };
    bpf_map_update_elem(&active_reads, &tid, &args, BPF_ANY);

    return 0;
}

// --- sys_exit_read: capture data ---
SEC("tracepoint/syscalls/sys_exit_read")
int tracepoint__sys_exit_read(struct trace_event_raw_sys_exit *ctx)
{
    __u64 tid = bpf_get_current_pid_tgid();
    __u32 pid = tid >> 32;

    struct read_args *args = bpf_map_lookup_elem(&active_reads, &tid);
    if (!args)
        return 0;

    // Cleanup the saved args
    bpf_map_delete_elem(&active_reads, &tid);

    __s64 ret = ctx->ret;
    if (ret <= 0)
        return 0;

    // Allocate ring buffer event
    struct event *e = bpf_ringbuf_reserve(&events, sizeof(struct event), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->tid = (__u32)tid;
    e->fd = args->fd;
    e->ret = ret;
    e->timestamp_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&e->comm, sizeof(e->comm));

    // Read the data from user buffer
    __u32 read_len = (__u32)ret;
    if (read_len > MAX_DATA_LEN)
        read_len = MAX_DATA_LEN;
    e->data_len = read_len;

    if (bpf_probe_read_user(e->data, read_len, args->buf) < 0) {
        bpf_ringbuf_discard(e, 0);
        return 0;
    }

    bpf_ringbuf_submit(e, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
