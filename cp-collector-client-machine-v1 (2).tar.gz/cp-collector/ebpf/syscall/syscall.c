// SPDX-License-Identifier: GPL-2.0
// Cyber Polygon — cp-collector syscall monitor eBPF program
//
// Hooks target syscalls and sends events to userspace via ring buffer.
// Filters out kernel threads and the iron user's own processes.

//go:build ignore

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

#define IRON_UID 1001  // UID of the iron user — set during build

struct syscall_event {
    __u32 pid;
    __u32 tid;
    __u32 syscall_nr;
    __s64 ret_val;
    __u64 timestamp_ns;
    char comm[16];
    __u64 arg0;
    __u64 arg1;
    __u64 arg2;
};

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 512 * 1024); // 512KB
} syscall_events SEC(".maps");

// Rate limiting: skip events if ring buffer is >75% full
// This prevents CPU stalls when syscalls are very frequent

static __always_inline int emit_event(__u32 syscall_nr, __u64 a0, __u64 a1, __u64 a2)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 tid = (__u32)bpf_get_current_pid_tgid();

    // Skip kernel threads (pid 0)
    if (pid == 0)
        return 0;

    // Skip iron user processes
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    if (uid == IRON_UID)
        return 0;

    struct syscall_event *e = bpf_ringbuf_reserve(&syscall_events, sizeof(*e), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->tid = tid;
    e->syscall_nr = syscall_nr;
    e->ret_val = 0; // Set on exit tracepoint
    e->timestamp_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&e->comm, sizeof(e->comm));
    e->arg0 = a0;
    e->arg1 = a1;
    e->arg2 = a2;

    bpf_ringbuf_submit(e, 0);
    return 0;
}

// --- Tracepoint handlers for each target syscall ---

SEC("tracepoint/syscalls/sys_enter_connect")
int tracepoint__syscalls__sys_enter_connect(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(42, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_bind")
int tracepoint__syscalls__sys_enter_bind(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(49, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_execve")
int tracepoint__syscalls__sys_enter_execve(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(59, ctx->args[0], ctx->args[1], 0);
}

SEC("tracepoint/syscalls/sys_enter_openat")
int tracepoint__syscalls__sys_enter_openat(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(257, ctx->args[1], ctx->args[2], 0);
}

SEC("tracepoint/syscalls/sys_enter_mmap")
int tracepoint__syscalls__sys_enter_mmap(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(9, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_mprotect")
int tracepoint__syscalls__sys_enter_mprotect(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(10, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_ptrace")
int tracepoint__syscalls__sys_enter_ptrace(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(101, ctx->args[0], ctx->args[1], 0);
}

SEC("tracepoint/syscalls/sys_enter_setuid")
int tracepoint__syscalls__sys_enter_setuid(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(105, ctx->args[0], 0, 0);
}

SEC("tracepoint/syscalls/sys_enter_fork")
int tracepoint__syscalls__sys_enter_fork(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(57, 0, 0, 0);
}

SEC("tracepoint/syscalls/sys_enter_clone")
int tracepoint__syscalls__sys_enter_clone(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(56, ctx->args[0], 0, 0);
}

char LICENSE[] SEC("license") = "GPL";
