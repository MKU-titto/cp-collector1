# cp-collector — Cyber Polygon CTF Behavioral Data Collector

**Agent: `Client_Machine`** — повний запис поведінки учасника CTF для навчання AI-агента.

## Архітектура

```
┌─────────────────────────────────────────────────┐
│                 cp-collector daemon              │
│                                                  │
│  ┌──────────────┐  ┌───────────────────────┐    │
│  │ shell-watcher │  │ interactive-watcher   │    │
│  │ (UNIX socket) │  │ (eBPF read syscall)   │    │
│  └──────┬───────┘  └──────────┬────────────┘    │
│         │                      │                 │
│  ┌──────┴───────┐  ┌──────────┴────────────┐    │
│  │ proc-monitor │  │ net-sniffer           │    │
│  │ (/proc poll) │  │ (libpcap)             │    │
│  └──────┬───────┘  └──────────┬────────────┘    │
│         │                      │                 │
│  ┌──────┴───────┐  ┌──────────┴────────────┐    │
│  │ fs-monitor   │  │ browser-watcher       │    │
│  │ (inotify)    │  │ (mitmproxy)           │    │
│  └──────┬───────┘  └──────────┬────────────┘    │
│         │                      │                 │
│  ┌──────┴───────┐  ┌──────────┴────────────┐    │
│  │ syscall-mon  │  │                        │    │
│  │ (eBPF)       │  │                        │    │
│  └──────┬───────┘  └──────────┬────────────┘    │
│         │                      │                 │
│         └──────────┬───────────┘                 │
│                    ▼                             │
│           ┌────────────────┐                     │
│           │  Event         │                     │
│           │  Aggregator    │                     │
│           └───────┬────────┘                     │
│                   ▼                              │
│           ┌────────────────┐                     │
│           │  JSONL Storage │ (.cplog.gz)         │
│           └───────┬────────┘                     │
│                   ▼                              │
│           ┌────────────────┐                     │
│           │  Exporter      │ (.tar.gz archive)   │
│           └────────────────┘                     │
└─────────────────────────────────────────────────┘
```

## Вимоги

- **ОС:** Linux (Debian/Ubuntu/Kali/Parrot)
- **Ядро:** >= 5.8 (для eBPF ring buffer)
- **Залежності:** libpcap, socat, bpfcc-tools, kernel headers
- **Опціонально:** mitmproxy (для browser-watcher), auditd

## Швидкий старт

### 1. Збірка

```bash
# Встановити Go >= 1.22, clang, bpftool
make all
```

### 2. Розгортання на машині учасника

```bash
sudo bash scripts/install_client_machine.sh --event-id cyberpolygon-2026-spring
```

Скрипт автоматично:
- Створить користувача `iron`
- Згенерує `machine_id` та `player_id`
- Встановить залежності
- Налаштує mitmproxy CA + iptables
- Встановить shell hooks (bash/zsh)
- Запустить systemd сервіс

### 3. Перевірка

```bash
systemctl status cp-collector
journalctl -u cp-collector -f
ls -la /home/iron/logs/
```

### 4. Експорт після події

```bash
# Автоматичний (при зупинці сервісу):
systemctl stop cp-collector

# Ручний:
cp-collector -config /home/iron/config.yaml -export
ls -la /home/iron/exports/
```

## Структура проекту

```
cp-collector/
├── cmd/cp-collector/       # Main entry point
│   └── main.go
├── internal/
│   ├── config/             # YAML config loader
│   ├── types/              # Event JSON types + CTF tool map
│   ├── watchers/           # All 7 watcher modules
│   │   ├── shell.go        # shell-watcher (UNIX socket ← bash/zsh hooks)
│   │   ├── interactive.go  # interactive-watcher (eBPF stdin capture)
│   │   ├── process.go      # proc-monitor (/proc + auditd)
│   │   ├── network.go      # net-sniffer (libpcap)
│   │   ├── browser.go      # browser-watcher (mitmproxy manager)
│   │   ├── filesystem.go   # fs-monitor (inotify)
│   │   └── syscall.go      # syscall-monitor (eBPF tracepoints)
│   ├── aggregator/         # Watcher lifecycle manager
│   ├── storage/            # JSONL writer (buffered, gzip, rotation)
│   └── exporter/           # tar.gz archive builder
├── ebpf/
│   ├── interactive/        # eBPF C: stdin read hook
│   └── syscall/            # eBPF C: syscall tracepoints
├── scripts/
│   ├── hooks/              # Bash/Zsh preexec hooks
│   └── install_client_machine.sh
├── configs/                # Config templates
├── systemd/                # Systemd unit files
├── Makefile
└── go.mod
```

## Формат подій

Всі події зберігаються у JSONL (один JSON-об'єкт на рядок):

| Тип | Поле `type` | Джерело |
|-----|-------------|---------|
| Термінальна команда | `shell_command` | shell-watcher |
| REPL введення | `interactive_input` | interactive-watcher |
| Запуск процесу | `process_spawn` | proc-monitor |
| Завершення процесу | `process_exit` | proc-monitor |
| Мережеве з'єднання | `network_connection` | net-sniffer |
| DNS запит | `dns_query` | net-sniffer |
| HTTP запит (браузер) | `browser_request` | browser-watcher |
| Файлова операція | `fs_event` | fs-monitor |
| Системний виклик | `syscall` | syscall-monitor |

## Ліміти ресурсів

| Параметр | Ліміт |
|----------|-------|
| CPU | < 5% |
| RAM | < 256 MB |
| Диск/годину | < 100 MB |
| Ротація лог-файлу | 100 MB |
| Макс. загальний розмір | 10 GB |

---

*Cyber Polygon — CTF Behavioral Data Collection Infrastructure*
