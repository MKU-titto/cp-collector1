package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/aggregator"
	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/exporter"
	"github.com/cyber-polygon/cp-collector/internal/storage"
)

var (
	version   = "1.0.0"
	buildTime = "unknown"
)

func main() {
	// --- CLI flags ---
	configPath := flag.String("config", "/home/iron/config.yaml", "Path to config file")
	doExport := flag.Bool("export", false, "Export collected data and exit")
	showVersion := flag.Bool("version", false, "Show version and exit")
	flag.Parse()

	if *showVersion {
		fmt.Printf("cp-collector %s (built %s)\n", version, buildTime)
		os.Exit(0)
	}

	// --- Setup logging ---
	log.SetPrefix("[cp-collector] ")
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds)

	log.Printf("cp-collector %s starting", version)

	// --- Load config ---
	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	log.Printf("agent: type=%s event=%s machine=%s player=%s",
		cfg.Agent.Type, cfg.Agent.CTFEventID, cfg.Agent.MachineID, cfg.Agent.PlayerID)

	// --- Export mode ---
	if *doExport {
		archivePath, err := exporter.Export(*cfg)
		if err != nil {
			log.Fatalf("export failed: %v", err)
		}
		fmt.Printf("Export complete: %s\n", archivePath)
		os.Exit(0)
	}

	// --- Create storage writer ---
	writer, err := storage.NewWriter(cfg.Agent, cfg.Storage)
	if err != nil {
		log.Fatalf("create storage writer: %v", err)
	}
	defer writer.Close()

	log.Printf("storage: path=%s max=%dGB compression=%v",
		cfg.Storage.BasePath, cfg.Storage.MaxSizeGB, cfg.Storage.Compression)

	// --- Write startup event ---
	startupEvent := map[string]interface{}{
		"type":         "agent_start",
		"timestamp":    time.Now().UTC().Format(time.RFC3339Nano),
		"machine_id":   cfg.Agent.MachineID,
		"player_id":    cfg.Agent.PlayerID,
		"ctf_event_id": cfg.Agent.CTFEventID,
		"agent_type":   cfg.Agent.Type,
		"version":      version,
	}
	writer.Write(startupEvent)

	// --- Create aggregator and start watchers ---
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	agg := aggregator.New(*cfg, writer)
	log.Printf("watchers registered: %v", agg.WatcherNames())

	// --- Signal handling ---
	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	// Start watchers in background
	errCh := make(chan error, 1)
	go func() {
		errCh <- agg.Start(ctx)
	}()

	// Wait for signal or error
	select {
	case sig := <-sigCh:
		log.Printf("received signal: %v, shutting down...", sig)
		cancel()

	case err := <-errCh:
		if err != nil {
			log.Printf("aggregator error: %v", err)
		}
	}

	// --- Write shutdown event ---
	shutdownEvent := map[string]interface{}{
		"type":         "agent_stop",
		"timestamp":    time.Now().UTC().Format(time.RFC3339Nano),
		"machine_id":   cfg.Agent.MachineID,
		"ctf_event_id": cfg.Agent.CTFEventID,
	}
	writer.Write(shutdownEvent)

	// --- Flush and close ---
	writer.Close()
	log.Printf("storage flushed: %s", writer.CurrentPath())

	// --- Auto-export if configured ---
	if cfg.Export.AutoExportOnStop {
		log.Printf("auto-exporting collected data...")
		archivePath, err := exporter.Export(*cfg)
		if err != nil {
			log.Printf("auto-export failed: %v", err)
		} else {
			log.Printf("auto-export complete: %s", archivePath)
		}
	}

	log.Printf("cp-collector stopped")
}
