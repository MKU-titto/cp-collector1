package storage

import (
	"bufio"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/config"
)

// Writer handles JSONL log output with rotation, buffering, and optional gzip.
type Writer struct {
	mu sync.Mutex

	cfg       config.StorageConfig
	agentCfg  config.AgentConfig

	file       *os.File
	gzWriter   *gzip.Writer
	bufWriter  *bufio.Writer
	currentPath string
	bytesWritten int64

	flushTicker *time.Ticker
	done        chan struct{}
}

// NewWriter creates a new JSONL storage writer.
func NewWriter(agentCfg config.AgentConfig, storageCfg config.StorageConfig) (*Writer, error) {
	if err := os.MkdirAll(storageCfg.BasePath, 0700); err != nil {
		return nil, fmt.Errorf("create log dir: %w", err)
	}

	w := &Writer{
		cfg:      storageCfg,
		agentCfg: agentCfg,
		done:     make(chan struct{}),
	}

	if err := w.rotate(); err != nil {
		return nil, err
	}

	// Periodic flush
	w.flushTicker = time.NewTicker(time.Duration(storageCfg.FlushInterval) * time.Millisecond)
	go w.flushLoop()

	return w, nil
}

// Write serializes an event to JSONL and writes it.
func (w *Writer) Write(event interface{}) error {
	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("marshal event: %w", err)
	}
	data = append(data, '\n')

	w.mu.Lock()
	defer w.mu.Unlock()

	// Check rotation
	maxBytes := int64(w.cfg.RotateSizeMB) * 1024 * 1024
	if w.bytesWritten+int64(len(data)) > maxBytes {
		if err := w.rotateLocked(); err != nil {
			return fmt.Errorf("rotate: %w", err)
		}
	}

	// Check total disk usage limit
	if err := w.checkDiskLimit(); err != nil {
		return err
	}

	n, err := w.bufWriter.Write(data)
	if err != nil {
		return fmt.Errorf("write event: %w", err)
	}
	w.bytesWritten += int64(n)

	return nil
}

// Close flushes buffers and closes the file.
func (w *Writer) Close() error {
	close(w.done)
	w.flushTicker.Stop()

	w.mu.Lock()
	defer w.mu.Unlock()

	return w.closeCurrentFile()
}

// Flush forces a flush of the write buffer.
func (w *Writer) Flush() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.flushLocked()
}

// CurrentPath returns the path of the current log file.
func (w *Writer) CurrentPath() string {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.currentPath
}

func (w *Writer) rotate() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.rotateLocked()
}

func (w *Writer) rotateLocked() error {
	if w.file != nil {
		if err := w.closeCurrentFile(); err != nil {
			log.Printf("[storage] warning: close previous file: %v", err)
		}
	}

	now := time.Now().UTC()
	filename := fmt.Sprintf("%s_%s_%s.cplog",
		w.agentCfg.CTFEventID,
		w.agentCfg.MachineID,
		now.Format("20060102_150405"),
	)
	if w.cfg.Compression {
		filename += ".gz"
	}

	path := filepath.Join(w.cfg.BasePath, filename)

	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return fmt.Errorf("open log file %s: %w", path, err)
	}

	w.file = f
	w.currentPath = path
	w.bytesWritten = 0

	if w.cfg.Compression {
		w.gzWriter = gzip.NewWriter(f)
		w.bufWriter = bufio.NewWriterSize(w.gzWriter, 64*1024) // 64KB buffer
	} else {
		w.gzWriter = nil
		w.bufWriter = bufio.NewWriterSize(f, 64*1024)
	}

	log.Printf("[storage] opened log file: %s", path)
	return nil
}

func (w *Writer) closeCurrentFile() error {
	if w.bufWriter != nil {
		if err := w.bufWriter.Flush(); err != nil {
			return err
		}
	}
	if w.gzWriter != nil {
		if err := w.gzWriter.Close(); err != nil {
			return err
		}
	}
	if w.file != nil {
		return w.file.Close()
	}
	return nil
}

func (w *Writer) flushLocked() error {
	if w.bufWriter != nil {
		if err := w.bufWriter.Flush(); err != nil {
			return err
		}
	}
	if w.gzWriter != nil {
		if err := w.gzWriter.Flush(); err != nil {
			return err
		}
	}
	if w.file != nil {
		return w.file.Sync()
	}
	return nil
}

func (w *Writer) flushLoop() {
	for {
		select {
		case <-w.flushTicker.C:
			if err := w.Flush(); err != nil {
				log.Printf("[storage] flush error: %v", err)
			}
		case <-w.done:
			return
		}
	}
}

// checkDiskLimit verifies total disk usage doesn't exceed MaxSizeGB.
func (w *Writer) checkDiskLimit() error {
	maxBytes := int64(w.cfg.MaxSizeGB) * 1024 * 1024 * 1024

	var totalSize int64
	entries, err := os.ReadDir(w.cfg.BasePath)
	if err != nil {
		return nil // non-fatal
	}
	for _, e := range entries {
		info, err := e.Info()
		if err != nil {
			continue
		}
		totalSize += info.Size()
	}

	if totalSize >= maxBytes {
		return fmt.Errorf("disk limit reached: %d bytes >= %d GB limit", totalSize, w.cfg.MaxSizeGB)
	}
	return nil
}
