package exporter

import (
	"archive/tar"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/config"
)

// Manifest describes the contents of an export archive.
type Manifest struct {
	AgentType  string    `json:"agent_type"`
	Version    string    `json:"version"`
	CTFEventID string    `json:"ctf_event_id"`
	MachineID  string    `json:"machine_id"`
	PlayerID   string    `json:"player_id,omitempty"`
	ExportedAt string    `json:"exported_at"`
	LogFiles   []string  `json:"log_files"`
	CopiedFiles []string `json:"copied_files"`
	TotalEvents int64    `json:"total_events_approx"`
}

// Export creates a .tar.gz archive of all collected data.
func Export(cfg config.Config) (string, error) {
	timestamp := time.Now().UTC().Format("20060102_150405")
	archiveName := fmt.Sprintf("%s_%s_%s.tar.gz",
		cfg.Agent.Type,
		cfg.Agent.CTFEventID,
		timestamp,
	)
	archivePath := filepath.Join(cfg.Export.OutputPath, archiveName)

	// Ensure output directory exists
	os.MkdirAll(cfg.Export.OutputPath, 0700)

	// Create archive
	outFile, err := os.Create(archivePath)
	if err != nil {
		return "", fmt.Errorf("create archive: %w", err)
	}
	defer outFile.Close()

	gzWriter := gzip.NewWriter(outFile)
	defer gzWriter.Close()

	tarWriter := tar.NewWriter(gzWriter)
	defer tarWriter.Close()

	manifest := Manifest{
		AgentType:  cfg.Agent.Type,
		Version:    cfg.Agent.Version,
		CTFEventID: cfg.Agent.CTFEventID,
		MachineID:  cfg.Agent.MachineID,
		PlayerID:   cfg.Agent.PlayerID,
		ExportedAt: time.Now().UTC().Format(time.RFC3339),
	}

	// Add log files
	logFiles, err := filepath.Glob(filepath.Join(cfg.Storage.BasePath, "*.cplog*"))
	if err == nil {
		for _, lf := range logFiles {
			if err := addFileToTar(tarWriter, lf, "logs/"+filepath.Base(lf)); err != nil {
				log.Printf("[exporter] add log %s: %v", lf, err)
				continue
			}
			manifest.LogFiles = append(manifest.LogFiles, filepath.Base(lf))
			// Count approximate events (lines in file)
			manifest.TotalEvents += countLines(lf)
		}
	}

	// Add copied files
	if _, err := os.Stat(cfg.Storage.FilesPath); err == nil {
		filepath.Walk(cfg.Storage.FilesPath, func(path string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() {
				return nil
			}
			relPath, _ := filepath.Rel(cfg.Storage.FilesPath, path)
			tarPath := "files/" + relPath
			if err := addFileToTar(tarWriter, path, tarPath); err != nil {
				log.Printf("[exporter] add file %s: %v", path, err)
				return nil
			}
			manifest.CopiedFiles = append(manifest.CopiedFiles, relPath)
			return nil
		})
	}

	// Add config.yaml
	configPath := filepath.Join(filepath.Dir(cfg.Storage.BasePath), "config.yaml")
	if _, err := os.Stat(configPath); err == nil {
		addFileToTar(tarWriter, configPath, "config.yaml")
	}

	// Write manifest
	manifestData, _ := json.MarshalIndent(manifest, "", "  ")
	hdr := &tar.Header{
		Name:    "manifest.json",
		Size:    int64(len(manifestData)),
		Mode:    0644,
		ModTime: time.Now(),
	}
	tarWriter.WriteHeader(hdr)
	tarWriter.Write(manifestData)

	log.Printf("[exporter] archive created: %s (%d logs, %d files, ~%d events)",
		archivePath,
		len(manifest.LogFiles),
		len(manifest.CopiedFiles),
		manifest.TotalEvents,
	)

	return archivePath, nil
}

func addFileToTar(tw *tar.Writer, srcPath, tarPath string) error {
	f, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer f.Close()

	info, err := f.Stat()
	if err != nil {
		return err
	}

	hdr, err := tar.FileInfoHeader(info, "")
	if err != nil {
		return err
	}
	hdr.Name = tarPath

	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}

	_, err = io.Copy(tw, f)
	return err
}

func countLines(path string) int64 {
	f, err := os.Open(path)
	if err != nil {
		return 0
	}
	defer f.Close()

	var count int64
	buf := make([]byte, 32*1024)
	for {
		n, err := f.Read(buf)
		for i := 0; i < n; i++ {
			if buf[i] == '\n' {
				count++
			}
		}
		if err != nil {
			break
		}
	}
	return count
}
