package types

import "time"

// --- Common fields ---

// EventBase contains fields shared by all events.
type EventBase struct {
	Type      string    `json:"type"`
	Timestamp time.Time `json:"timestamp"`
	SessionID string    `json:"session_id,omitempty"`
	MachineID string    `json:"machine_id"`
	PlayerID  string    `json:"player_id,omitempty"`
	EventID   string    `json:"ctf_event_id"`
}

// --- shell-watcher ---

// ShellCommandEvent represents a terminal command execution.
type ShellCommandEvent struct {
	Type           string `json:"type"` // "shell_command"
	TimestampStart string `json:"timestamp_start"`
	TimestampEnd   string `json:"timestamp_end"`
	SessionID      string `json:"session_id"`
	MachineID      string `json:"machine_id"`
	PlayerID       string `json:"player_id"`
	EventID        string `json:"ctf_event_id"`
	PID            int    `json:"pid"`
	TTY            string `json:"tty"`
	CWD            string `json:"cwd"`
	Shell          string `json:"shell"`
	Command        string `json:"command"`
	Argv           []string `json:"argv"`
	ExitCode       int    `json:"exit_code"`
	StdoutPreview  string `json:"stdout_preview"`
	StdoutSize     int64  `json:"stdout_size_bytes"`
	StderrPreview  string `json:"stderr_preview,omitempty"`
	StderrSize     int64  `json:"stderr_size_bytes"`
	DurationMs     int64  `json:"duration_ms"`
}

// --- interactive-watcher ---

// InteractiveInputEvent represents input to an interactive REPL tool.
type InteractiveInputEvent struct {
	Type            string `json:"type"` // "interactive_input"
	Timestamp       string `json:"timestamp"`
	SessionID       string `json:"session_id"`
	MachineID       string `json:"machine_id"`
	PlayerID        string `json:"player_id"`
	EventID         string `json:"ctf_event_id"`
	PID             int    `json:"pid"`
	ProcessName     string `json:"process_name"`
	ParentCommand   string `json:"parent_command"`
	InputLine       string `json:"input_line"`
	ResponsePreview string `json:"response_preview,omitempty"`
	ResponseSize    int64  `json:"response_size_bytes,omitempty"`
}

// --- proc-monitor ---

// ProcessSpawnEvent represents a process creation.
type ProcessSpawnEvent struct {
	Type         string   `json:"type"` // "process_spawn"
	Timestamp    string   `json:"timestamp"`
	MachineID    string   `json:"machine_id"`
	PlayerID     string   `json:"player_id"`
	EventID      string   `json:"ctf_event_id"`
	PID          int      `json:"pid"`
	PPID         int      `json:"ppid"`
	BinaryPath   string   `json:"binary_path"`
	BinarySHA256 string   `json:"binary_sha256"`
	Argv         []string `json:"argv"`
	CWD          string   `json:"cwd"`
	UID          int      `json:"uid"`
	GID          int      `json:"gid"`
	IsCTFTool    bool     `json:"is_ctf_tool"`
	ToolCategory string   `json:"tool_category,omitempty"`
}

// ProcessExitEvent represents a process termination.
type ProcessExitEvent struct {
	Type       string `json:"type"` // "process_exit"
	Timestamp  string `json:"timestamp"`
	MachineID  string `json:"machine_id"`
	EventID    string `json:"ctf_event_id"`
	PID        int    `json:"pid"`
	ExitCode   int    `json:"exit_code"`
	DurationMs int64  `json:"duration_ms"`
}

// --- net-sniffer ---

// NetworkConnectionEvent represents a network connection.
type NetworkConnectionEvent struct {
	Type          string `json:"type"` // "network_connection"
	Timestamp     string `json:"timestamp"`
	MachineID     string `json:"machine_id"`
	PlayerID      string `json:"player_id"`
	EventID       string `json:"ctf_event_id"`
	PID           int    `json:"pid"`
	ProcessName   string `json:"process_name"`
	Protocol      string `json:"protocol"` // TCP, UDP
	SrcIP         string `json:"src_ip"`
	SrcPort       int    `json:"src_port"`
	DstIP         string `json:"dst_ip"`
	DstPort       int    `json:"dst_port"`
	Direction     string `json:"direction"` // inbound, outbound
	State         string `json:"state"`
	BytesSent     int64  `json:"bytes_sent"`
	BytesReceived int64  `json:"bytes_received"`
	DurationMs    int64  `json:"duration_ms"`
}

// DNSQueryEvent represents a DNS lookup.
type DNSQueryEvent struct {
	Type       string   `json:"type"` // "dns_query"
	Timestamp  string   `json:"timestamp"`
	MachineID  string   `json:"machine_id"`
	EventID    string   `json:"ctf_event_id"`
	PID        int      `json:"pid"`
	Domain     string   `json:"domain"`
	QueryType  string   `json:"query_type"` // A, AAAA, CNAME, etc.
	Answers    []string `json:"answers,omitempty"`
	LatencyMs  int64    `json:"latency_ms"`
}

// --- browser-watcher ---

// BrowserRequestEvent represents an HTTP request captured by mitmproxy.
type BrowserRequestEvent struct {
	Type                string `json:"type"` // "browser_request"
	Timestamp           string `json:"timestamp"`
	MachineID           string `json:"machine_id"`
	PlayerID            string `json:"player_id"`
	EventID             string `json:"ctf_event_id"`
	PID                 int    `json:"pid,omitempty"`
	ProcessName         string `json:"process_name,omitempty"`
	Method              string `json:"method"`
	URL                 string `json:"url"`
	Referer             string `json:"referer,omitempty"`
	RequestBodyPreview  string `json:"request_body_preview,omitempty"`
	RequestBodySize     int64  `json:"request_body_size_bytes,omitempty"`
	ResponseStatus      int    `json:"response_status"`
	ResponseContentType string `json:"response_content_type,omitempty"`
	ResponseBodyPreview string `json:"response_body_preview,omitempty"`
	ResponseSize        int64  `json:"response_size_bytes,omitempty"`
	LatencyMs           int64  `json:"latency_ms"`
	TLS                 bool   `json:"tls"`
}

// --- fs-monitor ---

// FSEvent represents a filesystem event.
type FSEvent struct {
	Type           string `json:"type"` // "fs_event"
	Timestamp      string `json:"timestamp"`
	MachineID      string `json:"machine_id"`
	PlayerID       string `json:"player_id"`
	EventID        string `json:"ctf_event_id"`
	PID            int    `json:"pid"`
	ProcessName    string `json:"process_name"`
	Operation      string `json:"operation"` // CREATE, READ, WRITE, DELETE, RENAME, CHMOD, CHOWN
	Path           string `json:"path"`
	FileType       string `json:"file_type,omitempty"`
	SizeBytes      int64  `json:"size_bytes,omitempty"`
	SHA256         string `json:"sha256,omitempty"`
	ContentPreview string `json:"content_preview,omitempty"`
	Copied         bool   `json:"copied,omitempty"` // true if file was backed up to /home/iron/files/
}

// --- syscall-monitor ---

// SyscallEvent represents a system call.
type SyscallEvent struct {
	Type      string `json:"type"` // "syscall"
	Timestamp string `json:"timestamp"`
	MachineID string `json:"machine_id"`
	EventID   string `json:"ctf_event_id"`
	PID       int    `json:"pid"`
	TID       int    `json:"tid"`
	Comm      string `json:"comm"`
	Syscall   string `json:"syscall"`
	Args      []string `json:"args,omitempty"`
	RetVal    int64  `json:"ret_val"`
}

// --- CTF tool categories ---

// CTFToolMap maps binary names to their CTF tool categories.
var CTFToolMap = map[string]string{
	// recon
	"nmap": "recon", "masscan": "recon", "gobuster": "recon",
	"ffuf": "recon", "nikto": "recon", "dirbuster": "recon",
	"feroxbuster": "recon",
	// web
	"burpsuite": "web", "sqlmap": "web", "wfuzz": "web",
	"hydra": "web", "curl": "web", "wget": "web",
	// exploit
	"msfconsole": "exploit", "msfvenom": "exploit", "searchsploit": "exploit",
	// pwn
	"gdb": "pwn", "pwndbg": "pwn", "checksec": "pwn",
	// reverse
	"ghidra": "reverse", "radare2": "reverse", "r2": "reverse",
	"ltrace": "reverse", "strace": "reverse", "ida": "reverse",
	// crypto
	"hashcat": "crypto", "john": "crypto", "openssl": "crypto",
	// forensics
	"binwalk": "forensics", "volatility": "forensics", "strings": "forensics",
	"xxd": "forensics", "file": "forensics", "exiftool": "forensics",
	// network
	"wireshark": "network", "tcpdump": "network", "netcat": "network",
	"socat": "network", "ncat": "network", "nc": "network",
	// uav
	"mavproxy.py": "uav", "pymavlink": "uav",
	// ad_attack
	"rubeus": "ad_attack", "mimikatz": "ad_attack", "crackmapexec": "ad_attack",
	"evil-winrm": "ad_attack",
	// rdp
	"xfreerdp": "rdp", "xfreerdp3": "rdp", "rdesktop": "rdp",
	// ssh
	"ssh": "ssh", "scp": "ssh", "sftp": "ssh",
}

// InteractiveTargetProcesses lists processes whose stdin should be intercepted.
var InteractiveTargetProcesses = map[string]bool{
	"mavproxy.py": true, "gdb": true, "msfconsole": true,
	"python3": true, "python": true, "sqlmap": true,
	"radare2": true, "r2": true, "pwndbg": true,
	"nc": true, "ncat": true, "socat": true,
}

// CopyableExtensions lists file extensions that should be backed up.
var CopyableExtensions = map[string]bool{
	".py": true, ".sh": true, ".php": true, ".rb": true,
	".c": true, ".txt": true, ".pl": true, ".js": true,
	".ps1": true, ".bat": true, ".conf": true, ".yml": true,
	".yaml": true, ".json": true, ".xml": true, ".sql": true,
}

// TargetSyscalls lists syscalls to monitor.
var TargetSyscalls = []string{
	"connect", "bind", "execve", "open", "openat",
	"read", "write", "mmap", "mprotect", "setuid",
	"ptrace", "fork", "clone",
}
