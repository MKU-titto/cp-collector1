package aggregator

import (
	"context"
	"fmt"
	"log"
	"sync"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/watchers"
)

// Aggregator manages the lifecycle of all watchers.
type Aggregator struct {
	cfg      config.Config
	writer   *storage.Writer
	watchers []watchers.Watcher
}

// New creates a new Aggregator with all configured watchers.
func New(cfg config.Config, writer *storage.Writer) *Aggregator {
	agg := &Aggregator{
		cfg:    cfg,
		writer: writer,
	}

	// Register watchers based on agent type and enabled flags
	switch cfg.Agent.Type {
	case "client_machine":
		agg.registerClientMachineWatchers()
	case "linux_machine":
		// Future: register server-side watchers
		log.Printf("[aggregator] linux_machine watchers not yet implemented")
	case "windows_machine":
		log.Printf("[aggregator] windows_machine watchers not yet implemented")
	default:
		log.Printf("[aggregator] unknown agent type: %s", cfg.Agent.Type)
	}

	return agg
}

func (a *Aggregator) registerClientMachineWatchers() {
	if a.cfg.Shell.Enabled {
		a.watchers = append(a.watchers, watchers.NewShellWatcher(a.cfg, a.writer))
	}

	// interactive-watcher (eBPF) — always enabled for client_machine
	a.watchers = append(a.watchers, watchers.NewInteractiveWatcher(a.cfg, a.writer))

	if a.cfg.Proc.Enabled {
		a.watchers = append(a.watchers, watchers.NewProcMonitor(a.cfg, a.writer))
	}

	if a.cfg.Net.Enabled {
		a.watchers = append(a.watchers, watchers.NewNetSniffer(a.cfg, a.writer))
	}

	if a.cfg.Browser.Enabled {
		a.watchers = append(a.watchers, watchers.NewBrowserWatcher(a.cfg, a.writer))
	}

	if a.cfg.FS.Enabled {
		a.watchers = append(a.watchers, watchers.NewFSMonitor(a.cfg, a.writer))
	}

	// syscall-monitor — optional, high overhead
	// Enabled only when explicitly configured
	a.watchers = append(a.watchers, watchers.NewSyscallMonitor(a.cfg, a.writer))
}

// Start launches all watchers concurrently.
func (a *Aggregator) Start(ctx context.Context) error {
	if len(a.watchers) == 0 {
		return fmt.Errorf("no watchers configured")
	}

	var wg sync.WaitGroup
	errCh := make(chan error, len(a.watchers))

	log.Printf("[aggregator] starting %d watchers", len(a.watchers))

	for _, w := range a.watchers {
		wg.Add(1)
		go func(w watchers.Watcher) {
			defer wg.Done()
			log.Printf("[aggregator] starting %s", w.Name())
			if err := w.Start(ctx); err != nil {
				log.Printf("[aggregator] %s error: %v", w.Name(), err)
				errCh <- fmt.Errorf("%s: %w", w.Name(), err)
			}
		}(w)
	}

	// Wait for context cancellation
	<-ctx.Done()

	// Stop all watchers
	log.Printf("[aggregator] stopping all watchers...")
	for _, w := range a.watchers {
		if err := w.Stop(); err != nil {
			log.Printf("[aggregator] stop %s: %v", w.Name(), err)
		}
	}

	wg.Wait()
	close(errCh)

	// Collect errors
	var errs []error
	for err := range errCh {
		errs = append(errs, err)
	}

	if len(errs) > 0 {
		return fmt.Errorf("watcher errors: %v", errs)
	}
	return nil
}

// WatcherNames returns names of all registered watchers.
func (a *Aggregator) WatcherNames() []string {
	names := make([]string, len(a.watchers))
	for i, w := range a.watchers {
		names[i] = w.Name()
	}
	return names
}
