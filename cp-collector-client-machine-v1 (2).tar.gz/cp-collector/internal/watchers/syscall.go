package watchers

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"log"
	"time"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

// SyscallMonitor traces target syscalls via eBPF tracepoints.
type SyscallMonitor struct {
	cfg    config.Config
	writer *storage.Writer

	links  []link.Link
	reader *ringbuf.Reader
}

// syscallEvent matches the eBPF C struct
type syscallEvent struct {
	PID         uint32
	TID         uint32
	SyscallNr   uint32
	RetVal      int64
	TimestampNs uint64
	Comm        [16]byte
	Arg0        uint64
	Arg1        uint64
	Arg2        uint64
}

// Syscall number to name mapping (x86_64)
var syscallNames = map[uint32]string{
	0: "read", 1: "write", 2: "open", 3: "close",
	9: "mmap", 10: "mprotect", 41: "socket",
	42: "connect", 49: "bind", 56: "clone",
	57: "fork", 59: "execve", 101: "ptrace",
	105: "setuid", 257: "openat",
}

func NewSyscallMonitor(cfg config.Config, writer *storage.Writer) *SyscallMonitor {
	return &SyscallMonitor{
		cfg:    cfg,
		writer: writer,
	}
}

func (w *SyscallMonitor) Name() string { return "syscall-monitor" }

func (w *SyscallMonitor) Start(ctx context.Context) error {
	// Load eBPF program
	spec, err := ebpf.LoadCollectionSpec("ebpf/syscall/syscall.o")
	if err != nil {
		return fmt.Errorf("load eBPF spec: %w", err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}

	// Attach to target syscall tracepoints
	for _, syscall := range types.TargetSyscalls {
		enterName := fmt.Sprintf("sys_enter_%s", syscall)
		prog, ok := coll.Programs[fmt.Sprintf("tracepoint__syscalls__%s", enterName)]
		if !ok {
			log.Printf("[syscall-monitor] no program for %s, skipping", syscall)
			continue
		}

		l, err := link.Tracepoint("syscalls", enterName, prog, nil)
		if err != nil {
			log.Printf("[syscall-monitor] attach %s: %v", enterName, err)
			continue
		}
		w.links = append(w.links, l)
		log.Printf("[syscall-monitor] attached %s", enterName)
	}

	// Ring buffer reader
	eventsMap, ok := coll.Maps["syscall_events"]
	if !ok {
		return fmt.Errorf("syscall_events map not found")
	}

	rd, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ringbuf reader: %w", err)
	}
	w.reader = rd

	log.Printf("[syscall-monitor] started with %d tracepoints", len(w.links))

	// Read events
	go w.readEvents(ctx)

	<-ctx.Done()
	return nil
}

func (w *SyscallMonitor) Stop() error {
	if w.reader != nil {
		w.reader.Close()
	}
	for _, l := range w.links {
		l.Close()
	}
	log.Printf("[syscall-monitor] stopped")
	return nil
}

func (w *SyscallMonitor) readEvents(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		record, err := w.reader.Read()
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				continue
			}
		}

		if len(record.RawSample) < int(unsafe.Sizeof(syscallEvent{})) {
			continue
		}

		var raw syscallEvent
		if err := binary.Read(bytes.NewReader(record.RawSample), binary.LittleEndian, &raw); err != nil {
			continue
		}

		// Skip iron user processes (our own)
		comm := nullTermStr(raw.Comm[:])
		if comm == "cp-collector" {
			continue
		}

		syscallName := syscallNames[raw.SyscallNr]
		if syscallName == "" {
			syscallName = fmt.Sprintf("syscall_%d", raw.SyscallNr)
		}

		// Format args
		args := formatSyscallArgs(syscallName, raw.Arg0, raw.Arg1, raw.Arg2)

		event := types.SyscallEvent{
			Type:      "syscall",
			Timestamp: time.Now().UTC().Format(time.RFC3339Nano),
			MachineID: w.cfg.Agent.MachineID,
			EventID:   w.cfg.Agent.CTFEventID,
			PID:       int(raw.PID),
			TID:       int(raw.TID),
			Comm:      comm,
			Syscall:   syscallName,
			Args:      args,
			RetVal:    raw.RetVal,
		}

		if err := w.writer.Write(event); err != nil {
			log.Printf("[syscall-monitor] write: %v", err)
		}
	}
}

func nullTermStr(b []byte) string {
	for i, c := range b {
		if c == 0 {
			return string(b[:i])
		}
	}
	return string(b)
}

func formatSyscallArgs(name string, arg0, arg1, arg2 uint64) []string {
	switch name {
	case "connect":
		return []string{fmt.Sprintf("fd=%d", arg0), fmt.Sprintf("addr=%x", arg1)}
	case "bind":
		return []string{fmt.Sprintf("fd=%d", arg0), fmt.Sprintf("addr=%x", arg1)}
	case "execve":
		return []string{fmt.Sprintf("filename=%x", arg0)}
	case "open", "openat":
		return []string{fmt.Sprintf("filename=%x", arg0), fmt.Sprintf("flags=%d", arg1)}
	case "mmap":
		return []string{fmt.Sprintf("addr=%x", arg0), fmt.Sprintf("len=%d", arg1), fmt.Sprintf("prot=%d", arg2)}
	case "mprotect":
		return []string{fmt.Sprintf("addr=%x", arg0), fmt.Sprintf("len=%d", arg1), fmt.Sprintf("prot=%d", arg2)}
	case "ptrace":
		return []string{fmt.Sprintf("request=%d", arg0), fmt.Sprintf("pid=%d", arg1)}
	default:
		return []string{fmt.Sprintf("arg0=%d", arg0), fmt.Sprintf("arg1=%d", arg1)}
	}
}
