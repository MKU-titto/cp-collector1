package watchers

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

// ProcMonitor watches for process spawn/exit events via /proc polling + audit.
type ProcMonitor struct {
	cfg    config.Config
	writer *storage.Writer

	mu          sync.RWMutex
	knownPIDs   map[int]procEntry
	pollTicker  *time.Ticker
}

type procEntry struct {
	PID        int
	PPID       int
	BinaryPath string
	Argv       []string
	CWD        string
	UID        int
	GID        int
	StartTime  time.Time
}

func NewProcMonitor(cfg config.Config, writer *storage.Writer) *ProcMonitor {
	return &ProcMonitor{
		cfg:       cfg,
		writer:    writer,
		knownPIDs: make(map[int]procEntry),
	}
}

func (w *ProcMonitor) Name() string { return "proc-monitor" }

func (w *ProcMonitor) Start(ctx context.Context) error {
	// Setup auditd rules if configured
	if w.cfg.Proc.UseAuditd {
		if err := w.setupAuditRules(); err != nil {
			log.Printf("[proc-monitor] auditd setup failed, falling back to polling: %v", err)
		} else {
			go w.readAuditLog(ctx)
		}
	}

	// Always run /proc polling as a safety net
	interval := time.Duration(w.cfg.Proc.PollInterval) * time.Millisecond
	w.pollTicker = time.NewTicker(interval)

	log.Printf("[proc-monitor] started (poll interval: %v, auditd: %v)", interval, w.cfg.Proc.UseAuditd)

	// Initial scan
	w.scanProc()

	for {
		select {
		case <-w.pollTicker.C:
			w.scanProc()
		case <-ctx.Done():
			return nil
		}
	}
}

func (w *ProcMonitor) Stop() error {
	if w.pollTicker != nil {
		w.pollTicker.Stop()
	}
	if w.cfg.Proc.UseAuditd {
		w.cleanupAuditRules()
	}
	log.Printf("[proc-monitor] stopped (tracked %d processes)", len(w.knownPIDs))
	return nil
}

// scanProc walks /proc and detects new/exited processes.
func (w *ProcMonitor) scanProc() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		log.Printf("[proc-monitor] read /proc: %v", err)
		return
	}

	activePIDs := make(map[int]bool)

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}
		activePIDs[pid] = true

		w.mu.RLock()
		_, known := w.knownPIDs[pid]
		w.mu.RUnlock()

		if !known {
			// New process detected
			info := w.readProcessInfo(pid)
			if info == nil {
				continue
			}

			w.mu.Lock()
			w.knownPIDs[pid] = *info
			w.mu.Unlock()

			w.emitSpawnEvent(*info)
		}
	}

	// Detect exited processes
	w.mu.Lock()
	for pid, entry := range w.knownPIDs {
		if !activePIDs[pid] {
			w.emitExitEvent(entry)
			delete(w.knownPIDs, pid)
		}
	}
	w.mu.Unlock()
}

func (w *ProcMonitor) readProcessInfo(pid int) *procEntry {
	// Read binary path
	exePath, err := os.Readlink(fmt.Sprintf("/proc/%d/exe", pid))
	if err != nil {
		return nil // Process may have exited
	}

	// Read cmdline
	cmdlineData, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid))
	if err != nil {
		return nil
	}
	argv := parseCmdline(cmdlineData)

	// Read CWD
	cwd, _ := os.Readlink(fmt.Sprintf("/proc/%d/cwd", pid))

	// Read status for PPID, UID, GID
	status := readProcStatusFile(pid)
	ppid, _ := strconv.Atoi(status["PPid"])
	uidStr := strings.Fields(status["Uid"])
	uid := 0
	if len(uidStr) > 0 {
		uid, _ = strconv.Atoi(uidStr[0])
	}
	gidStr := strings.Fields(status["Gid"])
	gid := 0
	if len(gidStr) > 0 {
		gid, _ = strconv.Atoi(gidStr[0])
	}

	return &procEntry{
		PID:        pid,
		PPID:       ppid,
		BinaryPath: exePath,
		Argv:       argv,
		CWD:        cwd,
		UID:        uid,
		GID:        gid,
		StartTime:  time.Now(),
	}
}

func (w *ProcMonitor) emitSpawnEvent(info procEntry) {
	baseName := filepath.Base(info.BinaryPath)
	toolCategory, isTool := types.CTFToolMap[baseName]

	sha := hashFile(info.BinaryPath)

	event := types.ProcessSpawnEvent{
		Type:         "process_spawn",
		Timestamp:    time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:    w.cfg.Agent.MachineID,
		PlayerID:     w.cfg.Agent.PlayerID,
		EventID:      w.cfg.Agent.CTFEventID,
		PID:          info.PID,
		PPID:         info.PPID,
		BinaryPath:   info.BinaryPath,
		BinarySHA256: sha,
		Argv:         info.Argv,
		CWD:          info.CWD,
		UID:          info.UID,
		GID:          info.GID,
		IsCTFTool:    isTool,
		ToolCategory: toolCategory,
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("[proc-monitor] write spawn: %v", err)
	}
}

func (w *ProcMonitor) emitExitEvent(info procEntry) {
	duration := time.Since(info.StartTime)

	event := types.ProcessExitEvent{
		Type:       "process_exit",
		Timestamp:  time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:  w.cfg.Agent.MachineID,
		EventID:    w.cfg.Agent.CTFEventID,
		PID:        info.PID,
		ExitCode:   -1, // Not available via /proc polling
		DurationMs: duration.Milliseconds(),
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("[proc-monitor] write exit: %v", err)
	}
}

// --- Auditd integration ---

func (w *ProcMonitor) setupAuditRules() error {
	// Add audit rule for execve syscall
	// This requires auditd to be installed and running
	rules := []string{
		"-a always,exit -F arch=b64 -S execve -k cp_collector_exec",
		"-a always,exit -F arch=b32 -S execve -k cp_collector_exec",
	}

	for _, rule := range rules {
		cmd := fmt.Sprintf("auditctl %s", rule)
		// In production, execute via exec.Command
		log.Printf("[proc-monitor] audit rule: %s", cmd)
	}
	return nil
}

func (w *ProcMonitor) cleanupAuditRules() {
	log.Printf("[proc-monitor] cleaning up audit rules")
	// auditctl -d always,exit -F arch=b64 -S execve -k cp_collector_exec
}

func (w *ProcMonitor) readAuditLog(ctx context.Context) {
	// Watch /var/log/audit/audit.log for execve events
	logPath := "/var/log/audit/audit.log"

	f, err := os.Open(logPath)
	if err != nil {
		log.Printf("[proc-monitor] open audit log: %v", err)
		return
	}
	defer f.Close()

	// Seek to end (only process new events)
	f.Seek(0, io.SeekEnd)

	scanner := bufio.NewScanner(f)
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		if scanner.Scan() {
			line := scanner.Text()
			if strings.Contains(line, "cp_collector_exec") {
				w.parseAuditLine(line)
			}
		} else {
			// No new data, wait a bit
			time.Sleep(100 * time.Millisecond)
			// Reopen to catch log rotation
		}
	}
}

func (w *ProcMonitor) parseAuditLine(line string) {
	// Parse auditd log format for execve events
	// type=SYSCALL ... pid=12345 ppid=1234 ... exe="/usr/bin/nmap" ...
	// This is a simplified parser — production code should use a proper audit parser
	log.Printf("[proc-monitor] audit event: %s", line[:min(len(line), 120)])
}

// --- Helpers ---

func parseCmdline(data []byte) []string {
	var args []string
	parts := strings.Split(strings.TrimRight(string(data), "\x00"), "\x00")
	for _, p := range parts {
		if p != "" {
			args = append(args, p)
		}
	}
	return args
}

func readProcStatusFile(pid int) map[string]string {
	f, err := os.Open(fmt.Sprintf("/proc/%d/status", pid))
	if err != nil {
		return map[string]string{}
	}
	defer f.Close()

	result := make(map[string]string)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		parts := strings.SplitN(scanner.Text(), ":", 2)
		if len(parts) == 2 {
			result[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return result
}

func hashFile(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	// Read only first 1MB to avoid hashing huge files
	io.CopyN(h, f, 1024*1024)
	return hex.EncodeToString(h.Sum(nil))
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
