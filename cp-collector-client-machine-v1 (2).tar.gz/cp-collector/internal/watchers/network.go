package watchers

import (
	"context"
	"fmt"
	"log"
	"net"
	"sync"
	"time"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

// NetSniffer captures network connections and DNS queries using libpcap.
type NetSniffer struct {
	cfg    config.Config
	writer *storage.Writer

	handles []*pcap.Handle

	// Connection tracking
	mu    sync.Mutex
	flows map[string]*connFlow
}

type connFlow struct {
	Protocol  string
	SrcIP     string
	SrcPort   int
	DstIP     string
	DstPort   int
	Direction string
	BytesSent int64
	BytesRecv int64
	StartTime time.Time
	LastSeen  time.Time
	State     string
	PID       int
	Process   string
}

func NewNetSniffer(cfg config.Config, writer *storage.Writer) *NetSniffer {
	return &NetSniffer{
		cfg:    cfg,
		writer: writer,
		flows:  make(map[string]*connFlow),
	}
}

func (w *NetSniffer) Name() string { return "net-sniffer" }

func (w *NetSniffer) Start(ctx context.Context) error {
	for _, iface := range w.cfg.Net.Interfaces {
		handle, err := pcap.OpenLive(iface, 1600, true, pcap.BlockForever)
		if err != nil {
			log.Printf("[net-sniffer] open %s: %v (skipping)", iface, err)
			continue
		}

		// Apply BPF filter if configured
		if w.cfg.Net.BPFFilter != "" {
			if err := handle.SetBPFFilter(w.cfg.Net.BPFFilter); err != nil {
				log.Printf("[net-sniffer] BPF filter on %s: %v", iface, err)
			}
		}

		w.handles = append(w.handles, handle)
		go w.captureInterface(ctx, iface, handle)
		log.Printf("[net-sniffer] capturing on %s", iface)
	}

	if len(w.handles) == 0 {
		return fmt.Errorf("no interfaces available for capture")
	}

	// Start flow expiry goroutine
	go w.expireFlows(ctx)

	<-ctx.Done()
	return nil
}

func (w *NetSniffer) Stop() error {
	for _, h := range w.handles {
		h.Close()
	}
	// Emit all remaining flows
	w.mu.Lock()
	for key, flow := range w.flows {
		w.emitFlow(flow)
		delete(w.flows, key)
	}
	w.mu.Unlock()
	log.Printf("[net-sniffer] stopped")
	return nil
}

func (w *NetSniffer) captureInterface(ctx context.Context, iface string, handle *pcap.Handle) {
	packetSource := gopacket.NewPacketSource(handle, handle.LinkType())
	packetSource.NoCopy = true

	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		packet, err := packetSource.NextPacket()
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				continue
			}
		}

		w.processPacket(packet)
	}
}

func (w *NetSniffer) processPacket(packet gopacket.Packet) {
	// Extract IP layer
	ipLayer := packet.Layer(layers.LayerTypeIPv4)
	if ipLayer == nil {
		return
	}
	ip, _ := ipLayer.(*layers.IPv4)

	// Check for DNS (UDP port 53)
	if w.cfg.Net.CaptureDNS {
		dnsLayer := packet.Layer(layers.LayerTypeDNS)
		if dnsLayer != nil {
			w.processDNS(dnsLayer.(*layers.DNS), ip)
			return
		}
	}

	// Track TCP connections
	tcpLayer := packet.Layer(layers.LayerTypeTCP)
	if tcpLayer != nil {
		tcp, _ := tcpLayer.(*layers.TCP)
		w.trackTCPFlow(ip, tcp, len(packet.Data()))
		return
	}

	// Track UDP connections
	udpLayer := packet.Layer(layers.LayerTypeUDP)
	if udpLayer != nil {
		udp, _ := udpLayer.(*layers.UDP)
		w.trackUDPFlow(ip, udp, len(packet.Data()))
	}
}

func (w *NetSniffer) trackTCPFlow(ip *layers.IPv4, tcp *layers.TCP, packetLen int) {
	srcIP := ip.SrcIP.String()
	dstIP := ip.DstIP.String()
	srcPort := int(tcp.SrcPort)
	dstPort := int(tcp.DstPort)

	key := fmt.Sprintf("tcp:%s:%d-%s:%d", srcIP, srcPort, dstIP, dstPort)
	reverseKey := fmt.Sprintf("tcp:%s:%d-%s:%d", dstIP, dstPort, srcIP, srcPort)

	// Determine direction
	direction := "outbound"
	if isLocalIP(ip.DstIP) && !isLocalIP(ip.SrcIP) {
		direction = "inbound"
	}

	// Determine state
	state := "ESTABLISHED"
	if tcp.SYN && !tcp.ACK {
		state = "SYN_SENT"
	} else if tcp.SYN && tcp.ACK {
		state = "SYN_ACK"
	} else if tcp.FIN {
		state = "FIN"
	} else if tcp.RST {
		state = "RST"
	}

	w.mu.Lock()
	defer w.mu.Unlock()

	flow, exists := w.flows[key]
	if !exists {
		flow, exists = w.flows[reverseKey]
	}

	if !exists {
		flow = &connFlow{
			Protocol:  "TCP",
			SrcIP:     srcIP,
			SrcPort:   srcPort,
			DstIP:     dstIP,
			DstPort:   dstPort,
			Direction: direction,
			StartTime: time.Now(),
			State:     state,
			PID:       lookupPIDByPort(srcPort),
		}
		flow.Process = lookupProcessName(flow.PID)
		w.flows[key] = flow
	}

	flow.LastSeen = time.Now()
	flow.State = state

	// Count bytes
	if srcIP == flow.SrcIP {
		flow.BytesSent += int64(packetLen)
	} else {
		flow.BytesRecv += int64(packetLen)
	}

	// Emit on connection close
	if tcp.FIN || tcp.RST {
		w.emitFlow(flow)
		delete(w.flows, key)
		delete(w.flows, reverseKey)
	}
}

func (w *NetSniffer) trackUDPFlow(ip *layers.IPv4, udp *layers.UDP, packetLen int) {
	srcIP := ip.SrcIP.String()
	dstIP := ip.DstIP.String()
	srcPort := int(udp.SrcPort)
	dstPort := int(udp.DstPort)

	key := fmt.Sprintf("udp:%s:%d-%s:%d", srcIP, srcPort, dstIP, dstPort)

	direction := "outbound"
	if isLocalIP(ip.DstIP) && !isLocalIP(ip.SrcIP) {
		direction = "inbound"
	}

	w.mu.Lock()
	defer w.mu.Unlock()

	flow, exists := w.flows[key]
	if !exists {
		flow = &connFlow{
			Protocol:  "UDP",
			SrcIP:     srcIP,
			SrcPort:   srcPort,
			DstIP:     dstIP,
			DstPort:   dstPort,
			Direction: direction,
			StartTime: time.Now(),
			State:     "ACTIVE",
			PID:       lookupPIDByPort(srcPort),
		}
		flow.Process = lookupProcessName(flow.PID)
		w.flows[key] = flow
	}

	flow.LastSeen = time.Now()
	flow.BytesSent += int64(packetLen)
}

func (w *NetSniffer) processDNS(dns *layers.DNS, ip *layers.IPv4) {
	if dns.QR { // Response
		for _, q := range dns.Questions {
			var answers []string
			for _, a := range dns.Answers {
				if a.IP != nil {
					answers = append(answers, a.IP.String())
				} else if a.CNAME != nil {
					answers = append(answers, string(a.CNAME))
				}
			}

			event := types.DNSQueryEvent{
				Type:      "dns_query",
				Timestamp: time.Now().UTC().Format(time.RFC3339Nano),
				MachineID: w.cfg.Agent.MachineID,
				EventID:   w.cfg.Agent.CTFEventID,
				Domain:    string(q.Name),
				QueryType: q.Type.String(),
				Answers:   answers,
			}

			if err := w.writer.Write(event); err != nil {
				log.Printf("[net-sniffer] write DNS: %v", err)
			}
		}
	}
}

func (w *NetSniffer) emitFlow(flow *connFlow) {
	duration := flow.LastSeen.Sub(flow.StartTime)

	event := types.NetworkConnectionEvent{
		Type:          "network_connection",
		Timestamp:     flow.StartTime.UTC().Format(time.RFC3339Nano),
		MachineID:     w.cfg.Agent.MachineID,
		PlayerID:      w.cfg.Agent.PlayerID,
		EventID:       w.cfg.Agent.CTFEventID,
		PID:           flow.PID,
		ProcessName:   flow.Process,
		Protocol:      flow.Protocol,
		SrcIP:         flow.SrcIP,
		SrcPort:       flow.SrcPort,
		DstIP:         flow.DstIP,
		DstPort:       flow.DstPort,
		Direction:     flow.Direction,
		State:         flow.State,
		BytesSent:     flow.BytesSent,
		BytesReceived: flow.BytesRecv,
		DurationMs:    duration.Milliseconds(),
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("[net-sniffer] write flow: %v", err)
	}
}

// expireFlows emits and removes flows that have been idle for >30 seconds.
func (w *NetSniffer) expireFlows(ctx context.Context) {
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			w.mu.Lock()
			now := time.Now()
			for key, flow := range w.flows {
				if now.Sub(flow.LastSeen) > 30*time.Second {
					w.emitFlow(flow)
					delete(w.flows, key)
				}
			}
			w.mu.Unlock()
		case <-ctx.Done():
			return
		}
	}
}

// --- Helpers ---

func isLocalIP(ip net.IP) bool {
	ifaces, err := net.Interfaces()
	if err != nil {
		return false
	}
	for _, iface := range ifaces {
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			var ifIP net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ifIP = v.IP
			case *net.IPAddr:
				ifIP = v.IP
			}
			if ifIP != nil && ifIP.Equal(ip) {
				return true
			}
		}
	}
	return false
}

// lookupPIDByPort looks up the PID that owns a given local port via /proc/net/tcp.
func lookupPIDByPort(port int) int {
	// Parse /proc/net/tcp to find the inode for this port, then scan /proc/*/fd
	// This is simplified — production version should cache and use netlink.
	portHex := fmt.Sprintf("%04X", port)

	for _, proto := range []string{"/proc/net/tcp", "/proc/net/udp"} {
		f, err := os.Open(proto)
		if err != nil {
			continue
		}
		defer f.Close()

		scanner := bufio.NewScanner(f)
		scanner.Scan() // skip header
		for scanner.Scan() {
			fields := strings.Fields(scanner.Text())
			if len(fields) < 10 {
				continue
			}
			localAddr := fields[1]
			parts := strings.Split(localAddr, ":")
			if len(parts) == 2 && parts[1] == portHex {
				inode := fields[9]
				return findPIDByInode(inode)
			}
		}
	}
	return 0
}

func findPIDByInode(inode string) int {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return 0
	}

	target := fmt.Sprintf("socket:[%s]", inode)

	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}

		fdPath := fmt.Sprintf("/proc/%d/fd", pid)
		fds, err := os.ReadDir(fdPath)
		if err != nil {
			continue
		}

		for _, fd := range fds {
			link, err := os.Readlink(fmt.Sprintf("%s/%s", fdPath, fd.Name()))
			if err != nil {
				continue
			}
			if link == target {
				return pid
			}
		}
	}
	return 0
}

func lookupProcessName(pid int) string {
	if pid <= 0 {
		return ""
	}
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}
