package watchers

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/fsnotify/fsnotify"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

// FSMonitor watches filesystem changes using inotify.
type FSMonitor struct {
	cfg    config.Config
	writer *storage.Writer

	watcher      *fsnotify.Watcher
	excludeSet   map[string]bool
}

func NewFSMonitor(cfg config.Config, writer *storage.Writer) *FSMonitor {
	excludeSet := make(map[string]bool)
	for _, p := range cfg.FS.ExcludePaths {
		excludeSet[p] = true
	}
	// Always exclude our own data directories
	excludeSet["/home/iron"] = true

	return &FSMonitor{
		cfg:        cfg,
		writer:     writer,
		excludeSet: excludeSet,
	}
}

func (w *FSMonitor) Name() string { return "fs-monitor" }

func (w *FSMonitor) Start(ctx context.Context) error {
	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		return fmt.Errorf("create inotify watcher: %w", err)
	}
	w.watcher = watcher

	// Add watch paths recursively
	for _, watchPath := range w.cfg.FS.WatchPaths {
		w.addWatchRecursive(watchPath)
	}

	log.Printf("[fs-monitor] watching %d paths", len(w.cfg.FS.WatchPaths))

	for {
		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return nil
			}
			w.handleEvent(event)

		case err, ok := <-watcher.Errors:
			if !ok {
				return nil
			}
			log.Printf("[fs-monitor] error: %v", err)

		case <-ctx.Done():
			return nil
		}
	}
}

func (w *FSMonitor) Stop() error {
	if w.watcher != nil {
		w.watcher.Close()
	}
	log.Printf("[fs-monitor] stopped")
	return nil
}

func (w *FSMonitor) addWatchRecursive(root string) {
	filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			if w.isExcluded(path) {
				return filepath.SkipDir
			}
			if err := w.watcher.Add(path); err != nil {
				log.Printf("[fs-monitor] watch %s: %v", path, err)
			}
		}
		return nil
	})
}

func (w *FSMonitor) isExcluded(path string) bool {
	for excl := range w.excludeSet {
		if strings.HasPrefix(path, excl) {
			return true
		}
	}
	// Skip hidden directories and common noise
	base := filepath.Base(path)
	if strings.HasPrefix(base, ".") && base != "." {
		return true
	}
	return false
}

func (w *FSMonitor) handleEvent(event fsnotify.Event) {
	path := event.Name

	if w.isExcluded(path) {
		return
	}

	operation := mapFSOperation(event.Op)
	if operation == "" {
		return
	}

	// Get file info
	var sizeBytes int64
	var fileType string
	info, err := os.Stat(path)
	if err == nil {
		sizeBytes = info.Size()
		if info.IsDir() {
			// Watch new directories
			if event.Op&fsnotify.Create != 0 {
				w.addWatchRecursive(path)
			}
			return // Don't log directory events themselves
		}
	}

	// Determine file type
	ext := strings.ToLower(filepath.Ext(path))
	fileType = classifyFileType(ext)

	// Calculate SHA256 for created/modified files
	var sha string
	if (operation == "CREATE" || operation == "WRITE") && sizeBytes > 0 && sizeBytes < 50*1024*1024 {
		sha = hashFilePath(path)
	}

	// Content preview for text/script files
	var preview string
	if isTextFile(ext) && sizeBytes > 0 {
		preview = readFilePreview(path, w.cfg.FS.MaxPreviewSize)
	}

	// Copy important files
	var copied bool
	if w.cfg.FS.CopyFiles && types.CopyableExtensions[ext] && sizeBytes > 0 && sizeBytes < 10*1024*1024 {
		if sha != "" {
			copied = w.copyFile(path, sha)
		}
	}

	// Resolve PID that caused the event (best-effort via /proc)
	pid, procName := resolveFSEventPID(path)

	fsEvent := types.FSEvent{
		Type:           "fs_event",
		Timestamp:      time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:      w.cfg.Agent.MachineID,
		PlayerID:       w.cfg.Agent.PlayerID,
		EventID:        w.cfg.Agent.CTFEventID,
		PID:            pid,
		ProcessName:    procName,
		Operation:      operation,
		Path:           path,
		FileType:       fileType,
		SizeBytes:      sizeBytes,
		SHA256:         sha,
		ContentPreview: preview,
		Copied:         copied,
	}

	if err := w.writer.Write(fsEvent); err != nil {
		log.Printf("[fs-monitor] write: %v", err)
	}
}

func (w *FSMonitor) copyFile(srcPath string, sha string) bool {
	dstPath := filepath.Join(w.cfg.Storage.FilesPath, sha+".bin")

	// Skip if already copied
	if _, err := os.Stat(dstPath); err == nil {
		return true
	}

	os.MkdirAll(filepath.Dir(dstPath), 0700)

	src, err := os.Open(srcPath)
	if err != nil {
		return false
	}
	defer src.Close()

	dst, err := os.OpenFile(dstPath, os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return false
	}
	defer dst.Close()

	_, err = io.Copy(dst, src)
	return err == nil
}

// --- Helpers ---

func mapFSOperation(op fsnotify.Op) string {
	switch {
	case op&fsnotify.Create != 0:
		return "CREATE"
	case op&fsnotify.Write != 0:
		return "WRITE"
	case op&fsnotify.Remove != 0:
		return "DELETE"
	case op&fsnotify.Rename != 0:
		return "RENAME"
	case op&fsnotify.Chmod != 0:
		return "CHMOD"
	default:
		return ""
	}
}

func classifyFileType(ext string) string {
	switch ext {
	case ".py":
		return "python_script"
	case ".sh", ".bash":
		return "shell_script"
	case ".php":
		return "php_script"
	case ".rb":
		return "ruby_script"
	case ".c", ".h":
		return "c_source"
	case ".go":
		return "go_source"
	case ".js":
		return "javascript"
	case ".pl":
		return "perl_script"
	case ".ps1":
		return "powershell_script"
	case ".conf", ".cfg", ".ini":
		return "config"
	case ".yml", ".yaml":
		return "yaml"
	case ".json":
		return "json"
	case ".xml":
		return "xml"
	case ".sql":
		return "sql"
	case ".txt", ".md", ".log":
		return "text"
	case ".exe", ".elf", "":
		return "binary"
	default:
		return "other"
	}
}

func isTextFile(ext string) bool {
	textExts := map[string]bool{
		".py": true, ".sh": true, ".php": true, ".rb": true, ".c": true,
		".h": true, ".go": true, ".js": true, ".pl": true, ".ps1": true,
		".conf": true, ".cfg": true, ".ini": true, ".yml": true, ".yaml": true,
		".json": true, ".xml": true, ".sql": true, ".txt": true, ".md": true,
		".log": true, ".csv": true, ".html": true, ".css": true,
	}
	return textExts[ext]
}

func readFilePreview(path string, maxSize int64) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	buf := make([]byte, maxSize)
	n, _ := f.Read(buf)
	if n == 0 {
		return ""
	}
	return string(buf[:n])
}

func hashFilePath(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	io.Copy(h, f)
	return hex.EncodeToString(h.Sum(nil))
}

// resolveFSEventPID attempts to find which process has the file open.
// This is best-effort — inotify doesn't provide PID info.
func resolveFSEventPID(path string) (int, string) {
	// In production, this would use fanotify (which provides PID) instead of inotify,
	// or cross-reference with auditd events.
	// For now, return 0.
	return 0, ""
}
