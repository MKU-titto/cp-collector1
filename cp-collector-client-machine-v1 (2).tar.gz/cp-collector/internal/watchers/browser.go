package watchers

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"os/exec"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

// BrowserWatcher manages mitmproxy in transparent mode and collects HTTP events.
// Architecture:
//   1. cp-collector starts mitmproxy with a custom addon script
//   2. The addon script writes JSON events to a UNIX socket
//   3. BrowserWatcher reads from that socket and writes to storage
type BrowserWatcher struct {
	cfg    config.Config
	writer *storage.Writer

	mitmCmd  *exec.Cmd
	listener net.Listener
	wg       sync.WaitGroup
}

func NewBrowserWatcher(cfg config.Config, writer *storage.Writer) *BrowserWatcher {
	return &BrowserWatcher{
		cfg:    cfg,
		writer: writer,
	}
}

func (w *BrowserWatcher) Name() string { return "browser-watcher" }

func (w *BrowserWatcher) Start(ctx context.Context) error {
	socketPath := w.cfg.Browser.OutputSocketPath

	// Remove stale socket
	os.Remove(socketPath)

	// Start UNIX socket listener
	ln, err := net.Listen("unix", socketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", socketPath, err)
	}
	os.Chmod(socketPath, 0660)
	w.listener = ln

	// Start mitmproxy with our addon
	addonPath := "/home/iron/mitmproxy_addon.py"
	if err := w.writeAddonScript(addonPath, socketPath); err != nil {
		return fmt.Errorf("write addon: %w", err)
	}

	w.mitmCmd = exec.CommandContext(ctx,
		"mitmdump",
		"--mode", "transparent",
		"--showhost",
		"--set", fmt.Sprintf("listen_port=%d", w.cfg.Browser.MitmproxyPort),
		"-s", addonPath,
		"--quiet",
	)
	w.mitmCmd.Stdout = os.Stdout
	w.mitmCmd.Stderr = os.Stderr

	if err := w.mitmCmd.Start(); err != nil {
		return fmt.Errorf("start mitmproxy: %w", err)
	}

	log.Printf("[browser-watcher] mitmproxy started on port %d", w.cfg.Browser.MitmproxyPort)

	// Accept connections from mitmproxy addon
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				select {
				case <-ctx.Done():
					return
				default:
					log.Printf("[browser-watcher] accept: %v", err)
					continue
				}
			}
			w.wg.Add(1)
			go w.handleConnection(ctx, conn)
		}
	}()

	<-ctx.Done()
	return nil
}

func (w *BrowserWatcher) Stop() error {
	if w.listener != nil {
		w.listener.Close()
	}
	if w.mitmCmd != nil && w.mitmCmd.Process != nil {
		w.mitmCmd.Process.Signal(os.Interrupt)
		w.mitmCmd.Wait()
	}
	w.wg.Wait()
	os.Remove(w.cfg.Browser.OutputSocketPath)
	log.Printf("[browser-watcher] stopped")
	return nil
}

func (w *BrowserWatcher) handleConnection(ctx context.Context, conn net.Conn) {
	defer w.wg.Done()
	defer conn.Close()

	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 0, 128*1024), 128*1024)

	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return
		default:
		}

		var raw mitmproxyEvent
		if err := json.Unmarshal(scanner.Bytes(), &raw); err != nil {
			log.Printf("[browser-watcher] unmarshal: %v", err)
			continue
		}

		event := w.buildEvent(raw)
		if err := w.writer.Write(event); err != nil {
			log.Printf("[browser-watcher] write: %v", err)
		}
	}
}

type mitmproxyEvent struct {
	Method              string `json:"method"`
	URL                 string `json:"url"`
	Referer             string `json:"referer"`
	RequestBodyPreview  string `json:"request_body_preview"`
	RequestBodySize     int64  `json:"request_body_size"`
	ResponseStatus      int    `json:"response_status"`
	ResponseContentType string `json:"response_content_type"`
	ResponseBodyPreview string `json:"response_body_preview"`
	ResponseSize        int64  `json:"response_size"`
	LatencyMs           int64  `json:"latency_ms"`
	TLS                 bool   `json:"tls"`
	Timestamp           string `json:"timestamp"`
}

func (w *BrowserWatcher) buildEvent(raw mitmproxyEvent) types.BrowserRequestEvent {
	ts := raw.Timestamp
	if ts == "" {
		ts = time.Now().UTC().Format(time.RFC3339Nano)
	}

	// Truncate body previews
	maxPreview := w.cfg.Browser.MaxBodyPreview
	reqBody := raw.RequestBodyPreview
	if int64(len(reqBody)) > maxPreview {
		reqBody = reqBody[:maxPreview]
	}
	respBody := raw.ResponseBodyPreview
	if int64(len(respBody)) > maxPreview {
		respBody = respBody[:maxPreview]
	}

	return types.BrowserRequestEvent{
		Type:                "browser_request",
		Timestamp:           ts,
		MachineID:           w.cfg.Agent.MachineID,
		PlayerID:            w.cfg.Agent.PlayerID,
		EventID:             w.cfg.Agent.CTFEventID,
		Method:              raw.Method,
		URL:                 raw.URL,
		Referer:             raw.Referer,
		RequestBodyPreview:  reqBody,
		RequestBodySize:     raw.RequestBodySize,
		ResponseStatus:      raw.ResponseStatus,
		ResponseContentType: raw.ResponseContentType,
		ResponseBodyPreview: respBody,
		ResponseSize:        raw.ResponseSize,
		LatencyMs:           raw.LatencyMs,
		TLS:                 raw.TLS,
	}
}

// writeAddonScript creates the mitmproxy Python addon that sends events to our socket.
func (w *BrowserWatcher) writeAddonScript(path string, socketPath string) error {
	script := fmt.Sprintf(`"""
Cyber Polygon cp-collector — mitmproxy addon
Sends HTTP flow data to cp-collector via UNIX socket.
"""
import json
import socket
import time
import os
from mitmproxy import http, ctx

SOCKET_PATH = "%s"
MAX_BODY_PREVIEW = %d

class CpCollectorAddon:
    def __init__(self):
        self.sock = None
        self._connect()

    def _connect(self):
        try:
            if self.sock:
                self.sock.close()
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.sock.connect(SOCKET_PATH)
        except Exception as e:
            ctx.log.warn(f"cp-collector: connect failed: {e}")
            self.sock = None

    def _send(self, data: dict):
        if not self.sock:
            self._connect()
        if not self.sock:
            return
        try:
            line = json.dumps(data, ensure_ascii=False) + "\n"
            self.sock.sendall(line.encode("utf-8"))
        except (BrokenPipeError, ConnectionResetError, OSError):
            self.sock = None
            self._connect()

    def response(self, flow: http.HTTPFlow):
        try:
            request = flow.request
            response = flow.response

            # Request body preview
            req_body = ""
            req_body_size = 0
            if request.content:
                req_body_size = len(request.content)
                try:
                    req_body = request.content[:MAX_BODY_PREVIEW].decode("utf-8", errors="replace")
                except:
                    req_body = ""

            # Response body preview
            resp_body = ""
            resp_size = 0
            if response and response.content:
                resp_size = len(response.content)
                content_type = response.headers.get("content-type", "")
                # Only capture text-based responses
                if any(t in content_type for t in ["text/", "json", "xml", "javascript"]):
                    try:
                        resp_body = response.content[:MAX_BODY_PREVIEW].decode("utf-8", errors="replace")
                    except:
                        resp_body = ""

            # Calculate latency
            latency_ms = 0
            if flow.response and hasattr(flow, 'timestamp_end') and hasattr(flow, 'timestamp_start'):
                latency_ms = int((flow.timestamp_end - flow.timestamp_start) * 1000)

            event = {
                "method": request.method,
                "url": request.pretty_url,
                "referer": request.headers.get("referer", ""),
                "request_body_preview": req_body,
                "request_body_size": req_body_size,
                "response_status": response.status_code if response else 0,
                "response_content_type": response.headers.get("content-type", "") if response else "",
                "response_body_preview": resp_body,
                "response_size": resp_size,
                "latency_ms": latency_ms,
                "tls": request.scheme == "https",
                "timestamp": time.strftime("%%Y-%%m-%%dT%%H:%%M:%%S.000Z", time.gmtime()),
            }
            self._send(event)
        except Exception as e:
            ctx.log.warn(f"cp-collector addon error: {e}")

addons = [CpCollectorAddon()]
`, socketPath, w.cfg.Browser.MaxBodyPreview)

	return os.WriteFile(path, []byte(script), 0644)
}
