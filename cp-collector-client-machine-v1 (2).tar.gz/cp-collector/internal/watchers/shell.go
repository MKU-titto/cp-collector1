package watchers

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"sync"

	"github.com/cyber-polygon/cp-collector/internal/config"
	"github.com/cyber-polygon/cp-collector/internal/storage"
	"github.com/cyber-polygon/cp-collector/internal/types"
)

const shellSocketPath = "/home/iron/shell_watcher.sock"

// ShellWatcher receives command events from bash/zsh preexec hooks via UNIX socket.
type ShellWatcher struct {
	cfg      config.Config
	writer   *storage.Writer
	listener net.Listener
	wg       sync.WaitGroup
}

func NewShellWatcher(cfg config.Config, writer *storage.Writer) *ShellWatcher {
	return &ShellWatcher{
		cfg:    cfg,
		writer: writer,
	}
}

func (w *ShellWatcher) Name() string { return "shell-watcher" }

func (w *ShellWatcher) Start(ctx context.Context) error {
	// Remove stale socket
	os.Remove(shellSocketPath)

	ln, err := net.Listen("unix", shellSocketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", shellSocketPath, err)
	}
	// Writable by all users so shell hooks from player sessions can connect
	if err := os.Chmod(shellSocketPath, 0666); err != nil {
		ln.Close()
		return fmt.Errorf("chmod socket: %w", err)
	}
	w.listener = ln

	log.Printf("[shell-watcher] listening on %s", shellSocketPath)

	// Accept connections
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				select {
				case <-ctx.Done():
					return
				default:
					log.Printf("[shell-watcher] accept error: %v", err)
					continue
				}
			}
			w.wg.Add(1)
			go w.handleConnection(ctx, conn)
		}
	}()

	<-ctx.Done()
	return nil
}

func (w *ShellWatcher) Stop() error {
	if w.listener != nil {
		w.listener.Close()
	}
	w.wg.Wait()
	os.Remove(shellSocketPath)
	log.Printf("[shell-watcher] stopped")
	return nil
}

func (w *ShellWatcher) handleConnection(ctx context.Context, conn net.Conn) {
	defer w.wg.Done()
	defer conn.Close()

	scanner := bufio.NewScanner(conn)
	// Allow large messages (stdout can be up to 64KB)
	scanner.Buffer(make([]byte, 0, 256*1024), 256*1024)

	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return
		default:
		}

		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}

		// Parse the raw event from the shell hook
		var raw shellHookMessage
		if err := json.Unmarshal(line, &raw); err != nil {
			log.Printf("[shell-watcher] unmarshal error: %v", err)
			continue
		}

		event := w.buildEvent(raw)
		if err := w.writer.Write(event); err != nil {
			log.Printf("[shell-watcher] write error: %v", err)
		}
	}

	if err := scanner.Err(); err != nil {
		log.Printf("[shell-watcher] scanner error: %v", err)
	}
}

// shellHookMessage is the JSON sent by bash/zsh hooks.
type shellHookMessage struct {
	Command        string `json:"command"`
	CWD            string `json:"cwd"`
	Shell          string `json:"shell"`
	PID            int    `json:"pid"`
	TTY            string `json:"tty"`
	TimestampStart string `json:"timestamp_start"`
	TimestampEnd   string `json:"timestamp_end"`
	ExitCode       int    `json:"exit_code"`
	Stdout         string `json:"stdout"`
	StdoutSize     int64  `json:"stdout_size"`
	Stderr         string `json:"stderr"`
	StderrSize     int64  `json:"stderr_size"`
	DurationMs     int64  `json:"duration_ms"`
}

func (w *ShellWatcher) buildEvent(raw shellHookMessage) types.ShellCommandEvent {
	// Truncate stdout/stderr to configured max
	stdout := raw.Stdout
	if int64(len(stdout)) > w.cfg.Shell.MaxStdoutBytes {
		stdout = stdout[:w.cfg.Shell.MaxStdoutBytes]
	}
	stderr := raw.Stderr
	if int64(len(stderr)) > w.cfg.Shell.MaxStderrBytes {
		stderr = stderr[:w.cfg.Shell.MaxStderrBytes]
	}

	return types.ShellCommandEvent{
		Type:           "shell_command",
		TimestampStart: raw.TimestampStart,
		TimestampEnd:   raw.TimestampEnd,
		SessionID:      fmt.Sprintf("sess_%s_%d", raw.TTY, raw.PID),
		MachineID:      w.cfg.Agent.MachineID,
		PlayerID:       w.cfg.Agent.PlayerID,
		EventID:        w.cfg.Agent.CTFEventID,
		PID:            raw.PID,
		TTY:            raw.TTY,
		CWD:            raw.CWD,
		Shell:          raw.Shell,
		Command:        raw.Command,
		Argv:           parseArgv(raw.Command),
		ExitCode:       raw.ExitCode,
		StdoutPreview:  stdout,
		StdoutSize:     raw.StdoutSize,
		StderrPreview:  stderr,
		StderrSize:     raw.StderrSize,
		DurationMs:     raw.DurationMs,
	}
}

// parseArgv splits a command string into argv (simplified).
func parseArgv(cmd string) []string {
	// Simple split — for complex cases (pipes, redirects) we keep the full command.
	// The shell hooks also send the raw command string for faithful reproduction.
	var args []string
	var current []byte
	inQuote := byte(0)
	escaped := false

	for i := 0; i < len(cmd); i++ {
		c := cmd[i]
		if escaped {
			current = append(current, c)
			escaped = false
			continue
		}
		if c == '\\' {
			escaped = true
			current = append(current, c)
			continue
		}
		if inQuote != 0 {
			current = append(current, c)
			if c == inQuote {
				inQuote = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			inQuote = c
			current = append(current, c)
			continue
		}
		if c == ' ' || c == '\t' {
			if len(current) > 0 {
				args = append(args, string(current))
				current = current[:0]
			}
			continue
		}
		current = append(current, c)
	}
	if len(current) > 0 {
		args = append(args, string(current))
	}
	return args
}
