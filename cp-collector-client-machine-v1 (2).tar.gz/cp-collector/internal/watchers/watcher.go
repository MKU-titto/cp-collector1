package watchers

import (
	"context"
)

// Watcher is the interface implemented by all data collection modules.
type Watcher interface {
	// Name returns the human-readable name of this watcher.
	Name() string

	// Start begins data collection. It should block until ctx is cancelled.
	Start(ctx context.Context) error

	// Stop gracefully shuts down the watcher.
	Stop() error
}
