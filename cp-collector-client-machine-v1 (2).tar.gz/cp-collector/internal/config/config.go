package config

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// Config is the root configuration structure.
type Config struct {
	Agent   AgentConfig   `yaml:"agent"`
	Storage StorageConfig `yaml:"storage"`
	Export  ExportConfig  `yaml:"export"`
	Shell   ShellConfig   `yaml:"shell"`
	Net     NetConfig     `yaml:"net"`
	Browser BrowserConfig `yaml:"browser"`
	FS      FSConfig      `yaml:"fs"`
	Proc    ProcConfig    `yaml:"proc"`
}

type AgentConfig struct {
	Type       string `yaml:"type"`        // client_machine | linux_machine | windows_machine
	Version    string `yaml:"version"`
	CTFEventID string `yaml:"ctf_event_id"`
	MachineID  string `yaml:"machine_id"`
	PlayerID   string `yaml:"player_id,omitempty"`
}

type StorageConfig struct {
	BasePath      string `yaml:"base_path"`
	FilesPath     string `yaml:"files_path"`
	MaxSizeGB     int    `yaml:"max_size_gb"`
	Compression   bool   `yaml:"compression"`
	RotateSizeMB  int    `yaml:"rotate_size_mb"`
	FlushInterval int    `yaml:"flush_interval_ms"`
}

type ExportConfig struct {
	OutputPath       string `yaml:"output_path"`
	AutoExportOnStop bool   `yaml:"auto_export_on_stop"`
	Encrypt          bool   `yaml:"encrypt"`
	EncryptionKey    string `yaml:"encryption_key,omitempty"`
}

type ShellConfig struct {
	Enabled        bool  `yaml:"enabled"`
	MaxStdoutBytes int64 `yaml:"max_stdout_bytes"`
	MaxStderrBytes int64 `yaml:"max_stderr_bytes"`
}

type NetConfig struct {
	Enabled    bool     `yaml:"enabled"`
	Interfaces []string `yaml:"interfaces"`
	BPFFilter  string   `yaml:"bpf_filter,omitempty"`
	CaptureDNS bool     `yaml:"capture_dns"`
}

type BrowserConfig struct {
	Enabled          bool   `yaml:"enabled"`
	MitmproxyPort    int    `yaml:"mitmproxy_port"`
	MaxBodyPreview   int64  `yaml:"max_body_preview_bytes"`
	OutputSocketPath string `yaml:"output_socket_path"`
}

type FSConfig struct {
	Enabled        bool     `yaml:"enabled"`
	WatchPaths     []string `yaml:"watch_paths"`
	ExcludePaths   []string `yaml:"exclude_paths"`
	MaxPreviewSize int64    `yaml:"max_preview_size_bytes"`
	CopyFiles      bool     `yaml:"copy_files"`
}

type ProcConfig struct {
	Enabled      bool `yaml:"enabled"`
	UseAuditd    bool `yaml:"use_auditd"`
	PollInterval int  `yaml:"poll_interval_ms"`
}

// Load reads and parses config from the given YAML file path.
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %s: %w", path, err)
	}

	cfg := &Config{}
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}

	if err := cfg.validate(); err != nil {
		return nil, fmt.Errorf("config validation: %w", err)
	}

	cfg.setDefaults()
	return cfg, nil
}

func (c *Config) validate() error {
	if c.Agent.CTFEventID == "" {
		return fmt.Errorf("agent.ctf_event_id is required")
	}
	if c.Agent.MachineID == "" {
		return fmt.Errorf("agent.machine_id is required")
	}
	if c.Agent.Type == "" {
		return fmt.Errorf("agent.type is required")
	}
	if c.Storage.BasePath == "" {
		return fmt.Errorf("storage.base_path is required")
	}
	return nil
}

func (c *Config) setDefaults() {
	if c.Agent.Version == "" {
		c.Agent.Version = "1.0"
	}
	if c.Storage.MaxSizeGB == 0 {
		c.Storage.MaxSizeGB = 10
	}
	if c.Storage.RotateSizeMB == 0 {
		c.Storage.RotateSizeMB = 100
	}
	if c.Storage.FlushInterval == 0 {
		c.Storage.FlushInterval = 1000 // 1 second
	}
	if c.Storage.FilesPath == "" {
		c.Storage.FilesPath = "/home/iron/files"
	}
	if c.Export.OutputPath == "" {
		c.Export.OutputPath = "/home/iron/exports"
	}

	// Shell defaults
	if c.Shell.MaxStdoutBytes == 0 {
		c.Shell.MaxStdoutBytes = 65536 // 64KB
	}
	if c.Shell.MaxStderrBytes == 0 {
		c.Shell.MaxStderrBytes = 65536
	}

	// Net defaults
	if len(c.Net.Interfaces) == 0 {
		c.Net.Interfaces = []string{"eth0"}
	}

	// Browser defaults
	if c.Browser.MitmproxyPort == 0 {
		c.Browser.MitmproxyPort = 8080
	}
	if c.Browser.MaxBodyPreview == 0 {
		c.Browser.MaxBodyPreview = 4096 // 4KB
	}
	if c.Browser.OutputSocketPath == "" {
		c.Browser.OutputSocketPath = "/home/iron/mitmproxy.sock"
	}

	// FS defaults
	if len(c.FS.WatchPaths) == 0 {
		c.FS.WatchPaths = []string{"/home", "/tmp", "/var/tmp", "/opt"}
	}
	if c.FS.MaxPreviewSize == 0 {
		c.FS.MaxPreviewSize = 2048 // 2KB
	}

	// Proc defaults
	if c.Proc.PollInterval == 0 {
		c.Proc.PollInterval = 500
	}
}
