#!/bin/bash
# ============================================================================
# Cyber Polygon — cp-collector shell hook for Bash
# Installed to: /etc/profile.d/cp-collector-hook.sh
# Captures: command text, CWD, exit code, stdout/stderr preview, timing
# Sends: JSON event to cp-collector via UNIX socket
# ============================================================================

# Guard: don't load twice, skip for non-interactive shells, skip for iron user
[[ -n "$__CP_HOOK_LOADED" ]] && return
[[ $- != *i* ]] && return
[[ "$(whoami)" == "iron" ]] && return
export __CP_HOOK_LOADED=1

__CP_SOCKET="/home/iron/shell_watcher.sock"
__CP_MAX_OUTPUT=65536  # 64KB max captured output
__CP_TEMP_DIR="/tmp/.cp-collector-$$"

# Create temp directory for this shell session
mkdir -p "$__CP_TEMP_DIR" 2>/dev/null
chmod 700 "$__CP_TEMP_DIR" 2>/dev/null

# --- Helper: send JSON to socket ---
__cp_send() {
    local json="$1"
    if [[ -S "$__CP_SOCKET" ]]; then
        echo "$json" | socat - UNIX-CONNECT:"$__CP_SOCKET" 2>/dev/null &
        disown 2>/dev/null
    fi
}

# --- Helper: get timestamp in ISO 8601 with milliseconds ---
__cp_timestamp() {
    date -u +"%Y-%m-%dT%H:%M:%S.%3NZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ"
}

# --- Helper: truncate string to max bytes ---
__cp_truncate() {
    local input="$1"
    local max="$2"
    if [[ ${#input} -gt $max ]]; then
        echo "${input:0:$max}"
    else
        echo "$input"
    fi
}

# --- Helper: escape string for JSON ---
__cp_json_escape() {
    local str="$1"
    str="${str//\\/\\\\}"
    str="${str//\"/\\\"}"
    str="${str//$'\n'/\\n}"
    str="${str//$'\r'/\\r}"
    str="${str//$'\t'/\\t}"
    # Remove control characters
    str=$(echo -n "$str" | tr -d '\000-\010\013\014\016-\037')
    echo -n "$str"
}

# --- Pre-execution hook ---
# Using PROMPT_COMMAND + DEBUG trap approach for Bash
__cp_preexec_cmd=""
__cp_preexec_ts=""
__cp_stdout_file=""
__cp_stderr_file=""

__cp_preexec() {
    # Skip if this is triggered by PROMPT_COMMAND itself
    [[ -n "$COMP_LINE" ]] && return
    [[ "$BASH_COMMAND" == "__cp_precmd" ]] && return
    [[ "$BASH_COMMAND" == __cp_* ]] && return

    # Capture only the first command in a pipeline/compound
    if [[ -z "$__cp_preexec_cmd" ]]; then
        __cp_preexec_cmd="$(history 1 | sed 's/^[ ]*[0-9]*[ ]*//')"
        __cp_preexec_ts="$(__cp_timestamp)"
        __cp_preexec_start=$(date +%s%3N 2>/dev/null || echo 0)

        # Set up output capture files
        __cp_stdout_file="$__CP_TEMP_DIR/stdout.$$"
        __cp_stderr_file="$__CP_TEMP_DIR/stderr.$$"
    fi
}
trap '__cp_preexec' DEBUG

# --- Post-execution hook (runs before each prompt) ---
__cp_precmd() {
    local last_exit=$?

    # Skip if no command was captured
    [[ -z "$__cp_preexec_cmd" ]] && return

    local cmd="$__cp_preexec_cmd"
    local ts_start="$__cp_preexec_ts"
    local ts_end="$(__cp_timestamp)"

    # Calculate duration
    local end_ms=$(date +%s%3N 2>/dev/null || echo 0)
    local duration_ms=0
    if [[ "$__cp_preexec_start" -gt 0 && "$end_ms" -gt 0 ]]; then
        duration_ms=$((end_ms - __cp_preexec_start))
    fi

    # Get stdout/stderr from capture files (if they exist)
    local stdout_preview=""
    local stdout_size=0
    local stderr_preview=""
    local stderr_size=0

    if [[ -f "$__cp_stdout_file" ]]; then
        stdout_size=$(stat -c%s "$__cp_stdout_file" 2>/dev/null || echo 0)
        stdout_preview=$(__cp_truncate "$(head -c $__CP_MAX_OUTPUT "$__cp_stdout_file" 2>/dev/null)" $__CP_MAX_OUTPUT)
        rm -f "$__cp_stdout_file" 2>/dev/null
    fi
    if [[ -f "$__cp_stderr_file" ]]; then
        stderr_size=$(stat -c%s "$__cp_stderr_file" 2>/dev/null || echo 0)
        stderr_preview=$(__cp_truncate "$(head -c $__CP_MAX_OUTPUT "$__cp_stderr_file" 2>/dev/null)" $__CP_MAX_OUTPUT)
        rm -f "$__cp_stderr_file" 2>/dev/null
    fi

    # Escape for JSON
    local cmd_esc="$(__cp_json_escape "$cmd")"
    local cwd_esc="$(__cp_json_escape "$PWD")"
    local stdout_esc="$(__cp_json_escape "$stdout_preview")"
    local stderr_esc="$(__cp_json_escape "$stderr_preview")"
    local tty_val="$(tty 2>/dev/null || echo unknown)"

    # Build JSON
    local json
    json=$(cat <<-ENDJSON
{"command":"${cmd_esc}","cwd":"${cwd_esc}","shell":"bash","pid":$$,"tty":"${tty_val}","timestamp_start":"${ts_start}","timestamp_end":"${ts_end}","exit_code":${last_exit},"stdout":"${stdout_esc}","stdout_size":${stdout_size},"stderr":"${stderr_esc}","stderr_size":${stderr_size},"duration_ms":${duration_ms}}
ENDJSON
)

    __cp_send "$json"

    # Reset
    __cp_preexec_cmd=""
    __cp_preexec_ts=""
    __cp_preexec_start=""
}
PROMPT_COMMAND="__cp_precmd${PROMPT_COMMAND:+; $PROMPT_COMMAND}"

# Cleanup on exit
__cp_cleanup() {
    rm -rf "$__CP_TEMP_DIR" 2>/dev/null
}
trap '__cp_cleanup' EXIT
