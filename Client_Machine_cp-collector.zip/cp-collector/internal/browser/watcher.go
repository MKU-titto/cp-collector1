package browser

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher перехоплює HTTP/HTTPS трафік браузера через mitmproxy в transparent mode.
//
// Архітектура:
//   1. Генерує Python-аддон для mitmproxy (cp_addon.py)
//   2. Запускає mitmdump --mode transparent з цим аддоном
//   3. Аддон при кожному HTTP response надсилає JSON через UNIX socket
//   4. Go-код приймає з'єднання, парсить JSON, записує в JSONL storage
//
// Для роботи transparent proxy потрібні iptables правила:
//   iptables -t nat -A OUTPUT -p tcp --dport 80 -m owner ! --uid-owner iron -j REDIRECT --to-port 8080
//   iptables -t nat -A OUTPUT -p tcp --dport 443 -m owner ! --uid-owner iron -j REDIRECT --to-port 8080
//   (встановлюються install.sh)
//
// Що збирається для AI-тренування:
//   - Які веб-ресурси учасник досліджує (URL, referer chain)
//   - Які запити надсилає (method, body preview — форми, API calls)
//   - Які відповіді отримує (status, content type, body preview)
//   - Latency кожного запиту
//   - TLS статус (HTTP vs HTTPS)
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	socketPath string
	addonPath  string
	mitmCmd    *exec.Cmd
	listener   net.Listener
	wg         sync.WaitGroup
}

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	watcherDir := filepath.Join(cfg.Storage.BasePath, "browser-watcher")
	return &Watcher{
		cfg:        cfg,
		writer:     writer,
		socketPath: cfg.Browser.SocketPath,
		addonPath:  filepath.Join(watcherDir, "cp_addon.py"),
	}
}

func (w *Watcher) Name() string { return "browser-watcher" }

func (w *Watcher) Start(ctx context.Context) error {
	// Гарантуємо директорії
	watcherDir := filepath.Dir(w.socketPath)
	if err := os.MkdirAll(watcherDir, 0750); err != nil {
		return fmt.Errorf("create watcher dir: %w", err)
	}

	// Перевіряємо наявність mitmdump
	if _, err := exec.LookPath("mitmdump"); err != nil {
		return fmt.Errorf("mitmdump not found in PATH: %w (install: pip3 install mitmproxy)", err)
	}

	// Генеруємо Python аддон
	if err := w.writeAddonScript(); err != nil {
		return fmt.Errorf("write addon script: %w", err)
	}

	// Видаляємо stale socket
	os.Remove(w.socketPath)

	// Запускаємо UNIX socket listener ДО mitmproxy (щоб аддон міг підключитись)
	ln, err := net.Listen("unix", w.socketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", w.socketPath, err)
	}
	if err := os.Chmod(w.socketPath, 0660); err != nil {
		ln.Close()
		return fmt.Errorf("chmod socket: %w", err)
	}
	w.listener = ln

	// Запускаємо mitmproxy
	w.mitmCmd = exec.CommandContext(ctx,
		"mitmdump",
		"--mode", "transparent",
		"--showhost",
		"--set", fmt.Sprintf("listen_port=%d", w.cfg.Browser.MitmproxyPort),
		"-s", w.addonPath,
		"--quiet",
	)
	w.mitmCmd.Stdout = nil // Не пишемо stdout mitmproxy
	w.mitmCmd.Stderr = nil

	if err := w.mitmCmd.Start(); err != nil {
		ln.Close()
		return fmt.Errorf("start mitmproxy: %w", err)
	}

	log.Printf("mitmproxy started (port=%d, pid=%d)", w.cfg.Browser.MitmproxyPort, w.mitmCmd.Process.Pid)

	// Приймаємо з'єднання від аддону
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				select {
				case <-ctx.Done():
					return
				default:
					log.Printf("accept: %v", err)
					continue
				}
			}
			w.wg.Add(1)
			go w.handleConnection(ctx, conn)
		}
	}()

	// Чекаємо на завершення mitmproxy або context cancel
	mitmDone := make(chan error, 1)
	go func() {
		mitmDone <- w.mitmCmd.Wait()
	}()

	select {
	case <-ctx.Done():
		return nil
	case err := <-mitmDone:
		if err != nil && ctx.Err() == nil {
			return fmt.Errorf("mitmproxy exited unexpectedly: %w", err)
		}
		return nil
	}
}

func (w *Watcher) Stop() error {
	// Зупиняємо mitmproxy
	if w.mitmCmd != nil && w.mitmCmd.Process != nil {
		log.Printf("stopping mitmproxy (pid=%d)...", w.mitmCmd.Process.Pid)
		w.mitmCmd.Process.Signal(os.Interrupt)

		// Даємо 5 секунд на graceful shutdown
		done := make(chan struct{})
		go func() {
			w.mitmCmd.Wait()
			close(done)
		}()

		select {
		case <-done:
		case <-time.After(5 * time.Second):
			log.Printf("mitmproxy did not stop gracefully, killing")
			w.mitmCmd.Process.Kill()
		}
	}

	// Закриваємо socket listener
	if w.listener != nil {
		w.listener.Close()
	}

	// Чекаємо завершення всіх handler goroutines
	w.wg.Wait()

	// Cleanup
	os.Remove(w.socketPath)
	os.Remove(w.addonPath)

	log.Printf("stopped")
	return nil
}

// ============================================================================
// Socket connection handler
// ============================================================================

// handleConnection обробляє з'єднання від mitmproxy аддону.
// Аддон може переперіключатись або створювати нове з'єднання при помилці.
func (w *Watcher) handleConnection(ctx context.Context, conn net.Conn) {
	defer w.wg.Done()
	defer conn.Close()

	scanner := bufio.NewScanner(conn)
	// HTTP body preview може бути великим
	scanner.Buffer(make([]byte, 0, 128*1024), 128*1024)

	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return
		default:
		}

		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}

		var raw addonEvent
		if err := json.Unmarshal(line, &raw); err != nil {
			log.Printf("unmarshal: %v (data: %.100s)", err, string(line))
			continue
		}

		event := w.buildEvent(raw)
		if err := w.writer.Write(event); err != nil {
			log.Printf("write: %v", err)
		}
	}

	if err := scanner.Err(); err != nil {
		log.Printf("scanner: %v", err)
	}
}

// ============================================================================
// Event building
// ============================================================================

// addonEvent — JSON-структура яку надсилає Python аддон.
type addonEvent struct {
	Method              string `json:"method"`
	URL                 string `json:"url"`
	Referer             string `json:"referer"`
	RequestBodyPreview  string `json:"request_body_preview"`
	RequestBodySize     int64  `json:"request_body_size"`
	ResponseStatus      int    `json:"response_status"`
	ResponseContentType string `json:"response_content_type"`
	ResponseBodyPreview string `json:"response_body_preview"`
	ResponseSize        int64  `json:"response_size"`
	LatencyMs           int64  `json:"latency_ms"`
	TLS                 bool   `json:"tls"`
	Timestamp           string `json:"timestamp"`
}

func (w *Watcher) buildEvent(raw addonEvent) types.BrowserRequestEvent {
	ts := raw.Timestamp
	if ts == "" {
		ts = time.Now().UTC().Format(time.RFC3339Nano)
	}

	// Обрізаємо body preview до налаштованого максимуму
	maxPreview := w.cfg.Browser.MaxBodyPreview
	reqBody := truncate(raw.RequestBodyPreview, maxPreview)
	respBody := truncate(raw.ResponseBodyPreview, maxPreview)

	return types.BrowserRequestEvent{
		Type:                "browser_request",
		Timestamp:           ts,
		MachineID:           w.cfg.Agent.MachineID,
		PlayerID:            w.cfg.Agent.PlayerID,
		CTFEventID:          w.cfg.Agent.CTFEventID,
		Method:              raw.Method,
		URL:                 raw.URL,
		Referer:             raw.Referer,
		RequestBodyPreview:  reqBody,
		RequestBodySize:     raw.RequestBodySize,
		ResponseStatus:      raw.ResponseStatus,
		ResponseContentType: raw.ResponseContentType,
		ResponseBodyPreview: respBody,
		ResponseSize:        raw.ResponseSize,
		LatencyMs:           raw.LatencyMs,
		TLS:                 raw.TLS,
	}
}

func truncate(s string, maxBytes int64) string {
	if maxBytes <= 0 || int64(len(s)) <= maxBytes {
		return s
	}
	return s[:maxBytes]
}

// ============================================================================
// Python addon generator
// ============================================================================

// writeAddonScript генерує Python-аддон для mitmproxy.
//
// Аддон підключається до нашого UNIX socket та надсилає JSON на кожен HTTP response.
// Реалізує auto-reconnect якщо socket тимчасово недоступний.
// Фільтрує бінарний контент — response body preview тільки для text/* та json.
func (w *Watcher) writeAddonScript() error {
	script := fmt.Sprintf(`"""
Cyber Polygon cp-collector — mitmproxy addon
Captures HTTP/HTTPS flows and sends JSON events to browser-watcher via UNIX socket.
Auto-generated. Do not edit manually.
"""
import json
import socket
import time
import os
from mitmproxy import http, ctx

SOCKET_PATH = "%s"
MAX_BODY_PREVIEW = %d
RECONNECT_INTERVAL = 2  # seconds

class CpCollectorAddon:
    def __init__(self):
        self.sock = None
        self.last_connect_attempt = 0

    def _connect(self):
        """Connect to browser-watcher UNIX socket with rate limiting."""
        now = time.time()
        if now - self.last_connect_attempt < RECONNECT_INTERVAL:
            return
        self.last_connect_attempt = now

        try:
            if self.sock:
                try:
                    self.sock.close()
                except Exception:
                    pass
            self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self.sock.settimeout(2.0)
            self.sock.connect(SOCKET_PATH)
            ctx.log.info("cp-collector: connected to browser-watcher")
        except Exception as e:
            self.sock = None

    def _send(self, data: dict):
        """Send JSON event to socket. Reconnect on failure."""
        if not self.sock:
            self._connect()
        if not self.sock:
            return

        try:
            line = json.dumps(data, ensure_ascii=False) + "\n"
            self.sock.sendall(line.encode("utf-8"))
        except (BrokenPipeError, ConnectionResetError, OSError, socket.timeout):
            self.sock = None
            self._connect()

    def response(self, flow: http.HTTPFlow):
        """Called by mitmproxy when a complete HTTP response is received."""
        try:
            request = flow.request
            response = flow.response
            if not response:
                return

            # Request body preview
            req_body = ""
            req_body_size = 0
            if request.content:
                req_body_size = len(request.content)
                try:
                    req_body = request.content[:MAX_BODY_PREVIEW].decode("utf-8", errors="replace")
                except Exception:
                    req_body = ""

            # Response body preview — тільки текстові типи
            resp_body = ""
            resp_size = 0
            if response.content:
                resp_size = len(response.content)
                content_type = response.headers.get("content-type", "")
                text_types = ("text/", "json", "xml", "javascript", "html", "css")
                if any(t in content_type for t in text_types):
                    try:
                        resp_body = response.content[:MAX_BODY_PREVIEW].decode("utf-8", errors="replace")
                    except Exception:
                        resp_body = ""

            # Latency
            latency_ms = 0
            if hasattr(flow, "response") and flow.response:
                ts_start = getattr(flow.request, "timestamp_start", 0)
                ts_end = getattr(flow.response, "timestamp_end", 0)
                if ts_start and ts_end:
                    latency_ms = int((ts_end - ts_start) * 1000)

            event = {
                "method": request.method,
                "url": request.pretty_url,
                "referer": request.headers.get("referer", ""),
                "request_body_preview": req_body,
                "request_body_size": req_body_size,
                "response_status": response.status_code,
                "response_content_type": response.headers.get("content-type", ""),
                "response_body_preview": resp_body,
                "response_size": resp_size,
                "latency_ms": latency_ms,
                "tls": request.scheme == "https",
                "timestamp": time.strftime("%%Y-%%m-%%dT%%H:%%M:%%S.000Z", time.gmtime()),
            }
            self._send(event)
        except Exception as e:
            ctx.log.warn(f"cp-collector addon error: {e}")

addons = [CpCollectorAddon()]
`, w.socketPath, w.cfg.Browser.MaxBodyPreview)

	addonDir := filepath.Dir(w.addonPath)
	if err := os.MkdirAll(addonDir, 0750); err != nil {
		return fmt.Errorf("create addon dir: %w", err)
	}

	return os.WriteFile(w.addonPath, []byte(script), 0644)
}
