package syscallmon

import (
	"bufio"
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher відстежує цільові системні виклики через eBPF tracepoints.
//
// Архітектура:
//   1. Завантажує eBPF програму з .o файлу (syscall.c)
//   2. Підключає tracepoints для кожного syscall зі списку types.TargetSyscalls
//   3. eBPF фільтрує по UID (пропускає iron та root=0 процеси cp-collector)
//   4. Events приходять через ring buffer → Go формує SyscallEvent
//
// Що збирається для AI-тренування:
//   - connect() — куди учасник підключається (IP:port)
//   - bind() — які порти відкриває (reverse shell listener)
//   - execve() — які бінарники запускає (точніше за /proc polling)
//   - openat() — які файли відкриває
//   - mmap/mprotect() — маніпуляції з пам'яттю (shellcode, RWX)
//   - ptrace() — debug/injection
//   - setuid() — privilege escalation
//
// Покращення порівняно з v1:
//   - Динамічний UID iron через eBPF map (не хардкоджений #define)
//   - Rate limiting в userspace (drop events при перевантаженні)
//   - Comm-based фільтрація (пропускає cp-collector-* процеси)
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	collection *ebpf.Collection
	links      []link.Link
	reader     *ringbuf.Reader

	ironUID int

	// Rate limiting — якщо events приходять швидше ніж можемо обробляти
	dropCount uint64
}

// ebpfSyscallEvent відповідає C-структурі struct syscall_event у syscall.c.
type ebpfSyscallEvent struct {
	PID         uint32
	TID         uint32
	UID         uint32
	SyscallNr   uint32
	RetVal      int64
	TimestampNs uint64
	Comm        [16]byte
	Arg0        uint64
	Arg1        uint64
	Arg2        uint64
}

// Syscall number → name mapping (x86_64).
var syscallNames = map[uint32]string{
	0: "read", 1: "write", 2: "open", 3: "close",
	9: "mmap", 10: "mprotect", 41: "socket",
	42: "connect", 49: "bind", 56: "clone",
	57: "fork", 59: "execve", 101: "ptrace",
	105: "setuid", 257: "openat",
}

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	return &Watcher{
		cfg:     cfg,
		writer:  writer,
		ironUID: lookupUID("iron"),
	}
}

func (w *Watcher) Name() string { return "syscall-monitor" }

func (w *Watcher) Start(ctx context.Context) error {
	ebpfPath := w.cfg.Syscall.EbpfObjectPath

	if _, err := os.Stat(ebpfPath); err != nil {
		return fmt.Errorf("eBPF object not found at %s: %w (compile with: make ebpf)", ebpfPath, err)
	}

	// Завантажуємо eBPF
	spec, err := ebpf.LoadCollectionSpec(ebpfPath)
	if err != nil {
		return fmt.Errorf("load eBPF spec from %s: %w", ebpfPath, err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}
	w.collection = coll

	// Записуємо UID iron в eBPF map для фільтрації в ядрі
	if err := w.setFilterUID(coll); err != nil {
		log.Printf("set filter UID: %v (filtering in userspace only)", err)
	}

	// Підключаємо tracepoints
	for _, syscallName := range types.TargetSyscalls {
		enterName := fmt.Sprintf("sys_enter_%s", syscallName)
		progKey := fmt.Sprintf("tracepoint__syscalls__%s", enterName)

		prog, ok := coll.Programs[progKey]
		if !ok {
			log.Printf("no eBPF program for %s, skipping", syscallName)
			continue
		}

		l, err := link.Tracepoint("syscalls", enterName, prog, nil)
		if err != nil {
			log.Printf("attach %s: %v (skipping)", enterName, err)
			continue
		}
		w.links = append(w.links, l)
		log.Printf("attached tracepoint syscalls/%s", enterName)
	}

	if len(w.links) == 0 {
		return fmt.Errorf("no tracepoints attached")
	}

	// Ring buffer
	eventsMap, ok := coll.Maps["syscall_events"]
	if !ok {
		return fmt.Errorf("eBPF map 'syscall_events' not found")
	}

	rd, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ringbuf reader: %w", err)
	}
	w.reader = rd

	log.Printf("started (%d tracepoints, iron_uid=%d)", len(w.links), w.ironUID)

	go w.readEvents(ctx)

	<-ctx.Done()
	return nil
}

func (w *Watcher) Stop() error {
	if w.reader != nil {
		w.reader.Close()
	}
	for _, l := range w.links {
		l.Close()
	}
	if w.collection != nil {
		w.collection.Close()
	}
	if w.dropCount > 0 {
		log.Printf("dropped %d events due to rate limiting", w.dropCount)
	}
	log.Printf("stopped")
	return nil
}

// setFilterUID записує UID iron в eBPF map для kernel-side фільтрації.
func (w *Watcher) setFilterUID(coll *ebpf.Collection) error {
	m, ok := coll.Maps["filter_config"]
	if !ok {
		return fmt.Errorf("filter_config map not found")
	}

	// key=0 → iron UID
	key := uint32(0)
	val := uint32(w.ironUID)
	return m.Put(key, val)
}

// ============================================================================
// Event reader
// ============================================================================

func (w *Watcher) readEvents(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		record, err := w.reader.Read()
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				continue
			}
		}

		if len(record.RawSample) < int(unsafe.Sizeof(ebpfSyscallEvent{})) {
			continue
		}

		var raw ebpfSyscallEvent
		if err := binary.Read(bytes.NewReader(record.RawSample), binary.LittleEndian, &raw); err != nil {
			continue
		}

		// Userspace фільтрація (backup якщо kernel filter не спрацював)
		if w.shouldFilter(raw) {
			continue
		}

		w.emitEvent(raw)
	}
}

// shouldFilter перевіряє чи event потрібно пропустити.
func (w *Watcher) shouldFilter(raw ebpfSyscallEvent) bool {
	// Пропускаємо kernel threads
	if raw.PID == 0 {
		return true
	}

	// Пропускаємо iron user
	if w.ironUID >= 0 && int(raw.UID) == w.ironUID {
		return true
	}

	// Пропускаємо наші власні процеси
	comm := nullTermStr(raw.Comm[:])
	if strings.HasPrefix(comm, "cp-collector") ||
		strings.HasPrefix(comm, "shell-watch") ||
		strings.HasPrefix(comm, "interactive-") ||
		strings.HasPrefix(comm, "proc-monito") ||
		strings.HasPrefix(comm, "net-sniffer") ||
		strings.HasPrefix(comm, "browser-wat") ||
		strings.HasPrefix(comm, "fs-monitor") ||
		strings.HasPrefix(comm, "syscall-mon") {
		return true
	}

	return false
}

func (w *Watcher) emitEvent(raw ebpfSyscallEvent) {
	syscallName := syscallNames[raw.SyscallNr]
	if syscallName == "" {
		syscallName = fmt.Sprintf("syscall_%d", raw.SyscallNr)
	}

	comm := nullTermStr(raw.Comm[:])
	args := formatArgs(syscallName, raw.Arg0, raw.Arg1, raw.Arg2)

	event := types.SyscallEvent{
		Type:       "syscall",
		Timestamp:  time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:  w.cfg.Agent.MachineID,
		CTFEventID: w.cfg.Agent.CTFEventID,
		PID:        int(raw.PID),
		TID:        int(raw.TID),
		Comm:       comm,
		Syscall:    syscallName,
		Args:       args,
		RetVal:     raw.RetVal,
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write: %v", err)
	}
}

// ============================================================================
// Helpers
// ============================================================================

func nullTermStr(b []byte) string {
	for i, c := range b {
		if c == 0 {
			return string(b[:i])
		}
	}
	return string(b)
}

// formatArgs форматує аргументи syscall у читабельний вигляд.
func formatArgs(name string, a0, a1, a2 uint64) []string {
	switch name {
	case "connect":
		return []string{fmt.Sprintf("fd=%d", a0), fmt.Sprintf("addr_ptr=0x%x", a1), fmt.Sprintf("addrlen=%d", a2)}
	case "bind":
		return []string{fmt.Sprintf("fd=%d", a0), fmt.Sprintf("addr_ptr=0x%x", a1), fmt.Sprintf("addrlen=%d", a2)}
	case "execve":
		return []string{fmt.Sprintf("filename_ptr=0x%x", a0), fmt.Sprintf("argv_ptr=0x%x", a1)}
	case "openat":
		return []string{fmt.Sprintf("dirfd=%d", a0), fmt.Sprintf("filename_ptr=0x%x", a1), fmt.Sprintf("flags=0x%x", a2)}
	case "mmap":
		return []string{fmt.Sprintf("addr=0x%x", a0), fmt.Sprintf("len=%d", a1), fmt.Sprintf("prot=%s", formatMmapProt(a2))}
	case "mprotect":
		return []string{fmt.Sprintf("addr=0x%x", a0), fmt.Sprintf("len=%d", a1), fmt.Sprintf("prot=%s", formatMmapProt(a2))}
	case "ptrace":
		return []string{fmt.Sprintf("request=%s", formatPtraceReq(a0)), fmt.Sprintf("pid=%d", a1)}
	case "setuid":
		return []string{fmt.Sprintf("uid=%d", a0)}
	case "clone":
		return []string{fmt.Sprintf("flags=0x%x", a0)}
	case "fork":
		return nil // Без аргументів
	default:
		return []string{fmt.Sprintf("arg0=0x%x", a0), fmt.Sprintf("arg1=0x%x", a1)}
	}
}

// formatMmapProt форматує mmap/mprotect protection flags.
func formatMmapProt(prot uint64) string {
	var parts []string
	if prot == 0 {
		return "PROT_NONE"
	}
	if prot&0x1 != 0 {
		parts = append(parts, "PROT_READ")
	}
	if prot&0x2 != 0 {
		parts = append(parts, "PROT_WRITE")
	}
	if prot&0x4 != 0 {
		parts = append(parts, "PROT_EXEC")
	}
	if len(parts) == 0 {
		return fmt.Sprintf("0x%x", prot)
	}
	return strings.Join(parts, "|")
}

// formatPtraceReq форматує ptrace request type.
func formatPtraceReq(req uint64) string {
	switch req {
	case 0:
		return "PTRACE_TRACEME"
	case 1:
		return "PTRACE_PEEKTEXT"
	case 2:
		return "PTRACE_PEEKDATA"
	case 4:
		return "PTRACE_POKETEXT"
	case 5:
		return "PTRACE_POKEDATA"
	case 16:
		return "PTRACE_ATTACH"
	case 17:
		return "PTRACE_DETACH"
	case 31:
		return "PTRACE_SEIZE"
	default:
		return fmt.Sprintf("%d", req)
	}
}

// lookupUID знаходить UID по username через /etc/passwd.
func lookupUID(username string) int {
	f, err := os.Open("/etc/passwd")
	if err != nil {
		return -1
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		parts := strings.Split(scanner.Text(), ":")
		if len(parts) >= 3 && parts[0] == username {
			uid, err := strconv.Atoi(parts[2])
			if err != nil {
				return -1
			}
			return uid
		}
	}
	return -1
}
