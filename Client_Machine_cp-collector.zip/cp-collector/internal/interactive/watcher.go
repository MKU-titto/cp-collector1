package interactive

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher перехоплює stdin та stdout інтерактивних REPL-інструментів через eBPF.
//
// Архітектура:
//   1. Завантажує eBPF програму з .o файлу (interactive.c)
//   2. Підключає 4 tracepoints: sys_enter/exit_read + sys_enter/exit_write
//   3. Сканує /proc кожні N секунд, шукає цільові процеси (gdb, msfconsole, python тощо)
//   4. Додає PID знайдених процесів в eBPF map → ядро починає відслідковувати їх stdin/stdout
//   5. Events приходять через ring buffer → Go код збирає байти в рядки
//   6. Корелює input (stdin) з response (stdout) по таймауту 3 сек
//
// Покращення порівняно з v1:
//   - Захоплює stdout/stderr (sys_write fd=1,2) — повний response_preview
//   - Кореляція input→response (раніше response завжди був порожнім)
//   - Динамічний UID iron (не хардкоджений в eBPF)
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	collection *ebpf.Collection
	links      []link.Link
	reader     *ringbuf.Reader

	// Відстеження активних цільових процесів
	mu          sync.RWMutex
	trackedPIDs map[uint32]processInfo

	// Буфери для збирання stdin-рядків по PID
	stdinBufs   map[uint32]*lineBuffer
	stdinBufsMu sync.Mutex

	// Буфер stdout для кореляції з останнім stdin
	stdoutBufs   map[uint32]*responseBuffer
	stdoutBufsMu sync.Mutex

	pidScanTicker *time.Ticker
}

type processInfo struct {
	Name          string
	ParentCommand string
	StartTime     time.Time
}

type lineBuffer struct {
	buf        bytes.Buffer
	lastUpdate time.Time
}

// responseBuffer накопичує stdout після stdin-введення для кореляції.
type responseBuffer struct {
	buf         bytes.Buffer
	lastUpdate  time.Time
	inputLine   string    // Останній stdin-рядок, з яким корелюємо
	inputTime   time.Time // Час останнього stdin
	inputEmitted bool     // Чи вже було відправлено event для цього input
}

// ebpfEvent відповідає C-структурі struct event у interactive.c.
// УВАГА: порядок полів та розміри мають точно відповідати C-коду.
type ebpfEvent struct {
	PID         uint32
	TID         uint32
	FD          uint32
	EventType   uint32    // 0 = stdin read, 1 = stdout/stderr write
	Ret         int64
	TimestampNs uint64
	DataLen     uint32
	_           [4]byte   // padding для вирівнювання
	Comm        [16]byte
	Data        [4096]byte
}

const (
	eventTypeRead  = 0 // stdin (fd=0)
	eventTypeWrite = 1 // stdout/stderr (fd=1,2)
)

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	return &Watcher{
		cfg:         cfg,
		writer:      writer,
		trackedPIDs: make(map[uint32]processInfo),
		stdinBufs:   make(map[uint32]*lineBuffer),
		stdoutBufs:  make(map[uint32]*responseBuffer),
	}
}

func (w *Watcher) Name() string { return "interactive-watcher" }

func (w *Watcher) Start(ctx context.Context) error {
	ebpfPath := w.cfg.Interactive.EbpfObjectPath

	// Перевіряємо що eBPF object файл існує
	if _, err := os.Stat(ebpfPath); err != nil {
		return fmt.Errorf("eBPF object not found at %s: %w (compile with: make ebpf)", ebpfPath, err)
	}

	// Завантажуємо eBPF програму
	spec, err := ebpf.LoadCollectionSpec(ebpfPath)
	if err != nil {
		return fmt.Errorf("load eBPF spec from %s: %w", ebpfPath, err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}
	w.collection = coll

	// Підключаємо 4 tracepoints
	tracepoints := []struct {
		group   string
		name    string
		progKey string
	}{
		{"syscalls", "sys_enter_read", "tracepoint__sys_enter_read"},
		{"syscalls", "sys_exit_read", "tracepoint__sys_exit_read"},
		{"syscalls", "sys_enter_write", "tracepoint__sys_enter_write"},
		{"syscalls", "sys_exit_write", "tracepoint__sys_exit_write"},
	}

	for _, tp := range tracepoints {
		prog, ok := coll.Programs[tp.progKey]
		if !ok {
			log.Printf("eBPF program %s not found, skipping", tp.progKey)
			continue
		}

		l, err := link.Tracepoint(tp.group, tp.name, prog, nil)
		if err != nil {
			return fmt.Errorf("attach %s/%s: %w", tp.group, tp.name, err)
		}
		w.links = append(w.links, l)
		log.Printf("attached tracepoint %s/%s", tp.group, tp.name)
	}

	// Ring buffer reader
	eventsMap, ok := coll.Maps["events"]
	if !ok {
		return fmt.Errorf("eBPF map 'events' not found")
	}

	rd, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ringbuf reader: %w", err)
	}
	w.reader = rd

	log.Printf("eBPF loaded, %d tracepoints attached", len(w.links))

	// Фонові goroutines
	scanInterval := time.Duration(w.cfg.Interactive.ScanIntervalSec) * time.Second
	if scanInterval <= 0 {
		scanInterval = 2 * time.Second
	}
	w.pidScanTicker = time.NewTicker(scanInterval)

	go w.scanTargetProcesses(ctx) // Сканування /proc на цільові процеси
	go w.readEvents(ctx)          // Читання eBPF ring buffer
	go w.flushStaleBuffers(ctx)   // Flush незавершених рядків + response кореляція

	<-ctx.Done()
	return nil
}

func (w *Watcher) Stop() error {
	if w.reader != nil {
		w.reader.Close()
	}
	for _, l := range w.links {
		l.Close()
	}
	if w.collection != nil {
		w.collection.Close()
	}
	if w.pidScanTicker != nil {
		w.pidScanTicker.Stop()
	}
	log.Printf("stopped (tracked %d processes)", len(w.trackedPIDs))
	return nil
}

// ============================================================================
// PID Scanner — шукає цільові інтерактивні процеси в /proc
// ============================================================================

func (w *Watcher) scanTargetProcesses(ctx context.Context) {
	w.doScan() // Одразу при старті

	for {
		select {
		case <-w.pidScanTicker.C:
			w.doScan()
		case <-ctx.Done():
			return
		}
	}
}

func (w *Watcher) doScan() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		log.Printf("scan /proc: %v", err)
		return
	}

	activePIDs := make(map[uint32]bool)
	targetPIDsMap := w.getTargetPIDsMap()
	if targetPIDsMap == nil {
		return
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := strconv.ParseUint(entry.Name(), 10, 32)
		if err != nil {
			continue
		}

		comm := readProcComm(uint32(pid))
		if comm == "" {
			continue
		}

		baseName := filepath.Base(comm)
		if !types.InteractiveTargetProcesses[baseName] {
			continue
		}

		pidU32 := uint32(pid)
		activePIDs[pidU32] = true

		w.mu.RLock()
		_, exists := w.trackedPIDs[pidU32]
		w.mu.RUnlock()

		if !exists {
			cmdline := readProcCmdline(pidU32)

			// Додаємо PID в eBPF map — ядро почне відслідковувати цей процес
			val := uint8(1)
			if err := targetPIDsMap.Put(pidU32, val); err != nil {
				log.Printf("add PID %d to eBPF map: %v", pid, err)
				continue
			}

			w.mu.Lock()
			w.trackedPIDs[pidU32] = processInfo{
				Name:          baseName,
				ParentCommand: cmdline,
				StartTime:     time.Now(),
			}
			w.mu.Unlock()

			log.Printf("tracking PID %d (%s): %s", pid, baseName, cmdline)
		}
	}

	// Видаляємо мертві PID
	w.mu.Lock()
	for pid := range w.trackedPIDs {
		if !activePIDs[pid] {
			targetPIDsMap.Delete(pid)
			delete(w.trackedPIDs, pid)

			// Очищаємо буфери
			w.stdinBufsMu.Lock()
			delete(w.stdinBufs, pid)
			w.stdinBufsMu.Unlock()

			w.stdoutBufsMu.Lock()
			delete(w.stdoutBufs, pid)
			w.stdoutBufsMu.Unlock()

			log.Printf("removed dead PID %d", pid)
		}
	}
	w.mu.Unlock()
}

func (w *Watcher) getTargetPIDsMap() *ebpf.Map {
	if w.collection == nil {
		return nil
	}
	m, ok := w.collection.Maps["target_pids"]
	if !ok {
		return nil
	}
	return m
}

// ============================================================================
// Event Reader — обробляє eBPF ring buffer events
// ============================================================================

func (w *Watcher) readEvents(ctx context.Context) {
	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		record, err := w.reader.Read()
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				log.Printf("ringbuf read: %v", err)
				continue
			}
		}

		if len(record.RawSample) < int(unsafe.Sizeof(ebpfEvent{})) {
			continue
		}

		var event ebpfEvent
		if err := binary.Read(bytes.NewReader(record.RawSample), binary.LittleEndian, &event); err != nil {
			log.Printf("decode event: %v", err)
			continue
		}

		switch event.EventType {
		case eventTypeRead:
			w.handleStdinEvent(event)
		case eventTypeWrite:
			w.handleStdoutEvent(event)
		}
	}
}

// handleStdinEvent — обробляє stdin дані (те що користувач ввів).
func (w *Watcher) handleStdinEvent(event ebpfEvent) {
	data := event.Data[:event.DataLen]

	w.stdinBufsMu.Lock()
	lb, ok := w.stdinBufs[event.PID]
	if !ok {
		lb = &lineBuffer{}
		w.stdinBufs[event.PID] = lb
	}
	lb.lastUpdate = time.Now()
	lb.buf.Write(data)
	w.stdinBufsMu.Unlock()

	// Перевіряємо чи є завершені рядки
	w.processStdinLines(event.PID)
}

// handleStdoutEvent — обробляє stdout/stderr дані (відповідь програми).
func (w *Watcher) handleStdoutEvent(event ebpfEvent) {
	data := event.Data[:event.DataLen]

	w.stdoutBufsMu.Lock()
	rb, ok := w.stdoutBufs[event.PID]
	if !ok {
		rb = &responseBuffer{}
		w.stdoutBufs[event.PID] = rb
	}
	rb.lastUpdate = time.Now()
	rb.buf.Write(data)
	w.stdoutBufsMu.Unlock()
}

// processStdinLines — розбиває stdin буфер на рядки по \n та емітить events.
func (w *Watcher) processStdinLines(pid uint32) {
	w.stdinBufsMu.Lock()
	defer w.stdinBufsMu.Unlock()

	lb, ok := w.stdinBufs[pid]
	if !ok {
		return
	}

	content := lb.buf.String()
	if !strings.Contains(content, "\n") && !strings.Contains(content, "\r") {
		return
	}

	lines := strings.Split(content, "\n")
	for i, line := range lines {
		line = strings.TrimRight(line, "\r")

		if i == len(lines)-1 {
			// Останній фрагмент — може бути незавершеним
			lb.buf.Reset()
			lb.buf.WriteString(line)
			break
		}

		if line == "" {
			continue
		}

		// Перед емітом stdin — скидаємо stdout буфер (це response на попередній input)
		w.flushResponseForPID(pid)

		// Зберігаємо input для кореляції з наступним stdout
		w.stdoutBufsMu.Lock()
		rb, ok := w.stdoutBufs[pid]
		if !ok {
			rb = &responseBuffer{}
			w.stdoutBufs[pid] = rb
		}
		rb.buf.Reset()
		rb.inputLine = line
		rb.inputTime = time.Now()
		rb.inputEmitted = false
		w.stdoutBufsMu.Unlock()

		// Емітимо input event (response буде доданий пізніше при flush)
	}
}

// flushResponseForPID — якщо є незавершений input з response, емітить повний event.
func (w *Watcher) flushResponseForPID(pid uint32) {
	w.stdoutBufsMu.Lock()
	rb, ok := w.stdoutBufs[pid]
	if !ok || rb.inputEmitted || rb.inputLine == "" {
		w.stdoutBufsMu.Unlock()
		return
	}

	inputLine := rb.inputLine
	responsePreview := ""
	responseSize := int64(0)

	if rb.buf.Len() > 0 {
		responsePreview = rb.buf.String()
		responseSize = int64(rb.buf.Len())
		// Обмежуємо preview до 4KB
		if len(responsePreview) > 4096 {
			responsePreview = responsePreview[:4096]
		}
	}
	rb.inputEmitted = true
	w.stdoutBufsMu.Unlock()

	w.emitEvent(pid, inputLine, responsePreview, responseSize)
}

// emitEvent — створює та записує InteractiveInputEvent.
func (w *Watcher) emitEvent(pid uint32, inputLine, responsePreview string, responseSize int64) {
	w.mu.RLock()
	info, ok := w.trackedPIDs[pid]
	w.mu.RUnlock()

	if !ok {
		return
	}

	event := types.InteractiveInputEvent{
		Type:            "interactive_input",
		Timestamp:       time.Now().UTC().Format(time.RFC3339Nano),
		SessionID:       fmt.Sprintf("interactive_%d", pid),
		MachineID:       w.cfg.Agent.MachineID,
		PlayerID:        w.cfg.Agent.PlayerID,
		CTFEventID:      w.cfg.Agent.CTFEventID,
		PID:             int(pid),
		ProcessName:     info.Name,
		ParentCommand:   info.ParentCommand,
		InputLine:       inputLine,
		ResponsePreview: responsePreview,
		ResponseSize:    responseSize,
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write: %v", err)
	}
}

// ============================================================================
// Flush — обробляє незавершені буфери по таймауту
// ============================================================================

func (w *Watcher) flushStaleBuffers(ctx context.Context) {
	ticker := time.NewTicker(3 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			w.flushStaleStdin()
			w.flushStaleResponses()
		case <-ctx.Done():
			return
		}
	}
}

// flushStaleStdin — емітить незавершені stdin-рядки після 3 сек без нових даних.
// Це для REPL-ів де команда не завершується \n (наприклад, Ctrl+C).
func (w *Watcher) flushStaleStdin() {
	w.stdinBufsMu.Lock()
	now := time.Now()
	var toEmit []struct {
		pid  uint32
		line string
	}

	for pid, lb := range w.stdinBufs {
		if lb.buf.Len() > 0 && now.Sub(lb.lastUpdate) > 3*time.Second {
			line := strings.TrimSpace(lb.buf.String())
			lb.buf.Reset()
			if line != "" {
				toEmit = append(toEmit, struct {
					pid  uint32
					line string
				}{pid, line})
			}
		}
	}
	w.stdinBufsMu.Unlock()

	// Зберігаємо для кореляції та чекаємо на response
	for _, item := range toEmit {
		w.stdoutBufsMu.Lock()
		rb, ok := w.stdoutBufs[item.pid]
		if !ok {
			rb = &responseBuffer{}
			w.stdoutBufs[item.pid] = rb
		}
		rb.buf.Reset()
		rb.inputLine = item.line
		rb.inputTime = time.Now()
		rb.inputEmitted = false
		w.stdoutBufsMu.Unlock()
	}
}

// flushStaleResponses — емітить input+response коли stdout не оновлювався 3 сек.
func (w *Watcher) flushStaleResponses() {
	w.stdoutBufsMu.Lock()
	now := time.Now()
	var toFlush []uint32

	for pid, rb := range w.stdoutBufs {
		if !rb.inputEmitted && rb.inputLine != "" && now.Sub(rb.inputTime) > 3*time.Second {
			toFlush = append(toFlush, pid)
		}
	}
	w.stdoutBufsMu.Unlock()

	for _, pid := range toFlush {
		w.flushResponseForPID(pid)
	}
}

// ============================================================================
// /proc helpers
// ============================================================================

func readProcComm(pid uint32) string {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}

func readProcCmdline(pid uint32) string {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid))
	if err != nil {
		return ""
	}
	return strings.ReplaceAll(strings.TrimRight(string(data), "\x00"), "\x00", " ")
}
