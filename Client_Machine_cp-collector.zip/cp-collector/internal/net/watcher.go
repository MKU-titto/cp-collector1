package net

import (
	"bufio"
	"context"
	"fmt"
	"log"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher захоплює мережевий трафік через libpcap та генерує події:
//   - network_connection — TCP/UDP flows з connection tracking
//   - dns_query — DNS запити з відповідями
//
// Архітектура:
//   1. Відкриває pcap handle на кожному інтерфейсі з конфігу
//   2. Кожен інтерфейс обробляється в окремій goroutine
//   3. TCP/UDP пакети агрегуються у flows (connection tracking)
//   4. Flow emit відбувається при: FIN/RST, idle timeout 30с, або shutdown
//   5. DNS парсяться окремо — і запит, і відповідь
//
// Покращення порівняно з v1:
//   - Local IP кешується при старті (не сканує interfaces на кожен пакет)
//   - PID resolution з кешем та TTL (не сканує /proc/net/tcp на кожен flow)
//   - IPv6 підтримка
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	handles []*pcap.Handle

	// Flow tracking
	mu    sync.Mutex
	flows map[string]*connFlow

	// Кеш локальних IP (заповнюється при старті)
	localIPs map[string]bool

	// Кеш port→PID (TTL 10 сек)
	pidCacheMu sync.RWMutex
	pidCache   map[int]pidCacheEntry
}

type connFlow struct {
	Protocol  string
	SrcIP     string
	SrcPort   int
	DstIP     string
	DstPort   int
	Direction string
	BytesSent int64
	BytesRecv int64
	StartTime time.Time
	LastSeen  time.Time
	State     string
	PID       int
	Process   string
}

type pidCacheEntry struct {
	PID     int
	Process string
	Expires time.Time
}

const (
	flowIdleTimeout = 30 * time.Second
	flowCheckInterval = 10 * time.Second
	pidCacheTTL     = 10 * time.Second
)

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	return &Watcher{
		cfg:      cfg,
		writer:   writer,
		flows:    make(map[string]*connFlow),
		localIPs: make(map[string]bool),
		pidCache: make(map[int]pidCacheEntry),
	}
}

func (w *Watcher) Name() string { return "net-sniffer" }

func (w *Watcher) Start(ctx context.Context) error {
	// Кешуємо локальні IP адреси
	w.cacheLocalIPs()
	log.Printf("local IPs: %v", w.localIPList())

	// Відкриваємо pcap на кожному інтерфейсі
	for _, iface := range w.cfg.Net.Interfaces {
		handle, err := pcap.OpenLive(iface, 1600, true, pcap.BlockForever)
		if err != nil {
			log.Printf("open %s: %v (skipping)", iface, err)
			continue
		}

		if w.cfg.Net.BPFFilter != "" {
			if err := handle.SetBPFFilter(w.cfg.Net.BPFFilter); err != nil {
				log.Printf("BPF filter on %s: %v", iface, err)
			}
		}

		w.handles = append(w.handles, handle)
		go w.captureInterface(ctx, iface, handle)
		log.Printf("capturing on %s", iface)
	}

	if len(w.handles) == 0 {
		return fmt.Errorf("no interfaces available for capture")
	}

	// Фонова goroutine для expire та emit idle flows
	go w.expireFlows(ctx)

	<-ctx.Done()
	return nil
}

func (w *Watcher) Stop() error {
	for _, h := range w.handles {
		h.Close()
	}

	// Emit всі залишкові flows
	w.mu.Lock()
	for key, flow := range w.flows {
		w.emitFlow(flow)
		delete(w.flows, key)
	}
	w.mu.Unlock()

	log.Printf("stopped")
	return nil
}

// ============================================================================
// Packet capture
// ============================================================================

func (w *Watcher) captureInterface(ctx context.Context, iface string, handle *pcap.Handle) {
	packetSource := gopacket.NewPacketSource(handle, handle.LinkType())
	packetSource.NoCopy = true

	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		packet, err := packetSource.NextPacket()
		if err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				continue
			}
		}

		w.processPacket(packet)
	}
}

func (w *Watcher) processPacket(packet gopacket.Packet) {
	// Витягуємо IP (v4 або v6)
	var srcIP, dstIP string

	if ipLayer := packet.Layer(layers.LayerTypeIPv4); ipLayer != nil {
		ip := ipLayer.(*layers.IPv4)
		srcIP = ip.SrcIP.String()
		dstIP = ip.DstIP.String()
	} else if ipLayer := packet.Layer(layers.LayerTypeIPv6); ipLayer != nil {
		ip := ipLayer.(*layers.IPv6)
		srcIP = ip.SrcIP.String()
		dstIP = ip.DstIP.String()
	} else {
		return // Не IP пакет
	}

	// DNS
	if w.cfg.Net.CaptureDNS {
		if dnsLayer := packet.Layer(layers.LayerTypeDNS); dnsLayer != nil {
			w.processDNS(dnsLayer.(*layers.DNS))
			return
		}
	}

	// TCP
	if tcpLayer := packet.Layer(layers.LayerTypeTCP); tcpLayer != nil {
		tcp := tcpLayer.(*layers.TCP)
		w.trackTCPFlow(srcIP, dstIP, tcp, len(packet.Data()))
		return
	}

	// UDP (не DNS)
	if udpLayer := packet.Layer(layers.LayerTypeUDP); udpLayer != nil {
		udp := udpLayer.(*layers.UDP)
		w.trackUDPFlow(srcIP, dstIP, udp, len(packet.Data()))
	}
}

// ============================================================================
// TCP flow tracking
// ============================================================================

func (w *Watcher) trackTCPFlow(srcIP, dstIP string, tcp *layers.TCP, packetLen int) {
	srcPort := int(tcp.SrcPort)
	dstPort := int(tcp.DstPort)

	key := flowKey("tcp", srcIP, srcPort, dstIP, dstPort)
	reverseKey := flowKey("tcp", dstIP, dstPort, srcIP, srcPort)

	// TCP state
	state := "ESTABLISHED"
	if tcp.SYN && !tcp.ACK {
		state = "SYN_SENT"
	} else if tcp.SYN && tcp.ACK {
		state = "SYN_ACK"
	} else if tcp.FIN {
		state = "FIN"
	} else if tcp.RST {
		state = "RST"
	}

	// Direction
	direction := w.classifyDirection(srcIP, dstIP)

	w.mu.Lock()
	defer w.mu.Unlock()

	flow, exists := w.flows[key]
	if !exists {
		flow, exists = w.flows[reverseKey]
	}

	if !exists {
		// Новий flow — резолвимо PID
		pid, procName := w.lookupPID(srcPort)

		flow = &connFlow{
			Protocol:  "TCP",
			SrcIP:     srcIP,
			SrcPort:   srcPort,
			DstIP:     dstIP,
			DstPort:   dstPort,
			Direction: direction,
			StartTime: time.Now(),
			State:     state,
			PID:       pid,
			Process:   procName,
		}
		w.flows[key] = flow
	}

	flow.LastSeen = time.Now()
	flow.State = state

	// Рахуємо байти
	if srcIP == flow.SrcIP {
		flow.BytesSent += int64(packetLen)
	} else {
		flow.BytesRecv += int64(packetLen)
	}

	// Emit при закритті з'єднання
	if tcp.FIN || tcp.RST {
		w.emitFlow(flow)
		delete(w.flows, key)
		delete(w.flows, reverseKey)
	}
}

// ============================================================================
// UDP flow tracking
// ============================================================================

func (w *Watcher) trackUDPFlow(srcIP, dstIP string, udp *layers.UDP, packetLen int) {
	srcPort := int(udp.SrcPort)
	dstPort := int(udp.DstPort)

	// Пропускаємо DNS (обробляється окремо)
	if srcPort == 53 || dstPort == 53 {
		return
	}

	key := flowKey("udp", srcIP, srcPort, dstIP, dstPort)
	direction := w.classifyDirection(srcIP, dstIP)

	w.mu.Lock()
	defer w.mu.Unlock()

	flow, exists := w.flows[key]
	if !exists {
		pid, procName := w.lookupPID(srcPort)

		flow = &connFlow{
			Protocol:  "UDP",
			SrcIP:     srcIP,
			SrcPort:   srcPort,
			DstIP:     dstIP,
			DstPort:   dstPort,
			Direction: direction,
			StartTime: time.Now(),
			State:     "ACTIVE",
			PID:       pid,
			Process:   procName,
		}
		w.flows[key] = flow
	}

	flow.LastSeen = time.Now()
	flow.BytesSent += int64(packetLen)
}

// ============================================================================
// DNS capture
// ============================================================================

func (w *Watcher) processDNS(dns *layers.DNS) {
	// Обробляємо тільки відповіді (QR=true) — вони містять і запит, і answers
	if !dns.QR {
		return
	}

	for _, q := range dns.Questions {
		var answers []string
		for _, a := range dns.Answers {
			if a.IP != nil {
				answers = append(answers, a.IP.String())
			} else if len(a.CNAME) > 0 {
				answers = append(answers, string(a.CNAME))
			}
		}

		event := types.DNSQueryEvent{
			Type:      "dns_query",
			Timestamp: time.Now().UTC().Format(time.RFC3339Nano),
			MachineID: w.cfg.Agent.MachineID,
			CTFEventID: w.cfg.Agent.CTFEventID,
			Domain:    string(q.Name),
			QueryType: q.Type.String(),
			Answers:   answers,
		}

		if err := w.writer.Write(event); err != nil {
			log.Printf("write DNS: %v", err)
		}
	}
}

// ============================================================================
// Flow emit
// ============================================================================

func (w *Watcher) emitFlow(flow *connFlow) {
	duration := flow.LastSeen.Sub(flow.StartTime)

	event := types.NetworkConnectionEvent{
		Type:          "network_connection",
		Timestamp:     flow.StartTime.UTC().Format(time.RFC3339Nano),
		MachineID:     w.cfg.Agent.MachineID,
		PlayerID:      w.cfg.Agent.PlayerID,
		CTFEventID:    w.cfg.Agent.CTFEventID,
		PID:           flow.PID,
		ProcessName:   flow.Process,
		Protocol:      flow.Protocol,
		SrcIP:         flow.SrcIP,
		SrcPort:       flow.SrcPort,
		DstIP:         flow.DstIP,
		DstPort:       flow.DstPort,
		Direction:     flow.Direction,
		State:         flow.State,
		BytesSent:     flow.BytesSent,
		BytesReceived: flow.BytesRecv,
		DurationMs:    duration.Milliseconds(),
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write flow: %v", err)
	}
}

// expireFlows — фонова goroutine яка emit та видаляє idle flows.
func (w *Watcher) expireFlows(ctx context.Context) {
	ticker := time.NewTicker(flowCheckInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ticker.C:
			w.mu.Lock()
			now := time.Now()
			for key, flow := range w.flows {
				if now.Sub(flow.LastSeen) > flowIdleTimeout {
					w.emitFlow(flow)
					delete(w.flows, key)
				}
			}
			w.mu.Unlock()
		case <-ctx.Done():
			return
		}
	}
}

// ============================================================================
// Local IP cache
// ============================================================================

// cacheLocalIPs сканує мережеві інтерфейси один раз при старті.
func (w *Watcher) cacheLocalIPs() {
	ifaces, err := net.Interfaces()
	if err != nil {
		log.Printf("list interfaces: %v", err)
		return
	}
	for _, iface := range ifaces {
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip != nil {
				w.localIPs[ip.String()] = true
			}
		}
	}
}

func (w *Watcher) localIPList() []string {
	var ips []string
	for ip := range w.localIPs {
		ips = append(ips, ip)
	}
	return ips
}

func (w *Watcher) isLocalIP(ip string) bool {
	return w.localIPs[ip]
}

// classifyDirection визначає напрямок з'єднання.
func (w *Watcher) classifyDirection(srcIP, dstIP string) string {
	srcLocal := w.isLocalIP(srcIP)
	dstLocal := w.isLocalIP(dstIP)

	if srcLocal && !dstLocal {
		return "outbound"
	}
	if !srcLocal && dstLocal {
		return "inbound"
	}
	return "local" // Обидва локальні (loopback / LAN)
}

// ============================================================================
// PID resolution з кешем
// ============================================================================

// lookupPID знаходить PID за локальним портом через /proc/net/tcp + /proc/*/fd.
// Результат кешується на 10 секунд.
func (w *Watcher) lookupPID(port int) (int, string) {
	if port <= 0 {
		return 0, ""
	}

	// Перевіряємо кеш
	w.pidCacheMu.RLock()
	entry, ok := w.pidCache[port]
	w.pidCacheMu.RUnlock()

	if ok && time.Now().Before(entry.Expires) {
		return entry.PID, entry.Process
	}

	// Cache miss — скануємо /proc
	pid := findPIDByPort(port)
	procName := ""
	if pid > 0 {
		procName = readComm(pid)
	}

	// Зберігаємо в кеш
	w.pidCacheMu.Lock()
	w.pidCache[port] = pidCacheEntry{
		PID:     pid,
		Process: procName,
		Expires: time.Now().Add(pidCacheTTL),
	}
	w.pidCacheMu.Unlock()

	return pid, procName
}

// ============================================================================
// Helpers
// ============================================================================

func flowKey(proto, srcIP string, srcPort int, dstIP string, dstPort int) string {
	return fmt.Sprintf("%s:%s:%d->%s:%d", proto, srcIP, srcPort, dstIP, dstPort)
}

// findPIDByPort шукає PID який тримає локальний порт через /proc/net/tcp(6).
func findPIDByPort(port int) int {
	portHex := fmt.Sprintf("%04X", port)

	for _, procFile := range []string{"/proc/net/tcp", "/proc/net/tcp6", "/proc/net/udp", "/proc/net/udp6"} {
		f, err := os.Open(procFile)
		if err != nil {
			continue
		}

		scanner := bufio.NewScanner(f)
		scanner.Scan() // skip header
		for scanner.Scan() {
			fields := strings.Fields(scanner.Text())
			if len(fields) < 10 {
				continue
			}
			// local_address формат: IP:PORT (hex)
			localAddr := fields[1]
			parts := strings.Split(localAddr, ":")
			if len(parts) == 2 && parts[1] == portHex {
				inode := fields[9]
				f.Close()
				return findPIDByInode(inode)
			}
		}
		f.Close()
	}
	return 0
}

// findPIDByInode шукає PID по inode socket через /proc/*/fd.
func findPIDByInode(inode string) int {
	if inode == "0" {
		return 0
	}

	target := fmt.Sprintf("socket:[%s]", inode)

	entries, err := os.ReadDir("/proc")
	if err != nil {
		return 0
	}

	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}

		fdPath := fmt.Sprintf("/proc/%d/fd", pid)
		fds, err := os.ReadDir(fdPath)
		if err != nil {
			continue
		}

		for _, fd := range fds {
			link, err := os.Readlink(fmt.Sprintf("%s/%s", fdPath, fd.Name()))
			if err != nil {
				continue
			}
			if link == target {
				return pid
			}
		}
	}
	return 0
}

func readComm(pid int) string {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}
