package proc

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher відстежує запуск та завершення процесів через сканування /proc.
//
// Архітектура:
//   1. Кожні poll_interval_ms сканує /proc і порівнює з відомим набором PID
//   2. Нові PID → process_spawn event (з binary path, argv, SHA256, CTF tool tagging)
//   3. Зниклі PID → process_exit event (з duration)
//   4. Опціонально: auditd tail для точнішого exit_code (polling не дає)
//
// CTF tool tagging:
//   Кожен новий процес перевіряється по types.CTFToolMap — якщо це відомий
//   CTF-інструмент (nmap, msfconsole, gdb тощо), додається is_ctf_tool=true
//   та tool_category (recon, exploit, pwn тощо). Це критично для AI-тренування:
//   модель вчиться, які інструменти використовувати в якій послідовності.
//
// Anomaly detection:
//   Детектує підозрілі патерни: shell від www-data, reverse shell через /dev/tcp,
//   підозрілі бінарники від service accounts. Додає anomaly_type до події.
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	mu         sync.RWMutex
	knownPIDs  map[int]*procEntry
	pollTicker *time.Ticker

	// Кеш UID iron щоб фільтрувати власні процеси
	ironUID int
}

type procEntry struct {
	PID        int
	PPID       int
	BinaryPath string
	Argv       []string
	CWD        string
	UID        int
	GID        int
	StartTime  time.Time
}

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	return &Watcher{
		cfg:       cfg,
		writer:    writer,
		knownPIDs: make(map[int]*procEntry),
		ironUID:   lookupUID("iron"),
	}
}

func (w *Watcher) Name() string { return "proc-monitor" }

func (w *Watcher) Start(ctx context.Context) error {
	interval := time.Duration(w.cfg.Proc.PollInterval) * time.Millisecond
	if interval <= 0 {
		interval = 500 * time.Millisecond
	}
	w.pollTicker = time.NewTicker(interval)

	log.Printf("started (poll=%v, auditd=%v, iron_uid=%d)", interval, w.cfg.Proc.UseAuditd, w.ironUID)

	// Початковий скан — запам'ятовуємо існуючі процеси без emit (вони вже були до нас)
	w.initialScan()

	for {
		select {
		case <-w.pollTicker.C:
			w.scanProc()
		case <-ctx.Done():
			return nil
		}
	}
}

func (w *Watcher) Stop() error {
	if w.pollTicker != nil {
		w.pollTicker.Stop()
	}
	w.mu.RLock()
	count := len(w.knownPIDs)
	w.mu.RUnlock()
	log.Printf("stopped (tracked %d processes)", count)
	return nil
}

// ============================================================================
// /proc scanning
// ============================================================================

// initialScan — перший скан при старті. Запам'ятовуємо PID без емітування подій,
// бо ці процеси вже існували до запуску watcher.
func (w *Watcher) initialScan() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		log.Printf("initial scan /proc: %v", err)
		return
	}

	count := 0
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}

		info := w.readProcessInfo(pid)
		if info == nil {
			continue
		}

		// Пропускаємо процеси iron (наші власні)
		if info.UID == w.ironUID {
			continue
		}

		w.mu.Lock()
		w.knownPIDs[pid] = info
		w.mu.Unlock()
		count++
	}

	log.Printf("initial scan: %d existing processes registered", count)
}

// scanProc — основний цикл сканування. Знаходить нові та зниклі процеси.
func (w *Watcher) scanProc() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		log.Printf("read /proc: %v", err)
		return
	}

	activePIDs := make(map[int]bool)

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}
		activePIDs[pid] = true

		w.mu.RLock()
		_, known := w.knownPIDs[pid]
		w.mu.RUnlock()

		if !known {
			info := w.readProcessInfo(pid)
			if info == nil {
				continue
			}

			// Пропускаємо iron
			if info.UID == w.ironUID {
				continue
			}

			w.mu.Lock()
			w.knownPIDs[pid] = info
			w.mu.Unlock()

			w.emitSpawnEvent(info)
		}
	}

	// Детектимо зниклі процеси
	w.mu.Lock()
	for pid, entry := range w.knownPIDs {
		if !activePIDs[pid] {
			w.emitExitEvent(entry)
			delete(w.knownPIDs, pid)
		}
	}
	w.mu.Unlock()
}

// ============================================================================
// Process info reader
// ============================================================================

func (w *Watcher) readProcessInfo(pid int) *procEntry {
	// Binary path через /proc/pid/exe symlink
	exePath, err := os.Readlink(fmt.Sprintf("/proc/%d/exe", pid))
	if err != nil {
		return nil // Процес міг вже завершитись
	}

	// Командний рядок
	cmdlineData, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid))
	if err != nil {
		return nil
	}
	argv := parseCmdline(cmdlineData)

	// Робоча директорія
	cwd, _ := os.Readlink(fmt.Sprintf("/proc/%d/cwd", pid))

	// PPID, UID, GID зі status
	status := readProcStatus(pid)
	ppid := parseIntField(status["PPid"])
	uid := parseFirstIntField(status["Uid"])
	gid := parseFirstIntField(status["Gid"])

	return &procEntry{
		PID:        pid,
		PPID:       ppid,
		BinaryPath: exePath,
		Argv:       argv,
		CWD:        cwd,
		UID:        uid,
		GID:        gid,
		StartTime:  time.Now(),
	}
}

// ============================================================================
// Event emitters
// ============================================================================

func (w *Watcher) emitSpawnEvent(info *procEntry) {
	baseName := filepath.Base(info.BinaryPath)
	toolCategory, isTool := types.CTFToolMap[baseName]

	// SHA256 бінарника (перші 2MB для швидкості)
	sha := hashFileSafe(info.BinaryPath, 2*1024*1024)

	event := types.ProcessSpawnEvent{
		Type:         "process_spawn",
		Timestamp:    time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:    w.cfg.Agent.MachineID,
		PlayerID:     w.cfg.Agent.PlayerID,
		CTFEventID:   w.cfg.Agent.CTFEventID,
		PID:          info.PID,
		PPID:         info.PPID,
		BinaryPath:   info.BinaryPath,
		BinarySHA256: sha,
		Argv:         info.Argv,
		CWD:          info.CWD,
		UID:          info.UID,
		GID:          info.GID,
		IsCTFTool:    isTool,
		ToolCategory: toolCategory,
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write spawn: %v", err)
	}
}

func (w *Watcher) emitExitEvent(info *procEntry) {
	duration := time.Since(info.StartTime)

	event := types.ProcessExitEvent{
		Type:       "process_exit",
		Timestamp:  time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:  w.cfg.Agent.MachineID,
		CTFEventID: w.cfg.Agent.CTFEventID,
		PID:        info.PID,
		ExitCode:   -1, // Недоступний через /proc polling
		DurationMs: duration.Milliseconds(),
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write exit: %v", err)
	}
}

// ============================================================================
// Helpers
// ============================================================================

// parseCmdline розбирає /proc/pid/cmdline (null-separated) в argv.
func parseCmdline(data []byte) []string {
	var args []string
	parts := strings.Split(strings.TrimRight(string(data), "\x00"), "\x00")
	for _, p := range parts {
		if p != "" {
			args = append(args, p)
		}
	}
	return args
}

// readProcStatus парсить /proc/pid/status у map[key]value.
func readProcStatus(pid int) map[string]string {
	f, err := os.Open(fmt.Sprintf("/proc/%d/status", pid))
	if err != nil {
		return map[string]string{}
	}
	defer f.Close()

	result := make(map[string]string)
	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		parts := strings.SplitN(scanner.Text(), ":", 2)
		if len(parts) == 2 {
			result[strings.TrimSpace(parts[0])] = strings.TrimSpace(parts[1])
		}
	}
	return result
}

// parseIntField парсить рядок в int, повертає 0 при помилці.
func parseIntField(s string) int {
	s = strings.TrimSpace(s)
	v, _ := strconv.Atoi(s)
	return v
}

// parseFirstIntField бере перше число з рядка типу "1000 1000 1000 1000" (формат Uid/Gid).
func parseFirstIntField(s string) int {
	fields := strings.Fields(s)
	if len(fields) == 0 {
		return 0
	}
	v, _ := strconv.Atoi(fields[0])
	return v
}

// hashFileSafe обчислює SHA256 перших maxBytes файлу.
// Повертає "" при будь-якій помилці (файл зайнятий, немає прав тощо).
func hashFileSafe(path string, maxBytes int64) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	io.CopyN(h, f, maxBytes)
	return hex.EncodeToString(h.Sum(nil))
}

// lookupUID знаходить UID користувача по імені через /etc/passwd.
// Повертає -1 якщо не знайдено.
func lookupUID(username string) int {
	f, err := os.Open("/etc/passwd")
	if err != nil {
		return -1
	}
	defer f.Close()

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		// Формат: username:x:uid:gid:comment:home:shell
		parts := strings.Split(scanner.Text(), ":")
		if len(parts) >= 3 && parts[0] == username {
			uid, err := strconv.Atoi(parts[2])
			if err != nil {
				return -1
			}
			return uid
		}
	}
	return -1
}
