package fs

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/fsnotify/fsnotify"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher відстежує файлові операції через inotify (fsnotify).
//
// Архітектура:
//   1. Рекурсивно додає inotify watch на всі директорії з watch_paths
//   2. При створенні нової директорії — автоматично додає watch
//   3. Класифікує файли за розширенням (17+ категорій)
//   4. Обчислює SHA256 для створених/змінених файлів (до 50MB)
//   5. Робить content preview для текстових файлів (до max_preview_size)
//   6. Копіює скрипти (.py, .sh, .php тощо) у copied_files/ для відтворення
//
// Що збирається для AI-тренування:
//   - Які файли учасник створює / модифікує (exploit scripts, конфіги)
//   - Зміст скриптів (content preview + повна копія)
//   - Файлові операції на цільовій системі (upload webshell, зміна конфігу)
//   - Видалення файлів (зачистка слідів)
//
// Покращення порівняно з v1:
//   - Debounce: однакові events протягом 500мс агрегуються (inotify часто шле дублі)
//   - copied_files/ всередині watchers/fs-monitor/ (не в /home/iron/ root)
//   - Не хешує великі файли (>50MB) — запобігає підвисанню на ISO/disk images
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	fsWatcher    *fsnotify.Watcher
	excludeSet   map[string]bool
	copiedDir    string

	// Debounce: path → last event time, щоб агрегувати дублі від inotify
	debounce     map[string]time.Time
}

const (
	maxHashFileSize = 50 * 1024 * 1024  // 50MB — не хешувати більші файли
	maxCopyFileSize = 10 * 1024 * 1024  // 10MB — не копіювати більші файли
	debounceWindow  = 500 * time.Millisecond
)

func New(cfg config.Config, writer *storage.Writer) *Watcher {
	excludeSet := make(map[string]bool)
	for _, p := range cfg.FS.ExcludePaths {
		excludeSet[p] = true
	}
	// Завжди виключаємо наші власні директорії
	excludeSet["/home/iron"] = true

	copiedDir := filepath.Join(cfg.Storage.BasePath, "fs-monitor", "copied_files")

	return &Watcher{
		cfg:        cfg,
		writer:     writer,
		excludeSet: excludeSet,
		copiedDir:  copiedDir,
		debounce:   make(map[string]time.Time),
	}
}

func (w *Watcher) Name() string { return "fs-monitor" }

func (w *Watcher) Start(ctx context.Context) error {
	// Створюємо директорію для копій
	if w.cfg.FS.CopyFiles {
		if err := os.MkdirAll(w.copiedDir, 0750); err != nil {
			log.Printf("create copied_files dir: %v (file copying disabled)", err)
		}
	}

	watcher, err := fsnotify.NewWatcher()
	if err != nil {
		return fmt.Errorf("create inotify watcher: %w", err)
	}
	w.fsWatcher = watcher

	// Рекурсивно додаємо watch paths
	totalDirs := 0
	for _, watchPath := range w.cfg.FS.WatchPaths {
		n := w.addWatchRecursive(watchPath)
		totalDirs += n
	}

	log.Printf("watching %d directories across %d root paths", totalDirs, len(w.cfg.FS.WatchPaths))

	// Основний event loop
	for {
		select {
		case event, ok := <-watcher.Events:
			if !ok {
				return nil
			}
			w.handleEvent(event)

		case err, ok := <-watcher.Errors:
			if !ok {
				return nil
			}
			log.Printf("inotify error: %v", err)

		case <-ctx.Done():
			return nil
		}
	}
}

func (w *Watcher) Stop() error {
	if w.fsWatcher != nil {
		w.fsWatcher.Close()
	}
	log.Printf("stopped")
	return nil
}

// ============================================================================
// Watch management
// ============================================================================

// addWatchRecursive додає inotify watch на root та всі поддиректорії.
// Повертає кількість доданих директорій.
func (w *Watcher) addWatchRecursive(root string) int {
	count := 0
	filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil
		}
		if info.IsDir() {
			if w.isExcluded(path) {
				return filepath.SkipDir
			}
			if err := w.fsWatcher.Add(path); err != nil {
				// Занадто багато watches — не критично, логуємо і продовжуємо
				if !strings.Contains(err.Error(), "no space left") {
					log.Printf("watch %s: %v", path, err)
				}
			} else {
				count++
			}
		}
		return nil
	})
	return count
}

// isExcluded перевіряє чи шлях знаходиться в exclude-списку.
func (w *Watcher) isExcluded(path string) bool {
	for excl := range w.excludeSet {
		if strings.HasPrefix(path, excl) {
			return true
		}
	}
	// Пропускаємо приховані директорії (.git, .cache тощо)
	base := filepath.Base(path)
	if strings.HasPrefix(base, ".") && base != "." && base != ".." {
		return true
	}
	return false
}

// ============================================================================
// Event handling
// ============================================================================

func (w *Watcher) handleEvent(event fsnotify.Event) {
	path := event.Name

	if w.isExcluded(path) {
		return
	}

	// Debounce — inotify часто шле 2-3 events на одну операцію
	if w.isDuplicate(path) {
		return
	}

	operation := mapOperation(event.Op)
	if operation == "" {
		return
	}

	// Інформація про файл
	info, err := os.Stat(path)
	if err != nil {
		// Файл видалено або переіменовано — emit event без деталей
		if operation == "DELETE" || operation == "RENAME" {
			w.emitEvent(path, operation, 0, "", "", "", false)
		}
		return
	}

	// Нова директорія — додаємо watch
	if info.IsDir() {
		if event.Op&fsnotify.Create != 0 {
			w.addWatchRecursive(path)
		}
		return // Не логуємо події самих директорій
	}

	sizeBytes := info.Size()
	ext := strings.ToLower(filepath.Ext(path))
	fileType := classifyFileType(ext)

	// SHA256 для створених/змінених файлів (до 50MB)
	var fileSHA string
	if (operation == "CREATE" || operation == "WRITE") && sizeBytes > 0 && sizeBytes < maxHashFileSize {
		fileSHA = hashFile(path)
	}

	// Content preview для текстових файлів
	var preview string
	if isTextFile(ext) && sizeBytes > 0 {
		preview = readPreview(path, w.cfg.FS.MaxPreviewSize)
	}

	// Копіюємо скрипти/конфіги
	copied := false
	if w.cfg.FS.CopyFiles && types.CopyableExtensions[ext] && sizeBytes > 0 && sizeBytes < maxCopyFileSize {
		if fileSHA != "" {
			copied = w.copyFile(path, fileSHA, ext)
		}
	}

	w.emitEvent(path, operation, sizeBytes, fileType, fileSHA, preview, copied)
}

// isDuplicate перевіряє debounce window для шляху.
func (w *Watcher) isDuplicate(path string) bool {
	now := time.Now()
	if lastTime, ok := w.debounce[path]; ok {
		if now.Sub(lastTime) < debounceWindow {
			return true
		}
	}
	w.debounce[path] = now

	// Періодично чистимо map (щоб не росла безкінечно)
	if len(w.debounce) > 10000 {
		cutoff := now.Add(-debounceWindow * 2)
		for k, t := range w.debounce {
			if t.Before(cutoff) {
				delete(w.debounce, k)
			}
		}
	}

	return false
}

// emitEvent створює та записує FSEvent.
func (w *Watcher) emitEvent(path, operation string, sizeBytes int64, fileType, sha, preview string, copied bool) {
	event := types.FSEvent{
		Type:           "fs_event",
		Timestamp:      time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:      w.cfg.Agent.MachineID,
		PlayerID:       w.cfg.Agent.PlayerID,
		CTFEventID:     w.cfg.Agent.CTFEventID,
		PID:            0,  // inotify не надає PID — потрібен fanotify
		ProcessName:    "",
		Operation:      operation,
		Path:           path,
		FileType:       fileType,
		SizeBytes:      sizeBytes,
		SHA256:         sha,
		ContentPreview: preview,
		Copied:         copied,
	}

	if err := w.writer.Write(event); err != nil {
		log.Printf("write: %v", err)
	}
}

// ============================================================================
// File copy
// ============================================================================

// copyFile копіює файл у copied_files/ з ім'ям {sha256}{ext}.
// Якщо файл з таким хешем вже скопійовано — пропускає (дедуплікація).
func (w *Watcher) copyFile(srcPath, sha, ext string) bool {
	dstName := sha + ext
	dstPath := filepath.Join(w.copiedDir, dstName)

	// Вже скопійовано — skip
	if _, err := os.Stat(dstPath); err == nil {
		return true
	}

	src, err := os.Open(srcPath)
	if err != nil {
		return false
	}
	defer src.Close()

	dst, err := os.OpenFile(dstPath, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0640)
	if err != nil {
		return false
	}
	defer dst.Close()

	_, err = io.Copy(dst, src)
	if err != nil {
		os.Remove(dstPath) // Не залишаємо неповних файлів
		return false
	}

	return true
}

// ============================================================================
// Helpers
// ============================================================================

func mapOperation(op fsnotify.Op) string {
	switch {
	case op&fsnotify.Create != 0:
		return "CREATE"
	case op&fsnotify.Write != 0:
		return "WRITE"
	case op&fsnotify.Remove != 0:
		return "DELETE"
	case op&fsnotify.Rename != 0:
		return "RENAME"
	case op&fsnotify.Chmod != 0:
		return "CHMOD"
	default:
		return ""
	}
}

// classifyFileType повертає людську категорію файлу за розширенням.
func classifyFileType(ext string) string {
	switch ext {
	// Скрипти
	case ".py":
		return "python_script"
	case ".sh", ".bash":
		return "shell_script"
	case ".php":
		return "php_script"
	case ".rb":
		return "ruby_script"
	case ".pl":
		return "perl_script"
	case ".js":
		return "javascript"
	case ".ts":
		return "typescript"
	case ".ps1":
		return "powershell_script"
	case ".lua":
		return "lua_script"

	// Код
	case ".c", ".h":
		return "c_source"
	case ".cpp", ".hpp", ".cc":
		return "cpp_source"
	case ".go":
		return "go_source"
	case ".rs":
		return "rust_source"
	case ".java":
		return "java_source"
	case ".asm", ".nasm", ".s":
		return "assembly"

	// Конфіги
	case ".conf", ".cfg", ".ini":
		return "config"
	case ".yml", ".yaml":
		return "yaml"
	case ".json":
		return "json"
	case ".xml":
		return "xml"
	case ".toml":
		return "toml"
	case ".env":
		return "env_config"

	// Дані
	case ".sql":
		return "sql"
	case ".csv":
		return "csv"
	case ".html", ".htm":
		return "html"
	case ".css":
		return "css"

	// Документи
	case ".txt", ".md", ".log", ".out":
		return "text"

	// Exploit-specific
	case ".exp":
		return "exploit_script"

	// Бінарники
	case ".elf", ".exe", ".dll", ".so":
		return "binary"
	case "":
		return "no_extension"

	default:
		return "other"
	}
}

// isTextFile визначає чи файл текстовий (для content preview).
func isTextFile(ext string) bool {
	textExts := map[string]bool{
		".py": true, ".sh": true, ".bash": true, ".php": true, ".rb": true,
		".c": true, ".h": true, ".cpp": true, ".hpp": true, ".cc": true,
		".go": true, ".rs": true, ".java": true,
		".js": true, ".ts": true, ".pl": true, ".ps1": true, ".lua": true,
		".asm": true, ".nasm": true, ".s": true,
		".conf": true, ".cfg": true, ".ini": true,
		".yml": true, ".yaml": true, ".json": true, ".xml": true, ".toml": true,
		".env": true,
		".sql": true, ".csv": true,
		".html": true, ".htm": true, ".css": true,
		".txt": true, ".md": true, ".log": true, ".out": true,
		".exp": true,
	}
	return textExts[ext]
}

// readPreview читає перші maxSize байтів текстового файлу.
func readPreview(path string, maxSize int64) string {
	if maxSize <= 0 {
		maxSize = 2048
	}

	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	buf := make([]byte, maxSize)
	n, _ := f.Read(buf)
	if n == 0 {
		return ""
	}
	return string(buf[:n])
}

// hashFile обчислює повний SHA256 файлу.
func hashFile(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}
	return hex.EncodeToString(h.Sum(nil))
}
