package exporter

import (
	"archive/tar"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/pkg/config"
)

// ExportStats містить статистику експортованого архіву.
type ExportStats struct {
	ArchiveSize  int64
	JSONLFiles   int
	CopiedFiles  int
	TotalEvents  int64
	WatcherCount int
}

// Manifest описує вміст архіву — метадані для training pipeline.
type Manifest struct {
	AgentType    string            `json:"agent_type"`
	AgentVersion string            `json:"agent_version"`
	CTFEventID   string            `json:"ctf_event_id"`
	MachineID    string            `json:"machine_id"`
	PlayerID     string            `json:"player_id,omitempty"`
	ExportedAt   string            `json:"exported_at"`
	ExporterVer  string            `json:"exporter_version"`
	Watchers     []WatcherManifest `json:"watchers"`
	TotalEvents  int64             `json:"total_events_approx"`
	TotalFiles   int               `json:"total_files"`
}

// WatcherManifest описує дані одного watcher в архіві.
type WatcherManifest struct {
	Name        string   `json:"name"`
	DataFiles   []string `json:"data_files"`
	CopiedFiles []string `json:"copied_files,omitempty"`
	EventCount  int64    `json:"event_count_approx"`
}

// Export створює .tar.gz архів з усіма зібраними даними.
//
// Структура архіву:
//
//	manifest.json                           — метадані
//	config.yaml                             — конфігурація агента
//	watchers/shell-watcher/data/*.jsonl     — дані кожного watcher
//	watchers/interactive-watcher/data/*.jsonl
//	watchers/fs-monitor/data/*.jsonl
//	watchers/fs-monitor/copied_files/*      — копії скриптів учасника
//	...
func Export(cfg config.Config, exporterVersion string) (string, ExportStats, error) {
	var stats ExportStats

	// Ім'я архіву: {type}_{event}_{machine}_{timestamp}.tar.gz
	timestamp := time.Now().UTC().Format("20060102_150405")
	archiveName := fmt.Sprintf("%s_%s_%s_%s.tar.gz",
		cfg.Agent.Type,
		cfg.Agent.CTFEventID,
		cfg.Agent.MachineID,
		timestamp,
	)

	// Створюємо output directory
	if err := os.MkdirAll(cfg.Storage.ExportPath, 0750); err != nil {
		return "", stats, fmt.Errorf("create export dir: %w", err)
	}

	archivePath := filepath.Join(cfg.Storage.ExportPath, archiveName)

	// Створюємо архів
	outFile, err := os.Create(archivePath)
	if err != nil {
		return "", stats, fmt.Errorf("create archive: %w", err)
	}
	defer outFile.Close()

	gzWriter, err := gzip.NewWriterLevel(outFile, gzip.BestCompression)
	if err != nil {
		return "", stats, fmt.Errorf("create gzip writer: %w", err)
	}
	defer gzWriter.Close()

	tarWriter := tar.NewWriter(gzWriter)
	defer tarWriter.Close()

	// Збираємо manifest
	manifest := Manifest{
		AgentType:    cfg.Agent.Type,
		AgentVersion: cfg.Agent.Version,
		CTFEventID:   cfg.Agent.CTFEventID,
		MachineID:    cfg.Agent.MachineID,
		PlayerID:     cfg.Agent.PlayerID,
		ExportedAt:   time.Now().UTC().Format(time.RFC3339),
		ExporterVer:  exporterVersion,
	}

	// Обходимо всі watcher директорії
	watchersDir := cfg.Storage.BasePath
	entries, err := os.ReadDir(watchersDir)
	if err != nil {
		return "", stats, fmt.Errorf("read watchers dir %s: %w", watchersDir, err)
	}

	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}

		watcherName := entry.Name()
		watcherPath := filepath.Join(watchersDir, watcherName)

		wm := WatcherManifest{
			Name: watcherName,
		}

		// Додаємо data/*.jsonl
		dataDir := filepath.Join(watcherPath, "data")
		if dirExists(dataDir) {
			jsonlFiles, events := addDirectoryToTar(
				tarWriter,
				dataDir,
				filepath.Join("watchers", watcherName, "data"),
				".jsonl",
			)
			wm.DataFiles = jsonlFiles
			wm.EventCount = events
			stats.JSONLFiles += len(jsonlFiles)
			stats.TotalEvents += events
		}

		// Додаємо copied_files/ (тільки для fs-monitor)
		copiedDir := filepath.Join(watcherPath, "copied_files")
		if dirExists(copiedDir) {
			copiedFiles, _ := addDirectoryToTar(
				tarWriter,
				copiedDir,
				filepath.Join("watchers", watcherName, "copied_files"),
				"", // всі файли
			)
			wm.CopiedFiles = copiedFiles
			stats.CopiedFiles += len(copiedFiles)
		}

		// Додаємо watcher до manifest тільки якщо є дані
		if len(wm.DataFiles) > 0 || len(wm.CopiedFiles) > 0 {
			manifest.Watchers = append(manifest.Watchers, wm)
			stats.WatcherCount++
			log.Printf("packed %s: %d data files (~%d events), %d copied files",
				watcherName, len(wm.DataFiles), wm.EventCount, len(wm.CopiedFiles))
		}
	}

	manifest.TotalEvents = stats.TotalEvents
	manifest.TotalFiles = stats.JSONLFiles + stats.CopiedFiles

	// Додаємо config.yaml
	configPath := filepath.Join(filepath.Dir(watchersDir), "config.yaml")
	if fileExists(configPath) {
		if err := addFileToTar(tarWriter, configPath, "config.yaml"); err != nil {
			log.Printf("add config.yaml: %v (skipping)", err)
		}
	}

	// Записуємо manifest.json
	if err := addManifestToTar(tarWriter, manifest); err != nil {
		log.Printf("write manifest: %v", err)
	}

	// Закриваємо tar/gzip щоб отримати правильний розмір
	tarWriter.Close()
	gzWriter.Close()
	outFile.Close()

	// Читаємо фінальний розмір архіву
	if info, err := os.Stat(archivePath); err == nil {
		stats.ArchiveSize = info.Size()
	}

	log.Printf("archive created: %s (%.2f MB, %d watchers, ~%d events)",
		archivePath,
		float64(stats.ArchiveSize)/(1024*1024),
		stats.WatcherCount,
		stats.TotalEvents,
	)

	return archivePath, stats, nil
}

// ============================================================================
// tar helpers
// ============================================================================

// addDirectoryToTar додає всі файли з директорії в tar архів.
// Якщо extFilter != "" — додає тільки файли з цим розширенням.
// Повертає список доданих імен та підрахунок рядків (events) для JSONL файлів.
func addDirectoryToTar(tw *tar.Writer, srcDir, tarPrefix, extFilter string) ([]string, int64) {
	var files []string
	var totalLines int64

	filepath.Walk(srcDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}

		// Фільтруємо за розширенням якщо задано
		if extFilter != "" && !strings.HasSuffix(info.Name(), extFilter) {
			return nil
		}

		// Пропускаємо порожні файли
		if info.Size() == 0 {
			return nil
		}

		relPath, _ := filepath.Rel(srcDir, path)
		tarPath := filepath.Join(tarPrefix, relPath)

		if err := addFileToTar(tw, path, tarPath); err != nil {
			log.Printf("add %s: %v (skipping)", path, err)
			return nil
		}

		files = append(files, relPath)

		// Підраховуємо рядки у JSONL файлах (≈ кількість events)
		if strings.HasSuffix(info.Name(), ".jsonl") {
			totalLines += countLines(path)
		}

		return nil
	})

	return files, totalLines
}

// addFileToTar додає один файл в tar архів.
func addFileToTar(tw *tar.Writer, srcPath, tarPath string) error {
	f, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer f.Close()

	info, err := f.Stat()
	if err != nil {
		return err
	}

	hdr, err := tar.FileInfoHeader(info, "")
	if err != nil {
		return err
	}
	hdr.Name = tarPath

	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}

	_, err = io.Copy(tw, f)
	return err
}

// addManifestToTar серіалізує manifest в JSON і додає до архіву.
func addManifestToTar(tw *tar.Writer, manifest Manifest) error {
	data, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal manifest: %w", err)
	}
	data = append(data, '\n')

	hdr := &tar.Header{
		Name:    "manifest.json",
		Size:    int64(len(data)),
		Mode:    0644,
		ModTime: time.Now(),
	}

	if err := tw.WriteHeader(hdr); err != nil {
		return err
	}

	_, err = tw.Write(data)
	return err
}

// countLines рахує кількість рядків у файлі (≈ кількість JSONL events).
func countLines(path string) int64 {
	f, err := os.Open(path)
	if err != nil {
		return 0
	}
	defer f.Close()

	var count int64
	buf := make([]byte, 64*1024)
	for {
		n, err := f.Read(buf)
		for i := 0; i < n; i++ {
			if buf[i] == '\n' {
				count++
			}
		}
		if err != nil {
			break
		}
	}
	return count
}

// ============================================================================
// fs helpers
// ============================================================================

func dirExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.IsDir()
}

func fileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}
