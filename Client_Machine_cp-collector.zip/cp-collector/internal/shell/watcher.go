package shell

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"

	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
	"github.com/cyber-polygon/cp-collector/pkg/types"
)

// Watcher приймає JSON-повідомлення від bash/zsh shell hooks через UNIX socket.
//
// Архітектура:
//   1. При старті створює UNIX socket (за замовчуванням /home/iron/watchers/shell-watcher/shell.sock)
//   2. Bash/zsh hooks при кожній команді підключаються до socket і шлють JSON
//   3. Watcher парсить JSON, збагачує метаданими агента, пише в JSONL
//
// Кожне з'єднання обробляється в окремій goroutine.
type Watcher struct {
	cfg    config.Config
	writer *storage.Writer

	socketPath string
	listener   net.Listener
	wg         sync.WaitGroup
}

// New створює новий shell-watcher.
func New(cfg config.Config, writer *storage.Writer) *Watcher {
	return &Watcher{
		cfg:        cfg,
		writer:     writer,
		socketPath: cfg.Shell.SocketPath,
	}
}

func (w *Watcher) Name() string { return "shell-watcher" }

func (w *Watcher) Start(ctx context.Context) error {
	// Гарантуємо існування директорії для socket
	socketDir := filepath.Dir(w.socketPath)
	if err := os.MkdirAll(socketDir, 0750); err != nil {
		return fmt.Errorf("create socket dir %s: %w", socketDir, err)
	}

	// Видаляємо stale socket від попереднього запуску
	os.Remove(w.socketPath)

	ln, err := net.Listen("unix", w.socketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", w.socketPath, err)
	}

	// Socket має бути доступний для запису всім користувачам —
	// shell hooks працюють від імені учасника CTF, не від iron/root
	if err := os.Chmod(w.socketPath, 0666); err != nil {
		ln.Close()
		return fmt.Errorf("chmod socket: %w", err)
	}
	w.listener = ln

	log.Printf("listening on %s", w.socketPath)

	// Приймаємо з'єднання в фоні
	go func() {
		for {
			conn, err := ln.Accept()
			if err != nil {
				select {
				case <-ctx.Done():
					return
				default:
					log.Printf("accept error: %v", err)
					continue
				}
			}
			w.wg.Add(1)
			go w.handleConnection(ctx, conn)
		}
	}()

	<-ctx.Done()
	return nil
}

func (w *Watcher) Stop() error {
	if w.listener != nil {
		w.listener.Close()
	}
	// Чекаємо завершення всіх активних з'єднань
	w.wg.Wait()
	os.Remove(w.socketPath)
	log.Printf("stopped")
	return nil
}

// handleConnection обробляє одне з'єднання від shell hook.
// Кожен виклик socat створює нове з'єднання з одним JSON-рядком.
func (w *Watcher) handleConnection(ctx context.Context, conn net.Conn) {
	defer w.wg.Done()
	defer conn.Close()

	scanner := bufio.NewScanner(conn)
	// Shell hooks можуть надсилати великі повідомлення (stdout до 64KB)
	scanner.Buffer(make([]byte, 0, 256*1024), 256*1024)

	for scanner.Scan() {
		select {
		case <-ctx.Done():
			return
		default:
		}

		line := scanner.Bytes()
		if len(line) == 0 {
			continue
		}

		// Парсимо raw JSON від hook
		var raw hookMessage
		if err := json.Unmarshal(line, &raw); err != nil {
			log.Printf("unmarshal error: %v (data: %.100s)", err, string(line))
			continue
		}

		// Збагачуємо метаданими агента та пишемо в storage
		event := w.buildEvent(raw)
		if err := w.writer.Write(event); err != nil {
			log.Printf("write error: %v", err)
		}
	}

	if err := scanner.Err(); err != nil {
		log.Printf("scanner error: %v", err)
	}
}

// hookMessage — JSON-структура яку надсилають bash/zsh hooks.
type hookMessage struct {
	Command        string `json:"command"`
	CWD            string `json:"cwd"`
	Shell          string `json:"shell"` // "bash" | "zsh"
	PID            int    `json:"pid"`
	TTY            string `json:"tty"`
	TimestampStart string `json:"timestamp_start"`
	TimestampEnd   string `json:"timestamp_end"`
	ExitCode       int    `json:"exit_code"`
	Stdout         string `json:"stdout"`
	StdoutSize     int64  `json:"stdout_size"`
	Stderr         string `json:"stderr"`
	StderrSize     int64  `json:"stderr_size"`
	DurationMs     int64  `json:"duration_ms"`
}

// buildEvent конвертує raw повідомлення від hook у типізовану подію.
func (w *Watcher) buildEvent(raw hookMessage) types.ShellCommandEvent {
	// Обрізаємо stdout/stderr до налаштованого максимуму
	stdout := raw.Stdout
	if int64(len(stdout)) > w.cfg.Shell.MaxStdoutBytes {
		stdout = stdout[:w.cfg.Shell.MaxStdoutBytes]
	}
	stderr := raw.Stderr
	if int64(len(stderr)) > w.cfg.Shell.MaxStderrBytes {
		stderr = stderr[:w.cfg.Shell.MaxStderrBytes]
	}

	return types.ShellCommandEvent{
		Type:           "shell_command",
		TimestampStart: raw.TimestampStart,
		TimestampEnd:   raw.TimestampEnd,
		SessionID:      fmt.Sprintf("sess_%s_%d", sanitizeTTY(raw.TTY), raw.PID),
		MachineID:      w.cfg.Agent.MachineID,
		PlayerID:       w.cfg.Agent.PlayerID,
		CTFEventID:     w.cfg.Agent.CTFEventID,
		PID:            raw.PID,
		TTY:            raw.TTY,
		CWD:            raw.CWD,
		Shell:          raw.Shell,
		Command:        raw.Command,
		Argv:           parseArgv(raw.Command),
		ExitCode:       raw.ExitCode,
		StdoutPreview:  stdout,
		StdoutSize:     raw.StdoutSize,
		StderrPreview:  stderr,
		StderrSize:     raw.StderrSize,
		DurationMs:     raw.DurationMs,
	}
}

// sanitizeTTY перетворює /dev/pts/3 → pts3 для використання у session_id.
func sanitizeTTY(tty string) string {
	tty = strings.ReplaceAll(tty, "/dev/", "")
	tty = strings.ReplaceAll(tty, "/", "")
	return tty
}

// parseArgv розбиває командний рядок на аргументи.
// Підтримує одинарні та подвійні лапки, backslash-ескейпи.
// Для складних конструкцій (pipes, redirects) зберігається повний command.
func parseArgv(cmd string) []string {
	var args []string
	var current []byte
	inQuote := byte(0)
	escaped := false

	for i := 0; i < len(cmd); i++ {
		c := cmd[i]

		if escaped {
			current = append(current, c)
			escaped = false
			continue
		}
		if c == '\\' {
			escaped = true
			current = append(current, c)
			continue
		}
		if inQuote != 0 {
			current = append(current, c)
			if c == inQuote {
				inQuote = 0
			}
			continue
		}
		if c == '\'' || c == '"' {
			inQuote = c
			current = append(current, c)
			continue
		}
		if c == ' ' || c == '\t' {
			if len(current) > 0 {
				args = append(args, string(current))
				current = current[:0]
			}
			continue
		}
		current = append(current, c)
	}

	if len(current) > 0 {
		args = append(args, string(current))
	}
	return args
}
