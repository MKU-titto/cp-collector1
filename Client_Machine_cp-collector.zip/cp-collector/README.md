# CP-Collector — Client_Machine Agent

Behavioral data collection agent for CTF participants. Installs on the participant's machine (Kali/Parrot/Ubuntu) and silently records all actions during a CTF event. Collected data is used to train an AI agent capable of autonomously solving CTF scenarios.

## How It Works

The agent consists of 7 independent services (watchers) running as systemd units. Each watcher monitors a specific data source and writes JSONL events into its own directory under `/home/iron/watchers/<name>/data/`. A dedicated system user `iron` owns all agent files with restricted permissions — CTF participants cannot access or interfere with the collected data.

After the CTF event, the **exporter** utility packs all data into a single `.tar.gz` archive for transfer to the training pipeline.

## Services

| Service | Source | What it captures |
|---------|--------|-----------------|
| **shell-watcher** | bash/zsh preexec hooks → UNIX socket | Terminal commands, CWD, exit code, duration |
| **interactive-watcher** | eBPF (sys_read/sys_write) | Stdin/stdout of REPL tools: gdb, msfconsole, python, sqlmap, radare2, ssh, mysql, etc. |
| **proc-monitor** | /proc polling | Process spawn/exit, binary SHA256, CTF tool classification (70+ tools, 12 categories) |
| **net-sniffer** | libpcap | TCP/UDP flows, DNS queries, PID resolution, IPv4/IPv6 |
| **browser-watcher** | mitmproxy transparent proxy | HTTP/HTTPS requests: URL, method, body preview, status, latency |
| **fs-monitor** | inotify | File create/write/delete/rename, content preview, script backups (.py, .sh, .php, etc.) |
| **syscall-monitor** | eBPF tracepoints | Target syscalls: connect, execve, mmap, mprotect, ptrace, setuid, bind, clone |
| **exporter** | filesystem | Packs all watcher data + config + manifest into a compressed archive |

## Installation

Requirements: Debian/Ubuntu/Kali/Parrot, kernel ≥ 5.8, root access, internet connection.

```bash
cd cp-collector
sudo bash install.sh
```

The script will prompt for an Event ID, then automatically:

1. Create the `iron` system user with locked-down permissions
2. Install all dependencies (Go, clang, llvm, libbpf, libpcap, mitmproxy, etc.)
3. Compile eBPF programs and Go binaries
4. Generate `config.yaml` with machine_id and player_id
5. Install shell hooks and configure transparent proxy
6. Start all 7 services via systemd

After installation, provide the displayed `machine_id` and `player_id` to the event organizer.

## Quick Reference

```bash
systemctl status 'cp-collector-*'                              # all services status
journalctl -u cp-collector-shell -f                            # live logs
/home/iron/bin/exporter -config /home/iron/config.yaml         # export data
systemctl stop 'cp-collector-*'                                # stop all
```
