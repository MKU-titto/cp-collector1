#!/bin/bash
# ============================================================================
# Cyber Polygon — cp-collector shell hook for Bash
#
# Встановлюється в: /etc/profile.d/cp-collector-hook.sh
# Підключається автоматично при старті кожної інтерактивної bash-сесії.
#
# Що збирає:
#   - Текст команди (з history)
#   - CWD, PID, TTY, shell тип
#   - Timestamps (початок / кінець виконання)
#   - Exit code
#   - Тривалість виконання (мс)
#
# Stdout/stderr НЕ перехоплюються в hook — це робить interactive-watcher
# через eBPF для REPL-інструментів. Перехоплення stdout в bash потребувало б
# обгортання кожної команди, що ламає інтерактивні програми.
#
# Надсилає JSON через socat у UNIX socket shell-watcher.
# ============================================================================

# --- Guard: не завантажувати двічі, пропустити неінтерактивні сесії та iron ---
[[ -n "$__CP_HOOK_LOADED" ]] && return
[[ $- != *i* ]] && return
[[ "$(whoami)" == "iron" ]] && return
export __CP_HOOK_LOADED=1

# --- Конфігурація ---
__CP_SOCKET="/home/iron/watchers/shell-watcher/shell.sock"

# --- Helpers ---

# Відправити JSON у UNIX socket (async, щоб не блокувати shell)
__cp_send() {
    local json="$1"
    if [[ -S "$__CP_SOCKET" ]]; then
        echo "$json" | socat - UNIX-CONNECT:"$__CP_SOCKET" 2>/dev/null &
        disown 2>/dev/null
    fi
}

# ISO 8601 timestamp з мілісекундами
__cp_timestamp() {
    date -u +"%Y-%m-%dT%H:%M:%S.%3NZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ"
}

# Ескейпінг рядка для вставки в JSON
# Замінює: \ → \\, " → \", newline → \n, tab → \t, carriage return → \r
# Видаляє control characters (0x00-0x08, 0x0B, 0x0C, 0x0E-0x1F)
__cp_json_escape() {
    local str="$1"
    str="${str//\\/\\\\}"
    str="${str//\"/\\\"}"
    str="${str//$'\n'/\\n}"
    str="${str//$'\r'/\\r}"
    str="${str//$'\t'/\\t}"
    str=$(printf '%s' "$str" | tr -d '\000-\010\013\014\016-\037')
    printf '%s' "$str"
}

# --- Стан між preexec та precmd ---
__cp_cmd=""
__cp_ts_start=""
__cp_start_ms=0

# --- Pre-execution hook (DEBUG trap) ---
# Спрацьовує ПЕРЕД виконанням кожної команди.
__cp_preexec() {
    # Пропускаємо системні виклики та власні функції
    [[ -n "$COMP_LINE" ]] && return
    [[ "$BASH_COMMAND" == "__cp_precmd" ]] && return
    [[ "$BASH_COMMAND" == __cp_* ]] && return

    # Фіксуємо тільки першу команду (не pipe-сегменти)
    if [[ -z "$__cp_cmd" ]]; then
        __cp_cmd="$(history 1 | sed 's/^[ ]*[0-9]*[ ]*//')"
        __cp_ts_start="$(__cp_timestamp)"
        __cp_start_ms=$(date +%s%3N 2>/dev/null || echo 0)
    fi
}
trap '__cp_preexec' DEBUG

# --- Post-execution hook (PROMPT_COMMAND) ---
# Спрацьовує ПІСЛЯ виконання команди, перед виведенням prompt.
__cp_precmd() {
    local last_exit=$?

    # Нічого не було зафіксовано
    [[ -z "$__cp_cmd" ]] && return

    local cmd="$__cp_cmd"
    local ts_start="$__cp_ts_start"
    local ts_end="$(__cp_timestamp)"

    # Тривалість
    local end_ms
    end_ms=$(date +%s%3N 2>/dev/null || echo 0)
    local duration_ms=0
    if [[ "$__cp_start_ms" -gt 0 && "$end_ms" -gt 0 ]]; then
        duration_ms=$((end_ms - __cp_start_ms))
    fi

    # JSON escape
    local cmd_esc
    cmd_esc="$(__cp_json_escape "$cmd")"
    local cwd_esc
    cwd_esc="$(__cp_json_escape "$PWD")"
    local tty_val
    tty_val="$(tty 2>/dev/null || echo unknown)"

    # Формуємо JSON (компактний, один рядок)
    local json
    json="{\"command\":\"${cmd_esc}\",\"cwd\":\"${cwd_esc}\",\"shell\":\"bash\",\"pid\":$$,\"tty\":\"${tty_val}\",\"timestamp_start\":\"${ts_start}\",\"timestamp_end\":\"${ts_end}\",\"exit_code\":${last_exit},\"stdout\":\"\",\"stdout_size\":0,\"stderr\":\"\",\"stderr_size\":0,\"duration_ms\":${duration_ms}}"

    __cp_send "$json"

    # Скидаємо стан
    __cp_cmd=""
    __cp_ts_start=""
    __cp_start_ms=0
}

# Додаємо precmd до PROMPT_COMMAND (не перетираючи існуючий)
PROMPT_COMMAND="__cp_precmd${PROMPT_COMMAND:+; $PROMPT_COMMAND}"
