#!/bin/zsh
# ============================================================================
# Cyber Polygon — cp-collector shell hook for Zsh
#
# Встановлюється в: /etc/zsh/zshrc.d/cp-collector-hook.zsh
# Або підключається через source в /etc/zshrc
#
# Використовує нативні zsh хуки preexec / precmd.
# Zsh передає повний командний рядок як $1 у preexec — не потрібен history hack.
# ============================================================================

# --- Guard ---
[[ -n "$__CP_HOOK_LOADED" ]] && return
[[ ! -o interactive ]] && return
[[ "$(whoami)" == "iron" ]] && return
export __CP_HOOK_LOADED=1

# --- Конфігурація ---
__CP_SOCKET="/home/iron/watchers/shell-watcher/shell.sock"

# --- Helpers ---

__cp_send() {
    local json="$1"
    if [[ -S "$__CP_SOCKET" ]]; then
        echo "$json" | socat - UNIX-CONNECT:"$__CP_SOCKET" 2>/dev/null &!
    fi
}

__cp_timestamp() {
    date -u +"%Y-%m-%dT%H:%M:%S.%3NZ" 2>/dev/null || date -u +"%Y-%m-%dT%H:%M:%SZ"
}

__cp_json_escape() {
    local str="$1"
    str="${str//\\/\\\\}"
    str="${str//\"/\\\"}"
    str="${str//$'\n'/\\n}"
    str="${str//$'\r'/\\r}"
    str="${str//$'\t'/\\t}"
    str=$(printf '%s' "$str" | tr -d '\000-\010\013\014\016-\037')
    printf '%s' "$str"
}

# --- Стан ---
typeset -g __cp_cmd=""
typeset -g __cp_ts_start=""
typeset -g __cp_start_ms=0

# --- preexec: викликається перед виконанням команди ---
# $1 — повний командний рядок (zsh передає автоматично)
__cp_preexec() {
    __cp_cmd="$1"
    __cp_ts_start="$(__cp_timestamp)"
    __cp_start_ms=$(date +%s%3N 2>/dev/null || echo 0)
}

# --- precmd: викликається перед виведенням prompt ---
__cp_precmd() {
    local last_exit=$?

    [[ -z "$__cp_cmd" ]] && return

    local ts_end
    ts_end="$(__cp_timestamp)"
    local end_ms
    end_ms=$(date +%s%3N 2>/dev/null || echo 0)
    local duration_ms=0
    if [[ "$__cp_start_ms" -gt 0 && "$end_ms" -gt 0 ]]; then
        duration_ms=$((end_ms - __cp_start_ms))
    fi

    local cmd_esc
    cmd_esc="$(__cp_json_escape "$__cp_cmd")"
    local cwd_esc
    cwd_esc="$(__cp_json_escape "$PWD")"
    local tty_val
    tty_val="$(tty 2>/dev/null || echo unknown)"

    local json="{\"command\":\"${cmd_esc}\",\"cwd\":\"${cwd_esc}\",\"shell\":\"zsh\",\"pid\":$$,\"tty\":\"${tty_val}\",\"timestamp_start\":\"${__cp_ts_start}\",\"timestamp_end\":\"${ts_end}\",\"exit_code\":${last_exit},\"stdout\":\"\",\"stdout_size\":0,\"stderr\":\"\",\"stderr_size\":0,\"duration_ms\":${duration_ms}}"

    __cp_send "$json"

    # Скидаємо стан
    __cp_cmd=""
    __cp_ts_start=""
    __cp_start_ms=0
}

# --- Реєстрація хуків ---
autoload -Uz add-zsh-hook
add-zsh-hook preexec __cp_preexec
add-zsh-hook precmd __cp_precmd
