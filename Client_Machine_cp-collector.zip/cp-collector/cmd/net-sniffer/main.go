package main

import (
	"context"
	"flag"
	"fmt"
	"log"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cyber-polygon/cp-collector/internal/net"
	"github.com/cyber-polygon/cp-collector/pkg/config"
	"github.com/cyber-polygon/cp-collector/pkg/storage"
)

var (
	version   = "2.0.0"
	buildTime = "unknown"
)

func main() {
	configPath := flag.String("config", "/home/iron/config.yaml", "Path to config file")
	showVersion := flag.Bool("version", false, "Show version and exit")
	flag.Parse()

	if *showVersion {
		fmt.Printf("cp-collector-net %s (built %s)\n", version, buildTime)
		os.Exit(0)
	}

	log.SetPrefix("[net-sniffer] ")
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds)
	log.Printf("starting %s", version)

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	if !cfg.Net.Enabled {
		log.Printf("net sniffer is disabled in config, exiting")
		os.Exit(0)
	}

	log.Printf("event=%s machine=%s interfaces=%v dns=%v",
		cfg.Agent.CTFEventID, cfg.Agent.MachineID,
		cfg.Net.Interfaces, cfg.Net.CaptureDNS)

	writer, err := storage.NewWriter("net-sniffer", cfg.Agent, cfg.Storage)
	if err != nil {
		log.Fatalf("create storage writer: %v", err)
	}
	defer writer.Close()

	w := net.New(*cfg, writer)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	writer.Write(map[string]interface{}{
		"type":         "watcher_start",
		"watcher":      w.Name(),
		"timestamp":    time.Now().UTC().Format(time.RFC3339Nano),
		"machine_id":   cfg.Agent.MachineID,
		"ctf_event_id": cfg.Agent.CTFEventID,
		"version":      version,
	})

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	errCh := make(chan error, 1)
	go func() {
		errCh <- w.Start(ctx)
	}()

	select {
	case sig := <-sigCh:
		log.Printf("received signal: %v, shutting down...", sig)
		cancel()
	case err := <-errCh:
		if err != nil {
			log.Printf("watcher error: %v", err)
		}
	}

	w.Stop()

	writer.Write(map[string]interface{}{
		"type":         "watcher_stop",
		"watcher":      w.Name(),
		"timestamp":    time.Now().UTC().Format(time.RFC3339Nano),
		"machine_id":   cfg.Agent.MachineID,
		"ctf_event_id": cfg.Agent.CTFEventID,
	})

	writer.Close()
	log.Printf("stopped")
}
