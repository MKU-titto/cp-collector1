package main

import (
	"flag"
	"fmt"
	"log"
	"os"

	"github.com/cyber-polygon/cp-collector/internal/exporter"
	"github.com/cyber-polygon/cp-collector/pkg/config"
)

var (
	version   = "2.0.0"
	buildTime = "unknown"
)

func main() {
	configPath := flag.String("config", "/home/iron/config.yaml", "Path to config file")
	showVersion := flag.Bool("version", false, "Show version and exit")
	outputDir := flag.String("output", "", "Override export output directory")
	flag.Parse()

	if *showVersion {
		fmt.Printf("cp-collector-exporter %s (built %s)\n", version, buildTime)
		os.Exit(0)
	}

	log.SetPrefix("[exporter] ")
	log.SetFlags(log.Ldate | log.Ltime | log.Lmicroseconds)
	log.Printf("starting %s", version)

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Fatalf("load config: %v", err)
	}

	// Override output directory якщо задано через CLI
	if *outputDir != "" {
		cfg.Storage.ExportPath = *outputDir
	}

	log.Printf("event=%s machine=%s player=%s",
		cfg.Agent.CTFEventID, cfg.Agent.MachineID, cfg.Agent.PlayerID)
	log.Printf("watchers_dir=%s export_to=%s",
		cfg.Storage.BasePath, cfg.Storage.ExportPath)

	archivePath, stats, err := exporter.Export(*cfg, version)
	if err != nil {
		log.Fatalf("export failed: %v", err)
	}

	// Виводимо результат
	fmt.Println()
	fmt.Println("════════════════════════════════════════════════════")
	fmt.Println("  Export complete!")
	fmt.Println("════════════════════════════════════════════════════")
	fmt.Printf("  Archive:       %s\n", archivePath)
	fmt.Printf("  Size:          %s\n", formatSize(stats.ArchiveSize))
	fmt.Printf("  JSONL files:   %d\n", stats.JSONLFiles)
	fmt.Printf("  Copied files:  %d\n", stats.CopiedFiles)
	fmt.Printf("  Total events:  ~%d\n", stats.TotalEvents)
	fmt.Printf("  Watchers:      %d\n", stats.WatcherCount)
	fmt.Println("════════════════════════════════════════════════════")
	fmt.Println()
}

func formatSize(bytes int64) string {
	switch {
	case bytes >= 1024*1024*1024:
		return fmt.Sprintf("%.2f GB", float64(bytes)/(1024*1024*1024))
	case bytes >= 1024*1024:
		return fmt.Sprintf("%.2f MB", float64(bytes)/(1024*1024))
	case bytes >= 1024:
		return fmt.Sprintf("%.2f KB", float64(bytes)/1024)
	default:
		return fmt.Sprintf("%d bytes", bytes)
	}
}
