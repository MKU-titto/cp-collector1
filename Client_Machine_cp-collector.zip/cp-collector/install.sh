#!/bin/bash
# ============================================================================
# Cyber Polygon — Client_Machine Agent Installer
#
# Повна інсталяція пакету сервісів cp-collector на машину учасника CTF.
# Запуск: sudo bash install.sh
#
# Що робить скрипт:
#   1.  Створює користувача iron з паролем
#   2.  Налаштовує права доступу (максимальна ізоляція від CTF-учасників)
#   3.  Створює структуру директорій /home/iron/watchers/*/data/
#   4.  Встановлює ВСІ залежності (Go, clang, libbpf, libpcap, mitmproxy тощо)
#   5.  Генерує machine_id, player_id
#   6.  Автовизначає мережевий інтерфейс
#   7.  Компілює eBPF програми та Go бінарники
#   8.  Генерує config.yaml
#   9.  Встановлює shell hooks (bash/zsh)
#  10.  Налаштовує mitmproxy CA + iptables transparent proxy
#  11.  Реєструє та запускає systemd сервіси
#  12.  Верифікує що все працює
#
# Вимоги:
#   - Debian/Ubuntu/Kali/Parrot Linux
#   - Root привілеї (sudo)
#   - Ядро >= 5.8 (для eBPF ring buffer)
#   - Інтернет (для завантаження залежностей)
#
# ============================================================================

set -euo pipefail

# ============================================================================
# Кольори та логування
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

log_info()  { echo -e "${CYAN}[INFO]${NC}  $1"; }
log_ok()    { echo -e "${GREEN}[ OK ]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[FAIL]${NC}  $1"; }
log_step()  { echo -e "\n${BOLD}${CYAN}══════ Step $1 ══════${NC}"; }

# ============================================================================
# Банер
# ============================================================================
echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                          ║${NC}"
echo -e "${CYAN}║       ${BOLD}Cyber Polygon — cp-collector installer${NC}${CYAN}             ║${NC}"
echo -e "${CYAN}║       Agent: Client_Machine v2.0                         ║${NC}"
echo -e "${CYAN}║                                                          ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# ============================================================================
# Перевірки
# ============================================================================
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root: sudo bash install.sh"
    exit 1
fi

# Визначаємо директорію скрипта (там де лежить Makefile, go.mod тощо)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ ! -f "$SCRIPT_DIR/Makefile" || ! -f "$SCRIPT_DIR/go.mod" ]]; then
    log_error "install.sh must be in the cp-collector project root (next to Makefile and go.mod)"
    exit 1
fi

# Перевірка ядра
KERNEL_VER=$(uname -r | cut -d. -f1-2)
KERNEL_MAJOR=$(echo "$KERNEL_VER" | cut -d. -f1)
KERNEL_MINOR=$(echo "$KERNEL_VER" | cut -d. -f2)
if [[ "$KERNEL_MAJOR" -lt 5 ]] || { [[ "$KERNEL_MAJOR" -eq 5 ]] && [[ "$KERNEL_MINOR" -lt 8 ]]; }; then
    log_error "Kernel >= 5.8 required for eBPF ring buffer. Current: $(uname -r)"
    exit 1
fi
log_ok "Kernel $(uname -r) — OK"

# ============================================================================
# Інтерактивний запит параметрів
# ============================================================================
echo ""
echo -e "${BOLD}Configuration:${NC}"
echo ""

read -rp "  Enter CTF Event ID (e.g. cyberpolygon-2026-spring): " EVENT_ID
if [[ -z "$EVENT_ID" ]]; then
    log_error "Event ID is required"
    exit 1
fi

echo ""
log_info "Event ID: ${EVENT_ID}"
echo ""
read -rp "  Proceed with installation? [Y/n]: " CONFIRM
CONFIRM="${CONFIRM:-Y}"
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
    echo "Aborted."
    exit 0
fi

# ============================================================================
# Константи
# ============================================================================
IRON_USER="iron"
IRON_PASS="IronAgent_password"
IRON_HOME="/home/iron"
GO_VERSION="1.22.5"
GO_ARCHIVE="go${GO_VERSION}.linux-$(dpkg --print-architecture).tar.gz"
GO_URL="https://go.dev/dl/${GO_ARCHIVE}"

# Список watchers — відповідає Makefile MODULES
WATCHERS=(
    shell-watcher
    interactive-watcher
    proc-monitor
    net-sniffer
    browser-watcher
    fs-monitor
    syscall-monitor
)

SERVICES=(
    cp-collector-shell
    cp-collector-interactive
    cp-collector-proc
    cp-collector-net
    cp-collector-browser
    cp-collector-fs
    cp-collector-syscall
)

# ============================================================================
# Step 1: Створення користувача iron
# ============================================================================
log_step "1/12: Creating user '${IRON_USER}'"

if id "$IRON_USER" &>/dev/null; then
    log_warn "User '$IRON_USER' already exists, updating password"
    echo "${IRON_USER}:${IRON_PASS}" | chpasswd
else
    useradd -m -s /bin/bash "$IRON_USER"
    echo "${IRON_USER}:${IRON_PASS}" | chpasswd
    log_ok "User '$IRON_USER' created"
fi

log_ok "Password set for '$IRON_USER'"

# ============================================================================
# Step 2: Закриття прав доступу
# ============================================================================
log_step "2/12: Securing ${IRON_HOME}"

# Тільки iron та root мають доступ до /home/iron
chmod 700 "$IRON_HOME"
chown "${IRON_USER}:${IRON_USER}" "$IRON_HOME"

log_ok "${IRON_HOME} — chmod 700 (only iron/root access)"

# ============================================================================
# Step 3: Створення структури директорій
# ============================================================================
log_step "3/12: Creating directory structure"

# Директорії watchers
for w in "${WATCHERS[@]}"; do
    mkdir -p "${IRON_HOME}/watchers/${w}/data"
done
# fs-monitor має додатково copied_files
mkdir -p "${IRON_HOME}/watchers/fs-monitor/copied_files"

# Інші директорії
mkdir -p "${IRON_HOME}/bin"
mkdir -p "${IRON_HOME}/exports"
mkdir -p "${IRON_HOME}/logs"

# Права: все належить iron, закрито від інших
chown -R "${IRON_USER}:${IRON_USER}" "$IRON_HOME"
chmod -R 700 "$IRON_HOME"

log_ok "Directory structure created:"
log_info "  ${IRON_HOME}/watchers/*/data/   — event data"
log_info "  ${IRON_HOME}/bin/               — binaries"
log_info "  ${IRON_HOME}/exports/           — tar.gz archives"

# ============================================================================
# Step 4: Встановлення системних залежностей (apt)
# ============================================================================
log_step "4/12: Installing system dependencies"

export DEBIAN_FRONTEND=noninteractive

log_info "Updating package lists..."
apt-get update -qq

# Всі залежності в одному списку
APT_PACKAGES=(
    # eBPF toolchain
    clang
    llvm
    libbpf-dev
    linux-headers-"$(uname -r)"

    # libpcap (net-sniffer)
    libpcap-dev

    # Shell hooks communication
    socat

    # mitmproxy (browser-watcher)
    python3
    python3-pip
    python3-venv

    # Мережеві утиліти
    iptables
    ca-certificates
    curl
    wget

    # Build essentials
    build-essential
    pkg-config
    git

    # UUID generation
    uuid-runtime
)

log_info "Installing ${#APT_PACKAGES[@]} packages..."
apt-get install -y -qq "${APT_PACKAGES[@]}" 2>/dev/null || {
    log_warn "Batch install failed, trying individually..."
    for pkg in "${APT_PACKAGES[@]}"; do
        apt-get install -y -qq "$pkg" 2>/dev/null || log_warn "Failed: $pkg (non-critical)"
    done
}

# bpftool — може бути в різних пакетах
if ! command -v bpftool &>/dev/null; then
    log_info "Installing bpftool..."
    apt-get install -y -qq linux-tools-"$(uname -r)" linux-tools-common 2>/dev/null || \
    apt-get install -y -qq bpftool 2>/dev/null || \
    log_warn "bpftool not found — vmlinux.h may need to be pre-built"
fi

log_ok "System dependencies installed"

# ============================================================================
# Step 5: Встановлення Go з офіційного сайту
# ============================================================================
log_step "5/12: Installing Go ${GO_VERSION}"

NEED_GO_INSTALL=true

if command -v go &>/dev/null; then
    CURRENT_GO=$(go version | grep -oP 'go\K[0-9]+\.[0-9]+' || echo "0.0")
    log_info "Found Go ${CURRENT_GO}"
    GO_REQ_MAJOR=$(echo "$GO_VERSION" | cut -d. -f1)
    GO_REQ_MINOR=$(echo "$GO_VERSION" | cut -d. -f2)
    CUR_MAJOR=$(echo "$CURRENT_GO" | cut -d. -f1)
    CUR_MINOR=$(echo "$CURRENT_GO" | cut -d. -f2)
    if [[ "$CUR_MAJOR" -gt "$GO_REQ_MAJOR" ]] || \
       { [[ "$CUR_MAJOR" -eq "$GO_REQ_MAJOR" ]] && [[ "$CUR_MINOR" -ge "$GO_REQ_MINOR" ]]; }; then
        log_ok "Go ${CURRENT_GO} >= ${GO_VERSION} — skipping install"
        NEED_GO_INSTALL=false
    fi
fi

if $NEED_GO_INSTALL; then
    log_info "Downloading ${GO_URL}..."

    # Видаляємо стару версію якщо є
    rm -rf /usr/local/go

    cd /tmp
    wget -q "$GO_URL" -O "$GO_ARCHIVE"
    tar -C /usr/local -xzf "$GO_ARCHIVE"
    rm -f "$GO_ARCHIVE"

    # Додаємо в PATH глобально
    cat > /etc/profile.d/go-path.sh << 'GOPATH_EOF'
export PATH=/usr/local/go/bin:$PATH
GOPATH_EOF
    chmod 644 /etc/profile.d/go-path.sh

    export PATH=/usr/local/go/bin:$PATH

    log_ok "Go $(/usr/local/go/bin/go version) installed"
fi

# Гарантуємо що Go доступний в поточній сесії
# ВАЖЛИВО: /usr/local/go/bin має бути ПЕРШИМ, щоб override системний Go з apt
export PATH=/usr/local/go/bin:$PATH
export GOPATH=/root/go

# ============================================================================
# Step 6: Встановлення mitmproxy (browser-watcher)
# ============================================================================
log_step "6/12: Installing mitmproxy"

if command -v mitmdump &>/dev/null; then
    log_ok "mitmproxy already installed: $(mitmdump --version 2>/dev/null | head -1)"
else
    log_info "Installing mitmproxy via pip..."
    pip3 install --break-system-packages mitmproxy 2>/dev/null || \
    pip3 install mitmproxy 2>/dev/null || {
        log_warn "mitmproxy installation failed — browser-watcher will be disabled"
    }

    if command -v mitmdump &>/dev/null; then
        log_ok "mitmproxy installed: $(mitmdump --version 2>/dev/null | head -1)"
    fi
fi

# ============================================================================
# Step 7: Генерація ідентифікаторів
# ============================================================================
log_step "7/12: Generating identifiers"

# machine_id: hostname + sha256(MAC первого не-loopback інтерфейсу)[:8]
HOSTNAME_VAL=$(hostname)
NET_IFACE=$(ip -o link show | awk -F': ' '!/lo/{print $2; exit}' | tr -d ' ')
MAC_ADDR=$(cat "/sys/class/net/${NET_IFACE}/address" 2>/dev/null || echo "00:00:00:00:00:00")
MAC_HASH=$(echo -n "$MAC_ADDR" | sha256sum | cut -c1-8)
MACHINE_ID="${HOSTNAME_VAL}_${MAC_HASH}"

# player_id: UUID
if command -v uuidgen &>/dev/null; then
    PLAYER_ID=$(uuidgen)
elif [[ -f /proc/sys/kernel/random/uuid ]]; then
    PLAYER_ID=$(cat /proc/sys/kernel/random/uuid)
else
    PLAYER_ID="player-$(date +%s)-$(head -c 8 /dev/urandom | xxd -p)"
fi

# Автовизначення мережевого інтерфейсу (перший не-loopback)
NET_INTERFACE=$(ip -o link show | awk -F': ' '!/lo/{print $2; exit}' | tr -d ' ')
if [[ -z "$NET_INTERFACE" ]]; then
    NET_INTERFACE="eth0"
    log_warn "Could not detect network interface, using eth0"
fi

log_ok "machine_id:    ${MACHINE_ID}"
log_ok "player_id:     ${PLAYER_ID}"
log_ok "net_interface:  ${NET_INTERFACE}"

# ============================================================================
# Step 8: Компіляція проекту
# ============================================================================
log_step "8/12: Compiling cp-collector"

cd "$SCRIPT_DIR"

# Верифікуємо що використовується правильна версія Go
export PATH=/usr/local/go/bin:$PATH
GO_ACTUAL=$(go version 2>/dev/null || echo "NOT FOUND")
log_info "Using: ${GO_ACTUAL}"
log_info "Go binary: $(which go)"

if ! go version | grep -qE 'go1\.(2[2-9]|[3-9][0-9])'; then
    log_error "Go >= 1.22 required. Found: ${GO_ACTUAL}"
    log_error "Ensure /usr/local/go/bin is in PATH"
    exit 1
fi

log_info "Downloading Go dependencies..."
go mod download
go mod tidy

# Компілюємо eBPF
log_info "Compiling eBPF programs..."
PATH=/usr/local/go/bin:$PATH make ebpf 2>&1 | while IFS= read -r line; do echo "  $line"; done

# Компілюємо Go бінарники
log_info "Compiling Go binaries..."
PATH=/usr/local/go/bin:$PATH make build 2>&1 | while IFS= read -r line; do echo "  $line"; done

# Перевіряємо що бінарники створились
MISSING_BIN=0
for w in "${WATCHERS[@]}"; do
    if [[ ! -f "${SCRIPT_DIR}/bin/${w}" ]]; then
        log_error "Binary not found: bin/${w}"
        MISSING_BIN=1
    fi
done
if [[ ! -f "${SCRIPT_DIR}/bin/exporter" ]]; then
    log_error "Binary not found: bin/exporter"
    MISSING_BIN=1
fi
if [[ $MISSING_BIN -eq 1 ]]; then
    log_error "Compilation failed. Check errors above."
    exit 1
fi

log_ok "All binaries compiled successfully"

# ============================================================================
# Step 9: Встановлення бінарників та eBPF об'єктів
# ============================================================================
log_step "9/12: Installing binaries and eBPF objects"

# Бінарники
for w in "${WATCHERS[@]}"; do
    install -m 700 "${SCRIPT_DIR}/bin/${w}" "${IRON_HOME}/bin/${w}"
done
install -m 700 "${SCRIPT_DIR}/bin/exporter" "${IRON_HOME}/bin/exporter"

# eBPF .o файли
if [[ -f "${SCRIPT_DIR}/ebpf/interactive/interactive.o" ]]; then
    install -m 600 "${SCRIPT_DIR}/ebpf/interactive/interactive.o" \
        "${IRON_HOME}/watchers/interactive-watcher/interactive.o"
    log_ok "eBPF: interactive.o installed"
fi

if [[ -f "${SCRIPT_DIR}/ebpf/syscall/syscall.o" ]]; then
    install -m 600 "${SCRIPT_DIR}/ebpf/syscall/syscall.o" \
        "${IRON_HOME}/watchers/syscall-monitor/syscall.o"
    log_ok "eBPF: syscall.o installed"
fi

# Права: бінарники доступні тільки iron/root
chown -R "${IRON_USER}:${IRON_USER}" "${IRON_HOME}/bin"
chown -R "${IRON_USER}:${IRON_USER}" "${IRON_HOME}/watchers"

log_ok "Binaries installed to ${IRON_HOME}/bin/ (chmod 700)"

# ============================================================================
# Step 10: Генерація config.yaml
# ============================================================================
log_step "10/12: Generating config.yaml"

BROWSER_ENABLED="true"
if ! command -v mitmdump &>/dev/null; then
    BROWSER_ENABLED="false"
    log_warn "mitmproxy not available — browser-watcher disabled"
fi

cat > "${IRON_HOME}/config.yaml" << ENDCONFIG
# ============================================================================
# Cyber Polygon — cp-collector configuration
# Agent: Client_Machine v2.0
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# DO NOT EDIT MANUALLY during active CTF event
# ============================================================================

agent:
  type: "client_machine"
  version: "2.0"
  ctf_event_id: "${EVENT_ID}"
  machine_id: "${MACHINE_ID}"
  player_id: "${PLAYER_ID}"

storage:
  base_path: "/home/iron/watchers"
  rotate_size_mb: 50
  export_path: "/home/iron/exports"

shell:
  enabled: true
  socket_path: "/home/iron/watchers/shell-watcher/shell.sock"
  max_stdout_bytes: 65536
  max_stderr_bytes: 65536

interactive:
  enabled: true
  scan_interval_sec: 2
  ebpf_object_path: "/home/iron/watchers/interactive-watcher/interactive.o"

proc:
  enabled: true
  poll_interval_ms: 500
  use_auditd: false

net:
  enabled: true
  interfaces:
    - "${NET_INTERFACE}"
  capture_dns: true

browser:
  enabled: ${BROWSER_ENABLED}
  mitmproxy_port: 8080
  max_body_preview_bytes: 4096
  socket_path: "/home/iron/watchers/browser-watcher/mitmproxy.sock"

fs:
  enabled: true
  watch_paths:
    - "/home"
    - "/tmp"
    - "/var/tmp"
    - "/opt"
    - "/var/www"
    - "/srv"
  exclude_paths:
    - "/home/iron"
    - "/proc"
    - "/sys"
    - "/dev"
  max_preview_size_bytes: 2048
  copy_files: true

syscall:
  enabled: true
  ebpf_object_path: "/home/iron/watchers/syscall-monitor/syscall.o"
ENDCONFIG

# Config доступний тільки iron та root
chown "${IRON_USER}:${IRON_USER}" "${IRON_HOME}/config.yaml"
chmod 600 "${IRON_HOME}/config.yaml"

log_ok "config.yaml generated (chmod 600)"

# ============================================================================
# Step 11: Shell hooks + mitmproxy CA + iptables
# ============================================================================
log_step "11/12: Installing shell hooks and proxy"

# --- Bash hook ---
if [[ -f "${SCRIPT_DIR}/scripts/hooks/bash-hook.sh" ]]; then
    install -m 644 "${SCRIPT_DIR}/scripts/hooks/bash-hook.sh" /etc/profile.d/cp-collector-hook.sh
    log_ok "Bash hook: /etc/profile.d/cp-collector-hook.sh"
else
    log_warn "Bash hook source not found"
fi

# --- Zsh hook ---
if [[ -f "${SCRIPT_DIR}/scripts/hooks/zsh-hook.zsh" ]]; then
    mkdir -p /etc/zsh/zshrc.d 2>/dev/null || true
    install -m 644 "${SCRIPT_DIR}/scripts/hooks/zsh-hook.zsh" /etc/zsh/zshrc.d/cp-collector-hook.zsh

    # Додаємо source у /etc/zshrc якщо ще не додано
    if [[ -f /etc/zsh/zshrc ]] && ! grep -q "cp-collector-hook" /etc/zsh/zshrc 2>/dev/null; then
        echo '' >> /etc/zsh/zshrc
        echo '# Cyber Polygon cp-collector hook' >> /etc/zsh/zshrc
        echo '[[ -f /etc/zsh/zshrc.d/cp-collector-hook.zsh ]] && source /etc/zsh/zshrc.d/cp-collector-hook.zsh' >> /etc/zsh/zshrc
    fi
    log_ok "Zsh hook: /etc/zsh/zshrc.d/cp-collector-hook.zsh"
else
    log_warn "Zsh hook source not found"
fi

# --- mitmproxy CA + iptables (browser-watcher) ---
if [[ "$BROWSER_ENABLED" == "true" ]]; then
    log_info "Setting up mitmproxy transparent proxy..."

    # Генеруємо CA сертифікат (перший запуск створює ~/.mitmproxy/)
    timeout 5 mitmdump --mode transparent -p 18999 -q &>/dev/null &
    MITM_PID=$!
    sleep 3
    kill $MITM_PID 2>/dev/null || true
    wait $MITM_PID 2>/dev/null || true

    # Встановлюємо CA сертифікат системно
    MITM_CERT="/root/.mitmproxy/mitmproxy-ca-cert.pem"
    if [[ -f "$MITM_CERT" ]]; then
        cp "$MITM_CERT" /usr/local/share/ca-certificates/mitmproxy-ca.crt
        update-ca-certificates 2>/dev/null || true

        # Firefox (NSS database)
        if command -v certutil &>/dev/null; then
            for profile in /home/*/.mozilla/firefox/*.default*; do
                if [[ -d "$profile" ]]; then
                    certutil -A -n "mitmproxy" -t "C,," -i "$MITM_CERT" -d "sql:$profile" 2>/dev/null || true
                fi
            done
        fi
        log_ok "mitmproxy CA certificate installed"
    else
        log_warn "mitmproxy CA cert not generated"
    fi

    # iptables: перенаправляємо HTTP/HTTPS трафік на mitmproxy
    # Виключаємо iron (щоб mitmproxy сам не потрапляв в петлю)
    IRON_UID=$(id -u "$IRON_USER")
    MITM_PORT=8080

    # Зберігаємо поточні правила
    iptables-save > "${IRON_HOME}/iptables-backup.rules" 2>/dev/null || true

    # Пропускаємо трафік iron (запобігаємо петлі)
    iptables -t nat -I OUTPUT -m owner --uid-owner "$IRON_UID" -j RETURN 2>/dev/null || true
    # Пропускаємо root трафік mitmproxy
    iptables -t nat -I OUTPUT -m owner --uid-owner 0 -p tcp --sport "$MITM_PORT" -j RETURN 2>/dev/null || true

    # Redirect HTTP/HTTPS
    iptables -t nat -A OUTPUT -p tcp --dport 80 -m owner ! --uid-owner "$IRON_UID" -j REDIRECT --to-port "$MITM_PORT" 2>/dev/null || true
    iptables -t nat -A OUTPUT -p tcp --dport 443 -m owner ! --uid-owner "$IRON_UID" -j REDIRECT --to-port "$MITM_PORT" 2>/dev/null || true

    log_ok "iptables transparent proxy rules added (80,443 → ${MITM_PORT})"
else
    log_warn "Browser watcher disabled — skipping mitmproxy setup"
fi

# --- Збільшуємо inotify watches (fs-monitor) ---
echo 65536 > /proc/sys/fs/inotify/max_user_watches 2>/dev/null || true
# Робимо постійним
if ! grep -q "fs.inotify.max_user_watches" /etc/sysctl.conf 2>/dev/null; then
    echo "fs.inotify.max_user_watches=65536" >> /etc/sysctl.conf
fi
log_ok "inotify max_user_watches set to 65536"

# ============================================================================
# Step 12: Реєстрація та запуск systemd сервісів
# ============================================================================
log_step "12/12: Registering and starting systemd services"

# Копіюємо service файли
for svc_file in "${SCRIPT_DIR}"/systemd/cp-collector-*.service; do
    if [[ -f "$svc_file" ]]; then
        install -m 644 "$svc_file" /etc/systemd/system/
    fi
done

systemctl daemon-reload

# Запускаємо кожен сервіс
STARTED=0
FAILED=0
for svc in "${SERVICES[@]}"; do
    svc_name="${svc}.service"

    # Пропускаємо browser якщо вимкнений
    if [[ "$svc" == "cp-collector-browser" && "$BROWSER_ENABLED" != "true" ]]; then
        log_warn "${svc} — skipped (mitmproxy not available)"
        continue
    fi

    systemctl enable "$svc_name" 2>/dev/null || true
    systemctl start "$svc_name" 2>/dev/null

    sleep 1

    if systemctl is-active --quiet "$svc_name"; then
        log_ok "${svc} — running"
        ((STARTED++))
    else
        log_error "${svc} — FAILED to start"
        log_info "  Check: journalctl -u ${svc} -n 30"
        ((FAILED++))
    fi
done

# ============================================================================
# Фінальна перевірка
# ============================================================================
echo ""

# Перевіряємо shell-watcher socket
SHELL_SOCK="${IRON_HOME}/watchers/shell-watcher/shell.sock"
if [[ -S "$SHELL_SOCK" ]]; then
    log_ok "Shell watcher socket active: ${SHELL_SOCK}"
else
    log_warn "Shell watcher socket not yet created (may take a moment)"
fi

# Перевіряємо що JSONL data директорії існують
for w in "${WATCHERS[@]}"; do
    DATA_DIR="${IRON_HOME}/watchers/${w}/data"
    if [[ -d "$DATA_DIR" ]]; then
        FILE_COUNT=$(find "$DATA_DIR" -name "*.jsonl" 2>/dev/null | wc -l)
        if [[ $FILE_COUNT -gt 0 ]]; then
            log_ok "${w}/data/ — ${FILE_COUNT} JSONL file(s)"
        fi
    fi
done

# ============================================================================
# Фінальні права безпеки
# ============================================================================
# Закриваємо все повторно після інсталяції
chown -R "${IRON_USER}:${IRON_USER}" "$IRON_HOME"
chmod 700 "$IRON_HOME"
chmod 600 "${IRON_HOME}/config.yaml"
chmod -R 700 "${IRON_HOME}/bin"

# JSONL data файли: iron:iron, 640 (root може читати через group)
find "${IRON_HOME}/watchers" -name "*.jsonl" -exec chmod 640 {} \; 2>/dev/null || true

# Socket shell-watcher — ЄДИНИЙ елемент доступний учасникам (shell hooks пишуть від їх імені)
if [[ -S "$SHELL_SOCK" ]]; then
    chmod 666 "$SHELL_SOCK"
fi

# ============================================================================
# Результат
# ============================================================================
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║                                                          ║${NC}"
echo -e "${GREEN}║          ${BOLD}Installation complete!${NC}${GREEN}                          ║${NC}"
echo -e "${GREEN}║                                                          ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}Configuration:${NC}"
echo -e "    Event ID:      ${CYAN}${EVENT_ID}${NC}"
echo -e "    Machine ID:    ${CYAN}${MACHINE_ID}${NC}"
echo -e "    Player ID:     ${CYAN}${PLAYER_ID}${NC}"
echo -e "    Net interface:  ${CYAN}${NET_INTERFACE}${NC}"
echo ""
echo -e "  ${BOLD}Paths:${NC}"
echo -e "    Config:        ${IRON_HOME}/config.yaml"
echo -e "    Watchers:      ${IRON_HOME}/watchers/"
echo -e "    Binaries:      ${IRON_HOME}/bin/"
echo -e "    Exports:       ${IRON_HOME}/exports/"
echo ""
echo -e "  ${BOLD}Services:  ${GREEN}${STARTED} started${NC}, ${RED}${FAILED} failed${NC}"
echo ""
echo -e "  ${BOLD}Commands:${NC}"
echo -e "    Status all:    ${CYAN}systemctl status 'cp-collector-*'${NC}"
echo -e "    Logs:          ${CYAN}journalctl -u cp-collector-shell -f${NC}"
echo -e "    Export data:   ${CYAN}${IRON_HOME}/bin/exporter -config ${IRON_HOME}/config.yaml${NC}"
echo -e "    Stop all:      ${CYAN}systemctl stop 'cp-collector-*'${NC}"
echo ""
echo -e "  ${YELLOW}⚠  Provide machine_id and player_id to the event organizer${NC}"
echo ""
