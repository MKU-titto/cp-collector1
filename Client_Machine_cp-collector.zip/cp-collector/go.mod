module github.com/cyber-polygon/cp-collector

go 1.22

require (
	github.com/cilium/ebpf v0.15.0
	github.com/fsnotify/fsnotify v1.7.0
	github.com/google/gopacket v1.1.19
	gopkg.in/yaml.v3 v3.0.1
)

require golang.org/x/sys v0.20.0 // indirect
