// SPDX-License-Identifier: GPL-2.0
// ============================================================================
// Cyber Polygon — interactive-watcher eBPF program
//
// Перехоплює stdin (fd=0) та stdout/stderr (fd=1,2) для цільових PID.
// Цільові PID керуються з userspace через BPF map target_pids.
//
// Tracepoints:
//   - sys_enter_read  → зберігає args (fd, buf) для read
//   - sys_exit_read   → читає дані з user buffer, відправляє в ring buffer
//   - sys_enter_write → зберігає args (fd, buf) для write
//   - sys_exit_write  → читає дані з user buffer, відправляє в ring buffer
//
// Покращення порівняно з v1:
//   - Захоплює і stdin, і stdout/stderr (v1 мав тільки stdin)
//   - event_type поле розрізняє read (0) та write (1)
//   - Без хардкоду IRON_UID — фільтрація в userspace
// ============================================================================

//go:build ignore

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

#define MAX_DATA_LEN 4096
#define MAX_PIDS     256

#define EVENT_TYPE_READ  0   // stdin (fd=0)
#define EVENT_TYPE_WRITE 1   // stdout/stderr (fd=1,2)

// Event — структура яка передається в userspace через ring buffer.
// УВАГА: порядок полів та padding мають відповідати Go-структурі ebpfEvent.
struct event {
    __u32 pid;
    __u32 tid;
    __u32 fd;
    __u32 event_type;    // EVENT_TYPE_READ або EVENT_TYPE_WRITE
    __s64 ret;
    __u64 timestamp_ns;
    __u32 data_len;
    __u32 _pad;          // вирівнювання до 8 байт
    char  comm[16];
    char  data[MAX_DATA_LEN];
};

// target_pids — набір PID для моніторингу. Керується з Go.
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, MAX_PIDS);
    __type(key, __u32);
    __type(value, __u8);
} target_pids SEC(".maps");

// events — ring buffer для передачі подій в userspace.
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 256 * 1024); // 256KB
} events SEC(".maps");

// Тимчасове сховище аргументів між enter та exit syscall.
struct rw_args {
    __u32 fd;
    __u32 event_type;
    char *buf;
};

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 4096);
    __type(key, __u64);   // tid (thread id)
    __type(value, struct rw_args);
} active_rw SEC(".maps");

// ============================================================================
// sys_read — перехоплення stdin (fd=0)
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_read")
int tracepoint__sys_enter_read(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;

    // Перевіряємо чи цей PID в нашому target set
    __u8 *val = bpf_map_lookup_elem(&target_pids, &pid);
    if (!val)
        return 0;

    // Тільки stdin (fd == 0)
    int fd = (int)ctx->args[0];
    if (fd != 0)
        return 0;

    __u64 tid = bpf_get_current_pid_tgid();
    struct rw_args args = {
        .fd = (__u32)fd,
        .event_type = EVENT_TYPE_READ,
        .buf = (char *)ctx->args[1],
    };
    bpf_map_update_elem(&active_rw, &tid, &args, BPF_ANY);

    return 0;
}

SEC("tracepoint/syscalls/sys_exit_read")
int tracepoint__sys_exit_read(struct trace_event_raw_sys_exit *ctx)
{
    __u64 tid = bpf_get_current_pid_tgid();
    __u32 pid = tid >> 32;

    struct rw_args *args = bpf_map_lookup_elem(&active_rw, &tid);
    if (!args)
        return 0;

    // Перевіряємо що це наш read event (не write)
    if (args->event_type != EVENT_TYPE_READ) {
        bpf_map_delete_elem(&active_rw, &tid);
        return 0;
    }

    bpf_map_delete_elem(&active_rw, &tid);

    __s64 ret = ctx->ret;
    if (ret <= 0)
        return 0;

    struct event *e = bpf_ringbuf_reserve(&events, sizeof(struct event), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->tid = (__u32)tid;
    e->fd = args->fd;
    e->event_type = EVENT_TYPE_READ;
    e->ret = ret;
    e->timestamp_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&e->comm, sizeof(e->comm));

    __u32 read_len = (__u32)ret;
    if (read_len > MAX_DATA_LEN)
        read_len = MAX_DATA_LEN;
    e->data_len = read_len;

    if (bpf_probe_read_user(e->data, read_len, args->buf) < 0) {
        bpf_ringbuf_discard(e, 0);
        return 0;
    }

    bpf_ringbuf_submit(e, 0);
    return 0;
}

// ============================================================================
// sys_write — перехоплення stdout (fd=1) та stderr (fd=2)
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_write")
int tracepoint__sys_enter_write(struct trace_event_raw_sys_enter *ctx)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;

    __u8 *val = bpf_map_lookup_elem(&target_pids, &pid);
    if (!val)
        return 0;

    // Тільки stdout (fd=1) та stderr (fd=2)
    int fd = (int)ctx->args[0];
    if (fd != 1 && fd != 2)
        return 0;

    __u64 tid = bpf_get_current_pid_tgid();
    struct rw_args args = {
        .fd = (__u32)fd,
        .event_type = EVENT_TYPE_WRITE,
        .buf = (char *)ctx->args[1],
    };
    bpf_map_update_elem(&active_rw, &tid, &args, BPF_ANY);

    return 0;
}

SEC("tracepoint/syscalls/sys_exit_write")
int tracepoint__sys_exit_write(struct trace_event_raw_sys_exit *ctx)
{
    __u64 tid = bpf_get_current_pid_tgid();
    __u32 pid = tid >> 32;

    struct rw_args *args = bpf_map_lookup_elem(&active_rw, &tid);
    if (!args)
        return 0;

    if (args->event_type != EVENT_TYPE_WRITE) {
        bpf_map_delete_elem(&active_rw, &tid);
        return 0;
    }

    bpf_map_delete_elem(&active_rw, &tid);

    __s64 ret = ctx->ret;
    if (ret <= 0)
        return 0;

    struct event *e = bpf_ringbuf_reserve(&events, sizeof(struct event), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->tid = (__u32)tid;
    e->fd = args->fd;
    e->event_type = EVENT_TYPE_WRITE;
    e->ret = ret;
    e->timestamp_ns = bpf_ktime_get_ns();
    bpf_get_current_comm(&e->comm, sizeof(e->comm));

    __u32 write_len = (__u32)ret;
    if (write_len > MAX_DATA_LEN)
        write_len = MAX_DATA_LEN;
    e->data_len = write_len;

    if (bpf_probe_read_user(e->data, write_len, args->buf) < 0) {
        bpf_ringbuf_discard(e, 0);
        return 0;
    }

    bpf_ringbuf_submit(e, 0);
    return 0;
}

char LICENSE[] SEC("license") = "GPL";
