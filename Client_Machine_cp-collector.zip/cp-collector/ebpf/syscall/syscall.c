// SPDX-License-Identifier: GPL-2.0
// ============================================================================
// Cyber Polygon — syscall-monitor eBPF program
//
// Перехоплює цільові системні виклики та надсилає events в userspace.
// Фільтрує kernel threads та процеси користувача iron.
//
// Покращення порівняно з v1:
//   - Динамічний UID iron через filter_config map (не #define)
//   - UID включений в event struct для userspace фільтрації
//   - Спільна helper-функція emit_event для всіх tracepoints
// ============================================================================

//go:build ignore

#include "vmlinux.h"
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

struct syscall_event {
    __u32 pid;
    __u32 tid;
    __u32 uid;
    __u32 syscall_nr;
    __s64 ret_val;
    __u64 timestamp_ns;
    char  comm[16];
    __u64 arg0;
    __u64 arg1;
    __u64 arg2;
};

// Ring buffer для передачі подій.
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 512 * 1024); // 512KB
} syscall_events SEC(".maps");

// Конфігурація фільтрації — заповнюється з Go при старті.
// key=0 → UID iron user (пропускати)
struct {
    __uint(type, BPF_MAP_TYPE_ARRAY);
    __uint(max_entries, 4);
    __type(key, __u32);
    __type(value, __u32);
} filter_config SEC(".maps");

// emit_event — спільна функція для всіх syscall handlers.
static __always_inline int emit_event(__u32 syscall_nr, __u64 a0, __u64 a1, __u64 a2)
{
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    __u32 tid = (__u32)bpf_get_current_pid_tgid();

    // Пропускаємо kernel threads
    if (pid == 0)
        return 0;

    // Отримуємо UID поточного процесу
    __u32 uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;

    // Фільтруємо по UID iron (динамічний, з map)
    __u32 key = 0;
    __u32 *iron_uid = bpf_map_lookup_elem(&filter_config, &key);
    if (iron_uid && uid == *iron_uid)
        return 0;

    // Пропускаємо root (uid=0) — наші сервіси працюють від root
    // Але root-процеси учасника (sudo, SUID) теж мають uid=0,
    // тому фільтруємо тільки по comm name
    char comm[16];
    bpf_get_current_comm(&comm, sizeof(comm));

    // Пропускаємо cp-collector процеси (comm починається з "cp-collec" або назви watchers)
    // comm обмежений 16 байтами ядром, тому "cp-collector-shell" → "cp-collector-she"
    if (comm[0] == 'c' && comm[1] == 'p' && comm[2] == '-')
        return 0;
    // shell-watcher, syscall-monitor тощо — бінарники що починаються з відомих префіксів
    if (comm[0] == 's' && comm[1] == 'h' && comm[2] == 'e' && comm[3] == 'l' && comm[4] == 'l' && comm[5] == '-')
        return 0;
    if (comm[0] == 'n' && comm[1] == 'e' && comm[2] == 't' && comm[3] == '-' && comm[4] == 's')
        return 0;
    if (comm[0] == 'f' && comm[1] == 's' && comm[2] == '-' && comm[3] == 'm')
        return 0;
    if (comm[0] == 'b' && comm[1] == 'r' && comm[2] == 'o' && comm[3] == 'w' && comm[4] == 's')
        return 0;
    if (comm[0] == 'p' && comm[1] == 'r' && comm[2] == 'o' && comm[3] == 'c' && comm[4] == '-')
        return 0;
    if (comm[0] == 'i' && comm[1] == 'n' && comm[2] == 't' && comm[3] == 'e' && comm[4] == 'r')
        return 0;
    if (comm[0] == 's' && comm[1] == 'y' && comm[2] == 's' && comm[3] == 'c' && comm[4] == 'a')
        return 0;
    if (comm[0] == 'e' && comm[1] == 'x' && comm[2] == 'p' && comm[3] == 'o' && comm[4] == 'r')
        return 0;

    struct syscall_event *e = bpf_ringbuf_reserve(&syscall_events, sizeof(*e), 0);
    if (!e)
        return 0;

    e->pid = pid;
    e->tid = tid;
    e->uid = uid;
    e->syscall_nr = syscall_nr;
    e->ret_val = 0;
    e->timestamp_ns = bpf_ktime_get_ns();
    __builtin_memcpy(e->comm, comm, sizeof(e->comm));
    e->arg0 = a0;
    e->arg1 = a1;
    e->arg2 = a2;

    bpf_ringbuf_submit(e, 0);
    return 0;
}

// ============================================================================
// Tracepoint handlers — один на кожен цільовий syscall
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_connect")
int tracepoint__syscalls__sys_enter_connect(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(42, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_bind")
int tracepoint__syscalls__sys_enter_bind(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(49, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_execve")
int tracepoint__syscalls__sys_enter_execve(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(59, ctx->args[0], ctx->args[1], 0);
}

SEC("tracepoint/syscalls/sys_enter_openat")
int tracepoint__syscalls__sys_enter_openat(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(257, ctx->args[1], ctx->args[2], 0);
}

SEC("tracepoint/syscalls/sys_enter_mmap")
int tracepoint__syscalls__sys_enter_mmap(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(9, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_mprotect")
int tracepoint__syscalls__sys_enter_mprotect(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(10, ctx->args[0], ctx->args[1], ctx->args[2]);
}

SEC("tracepoint/syscalls/sys_enter_ptrace")
int tracepoint__syscalls__sys_enter_ptrace(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(101, ctx->args[0], ctx->args[1], 0);
}

SEC("tracepoint/syscalls/sys_enter_setuid")
int tracepoint__syscalls__sys_enter_setuid(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(105, ctx->args[0], 0, 0);
}

SEC("tracepoint/syscalls/sys_enter_fork")
int tracepoint__syscalls__sys_enter_fork(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(57, 0, 0, 0);
}

SEC("tracepoint/syscalls/sys_enter_clone")
int tracepoint__syscalls__sys_enter_clone(struct trace_event_raw_sys_enter *ctx)
{
    return emit_event(56, ctx->args[0], 0, 0);
}

char LICENSE[] SEC("license") = "GPL";
