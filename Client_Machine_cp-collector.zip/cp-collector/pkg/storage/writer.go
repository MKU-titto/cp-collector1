package storage

import (
	"bufio"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/pkg/config"
)

// Writer — потокобезпечний JSONL-записувач з ротацією по розміру.
//
// Кожен watcher створює свій Writer, який пише у свою директорію:
//
//	/home/iron/watchers/{watcher-name}/data/{event}_{machine}_{timestamp}.jsonl
//
// Ротація відбувається при досягненні RotateSizeMB (за замовчуванням 50MB).
// Стиснення не застосовується — файли зберігаються як plain JSONL
// для простоти real-time дебагу (tail -f) та стійкості до збоїв.
type Writer struct {
	mu sync.Mutex

	watcherName  string
	dataDir      string
	agentCfg     config.AgentConfig
	rotateSizeMB int

	file         *os.File
	bufWriter    *bufio.Writer
	currentPath  string
	bytesWritten int64

	flushTicker *time.Ticker
	done        chan struct{}
}

// NewWriter створює Writer для конкретного watcher.
//
//	watcherName: "shell-watcher", "net-sniffer" тощо
//	agentCfg:    ідентифікація агента (для іменування файлів)
//	storageCfg:  загальні параметри зберігання
//
// Автоматично створює директорію data/ якщо не існує.
func NewWriter(watcherName string, agentCfg config.AgentConfig, storageCfg config.StorageConfig) (*Writer, error) {
	dataDir := filepath.Join(storageCfg.BasePath, watcherName, "data")
	if err := os.MkdirAll(dataDir, 0750); err != nil {
		return nil, fmt.Errorf("create data dir %s: %w", dataDir, err)
	}

	rotateMB := storageCfg.RotateSizeMB
	if rotateMB <= 0 {
		rotateMB = 50
	}

	w := &Writer{
		watcherName:  watcherName,
		dataDir:      dataDir,
		agentCfg:     agentCfg,
		rotateSizeMB: rotateMB,
		done:         make(chan struct{}),
	}

	if err := w.openNewFile(); err != nil {
		return nil, err
	}

	// Flush на диск кожну секунду — баланс між продуктивністю та збереженням даних
	w.flushTicker = time.NewTicker(1 * time.Second)
	go w.flushLoop()

	return w, nil
}

// Write серіалізує подію в JSON і записує один рядок у JSONL файл.
// Потокобезпечний — може викликатись з декількох goroutines.
func (w *Writer) Write(event interface{}) error {
	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("marshal event: %w", err)
	}
	data = append(data, '\n')

	w.mu.Lock()
	defer w.mu.Unlock()

	// Перевіряємо чи потрібна ротація
	maxBytes := int64(w.rotateSizeMB) * 1024 * 1024
	if w.bytesWritten+int64(len(data)) > maxBytes {
		if err := w.rotateFile(); err != nil {
			return fmt.Errorf("rotate: %w", err)
		}
	}

	n, err := w.bufWriter.Write(data)
	if err != nil {
		return fmt.Errorf("write event: %w", err)
	}
	w.bytesWritten += int64(n)

	return nil
}

// Flush примусово скидає буфер на диск.
func (w *Writer) Flush() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.flushLocked()
}

// Close закриває файл та зупиняє фонові goroutines.
func (w *Writer) Close() error {
	// Сигналізуємо flushLoop про зупинку
	select {
	case <-w.done:
		// Вже закрито
		return nil
	default:
		close(w.done)
	}

	w.flushTicker.Stop()

	w.mu.Lock()
	defer w.mu.Unlock()
	return w.closeCurrentFile()
}

// CurrentPath повертає шлях до поточного активного JSONL файлу.
func (w *Writer) CurrentPath() string {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.currentPath
}

// DataDir повертає шлях до директорії data/ цього watcher.
func (w *Writer) DataDir() string {
	return w.dataDir
}

// --- internal ---

// openNewFile створює новий JSONL файл з timestamp у імені.
func (w *Writer) openNewFile() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.openNewFileLocked()
}

func (w *Writer) openNewFileLocked() error {
	now := time.Now().UTC()
	filename := fmt.Sprintf("%s_%s_%s.jsonl",
		w.agentCfg.CTFEventID,
		w.agentCfg.MachineID,
		now.Format("20060102_150405"),
	)

	path := filepath.Join(w.dataDir, filename)

	f, err := os.OpenFile(path, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0640)
	if err != nil {
		return fmt.Errorf("open log file %s: %w", path, err)
	}

	w.file = f
	w.currentPath = path
	w.bytesWritten = 0
	w.bufWriter = bufio.NewWriterSize(f, 64*1024) // 64KB buffer

	log.Printf("[%s] opened log file: %s", w.watcherName, path)
	return nil
}

// rotateFile закриває поточний файл та відкриває новий.
func (w *Writer) rotateFile() error {
	if err := w.closeCurrentFile(); err != nil {
		log.Printf("[%s] warning: close on rotate: %v", w.watcherName, err)
	}
	return w.openNewFileLocked()
}

func (w *Writer) closeCurrentFile() error {
	if w.bufWriter != nil {
		if err := w.bufWriter.Flush(); err != nil {
			return fmt.Errorf("flush buffer: %w", err)
		}
	}
	if w.file != nil {
		if err := w.file.Sync(); err != nil {
			return fmt.Errorf("sync file: %w", err)
		}
		if err := w.file.Close(); err != nil {
			return fmt.Errorf("close file: %w", err)
		}
		w.file = nil
	}
	return nil
}

func (w *Writer) flushLocked() error {
	if w.bufWriter != nil {
		if err := w.bufWriter.Flush(); err != nil {
			return err
		}
	}
	if w.file != nil {
		return w.file.Sync()
	}
	return nil
}

func (w *Writer) flushLoop() {
	for {
		select {
		case <-w.flushTicker.C:
			if err := w.Flush(); err != nil {
				log.Printf("[%s] flush error: %v", w.watcherName, err)
			}
		case <-w.done:
			return
		}
	}
}
