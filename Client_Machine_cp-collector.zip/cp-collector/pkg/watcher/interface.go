package watcher

import "context"

// Watcher — інтерфейс який реалізує кожен модуль збору даних.
// Кожен watcher запускається як окремий процес (systemd сервіс).
type Watcher interface {
	// Name повертає ідентифікатор watcher (використовується для шляху до data/).
	// Приклад: "shell-watcher", "net-sniffer"
	Name() string

	// Start запускає збір даних. Блокує до скасування ctx.
	Start(ctx context.Context) error

	// Stop коректно зупиняє watcher — flush буферів, закриття з'єднань.
	Stop() error
}
