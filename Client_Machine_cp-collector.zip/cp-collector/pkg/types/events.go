package types

// ============================================================================
// Структури подій — кожен watcher генерує свій тип JSON-подій.
// Усі поля мають json-теги для серіалізації в JSONL.
// ============================================================================

// --- shell-watcher ---

// ShellCommandEvent — виконання команди в терміналі (bash/zsh).
// Джерело: preexec/precmd hooks → UNIX socket → shell-watcher.
type ShellCommandEvent struct {
	Type           string   `json:"type"`            // "shell_command"
	TimestampStart string   `json:"timestamp_start"` // ISO 8601, початок виконання
	TimestampEnd   string   `json:"timestamp_end"`   // ISO 8601, кінець виконання
	SessionID      string   `json:"session_id"`      // Унікальний ID сесії (tty + pid)
	MachineID      string   `json:"machine_id"`
	PlayerID       string   `json:"player_id"`
	CTFEventID     string   `json:"ctf_event_id"`
	PID            int      `json:"pid"`
	TTY            string   `json:"tty"`
	CWD            string   `json:"cwd"`
	Shell          string   `json:"shell"` // "bash" | "zsh"
	Command        string   `json:"command"`
	Argv           []string `json:"argv"`
	ExitCode       int      `json:"exit_code"`
	StdoutPreview  string   `json:"stdout_preview"`
	StdoutSize     int64    `json:"stdout_size_bytes"`
	StderrPreview  string   `json:"stderr_preview,omitempty"`
	StderrSize     int64    `json:"stderr_size_bytes"`
	DurationMs     int64    `json:"duration_ms"`
}

// --- interactive-watcher ---

// InteractiveInputEvent — введення у інтерактивний REPL-інструмент.
// Джерело: eBPF hook на sys_read(fd=0) для цільових процесів.
type InteractiveInputEvent struct {
	Type            string `json:"type"`             // "interactive_input"
	Timestamp       string `json:"timestamp"`        // ISO 8601
	SessionID       string `json:"session_id"`       // "interactive_{pid}"
	MachineID       string `json:"machine_id"`
	PlayerID        string `json:"player_id"`
	CTFEventID      string `json:"ctf_event_id"`
	PID             int    `json:"pid"`
	ProcessName     string `json:"process_name"`     // Ім'я процесу (gdb, msfconsole)
	ParentCommand   string `json:"parent_command"`   // Повний cmdline батьківського процесу
	InputLine       string `json:"input_line"`       // Що ввів користувач
	ResponsePreview string `json:"response_preview,omitempty"` // stdout відповідь (якщо захоплено)
	ResponseSize    int64  `json:"response_size_bytes,omitempty"`
}

// --- proc-monitor ---

// ProcessSpawnEvent — запуск нового процесу.
// Джерело: сканування /proc + опціонально auditd.
type ProcessSpawnEvent struct {
	Type         string   `json:"type"`          // "process_spawn"
	Timestamp    string   `json:"timestamp"`
	MachineID    string   `json:"machine_id"`
	PlayerID     string   `json:"player_id"`
	CTFEventID   string   `json:"ctf_event_id"`
	PID          int      `json:"pid"`
	PPID         int      `json:"ppid"`
	BinaryPath   string   `json:"binary_path"`
	BinarySHA256 string   `json:"binary_sha256"`
	Argv         []string `json:"argv"`
	CWD          string   `json:"cwd"`
	UID          int      `json:"uid"`
	GID          int      `json:"gid"`
	IsCTFTool    bool     `json:"is_ctf_tool"`
	ToolCategory string   `json:"tool_category,omitempty"` // "recon", "exploit", "pwn" тощо
}

// ProcessExitEvent — завершення процесу.
type ProcessExitEvent struct {
	Type       string `json:"type"` // "process_exit"
	Timestamp  string `json:"timestamp"`
	MachineID  string `json:"machine_id"`
	CTFEventID string `json:"ctf_event_id"`
	PID        int    `json:"pid"`
	ExitCode   int    `json:"exit_code"`
	DurationMs int64  `json:"duration_ms"`
}

// --- net-sniffer ---

// NetworkConnectionEvent — мережеве з'єднання (TCP/UDP flow).
// Джерело: libpcap з connection tracking.
type NetworkConnectionEvent struct {
	Type          string `json:"type"`      // "network_connection"
	Timestamp     string `json:"timestamp"` // Час початку flow
	MachineID     string `json:"machine_id"`
	PlayerID      string `json:"player_id"`
	CTFEventID    string `json:"ctf_event_id"`
	PID           int    `json:"pid"`
	ProcessName   string `json:"process_name"`
	Protocol      string `json:"protocol"`  // "TCP" | "UDP"
	SrcIP         string `json:"src_ip"`
	SrcPort       int    `json:"src_port"`
	DstIP         string `json:"dst_ip"`
	DstPort       int    `json:"dst_port"`
	Direction     string `json:"direction"` // "inbound" | "outbound"
	State         string `json:"state"`     // TCP: SYN_SENT, ESTABLISHED, FIN, RST; UDP: ACTIVE
	BytesSent     int64  `json:"bytes_sent"`
	BytesReceived int64  `json:"bytes_received"`
	DurationMs    int64  `json:"duration_ms"`
}

// DNSQueryEvent — DNS запит та відповідь.
type DNSQueryEvent struct {
	Type       string   `json:"type"` // "dns_query"
	Timestamp  string   `json:"timestamp"`
	MachineID  string   `json:"machine_id"`
	CTFEventID string   `json:"ctf_event_id"`
	PID        int      `json:"pid"`
	Domain     string   `json:"domain"`
	QueryType  string   `json:"query_type"` // "A", "AAAA", "CNAME" тощо
	Answers    []string `json:"answers,omitempty"`
	LatencyMs  int64    `json:"latency_ms"`
}

// --- browser-watcher ---

// BrowserRequestEvent — HTTP/HTTPS запит через браузер.
// Джерело: mitmproxy transparent proxy → Python addon → UNIX socket.
type BrowserRequestEvent struct {
	Type                string `json:"type"` // "browser_request"
	Timestamp           string `json:"timestamp"`
	MachineID           string `json:"machine_id"`
	PlayerID            string `json:"player_id"`
	CTFEventID          string `json:"ctf_event_id"`
	Method              string `json:"method"` // GET, POST, PUT тощо
	URL                 string `json:"url"`
	Referer             string `json:"referer,omitempty"`
	RequestBodyPreview  string `json:"request_body_preview,omitempty"`
	RequestBodySize     int64  `json:"request_body_size_bytes,omitempty"`
	ResponseStatus      int    `json:"response_status"`
	ResponseContentType string `json:"response_content_type,omitempty"`
	ResponseBodyPreview string `json:"response_body_preview,omitempty"`
	ResponseSize        int64  `json:"response_size_bytes,omitempty"`
	LatencyMs           int64  `json:"latency_ms"`
	TLS                 bool   `json:"tls"`
}

// --- fs-monitor ---

// FSEvent — файлова операція.
// Джерело: inotify (fsnotify) на цільових директоріях.
type FSEvent struct {
	Type           string `json:"type"` // "fs_event"
	Timestamp      string `json:"timestamp"`
	MachineID      string `json:"machine_id"`
	PlayerID       string `json:"player_id"`
	CTFEventID     string `json:"ctf_event_id"`
	PID            int    `json:"pid"`
	ProcessName    string `json:"process_name"`
	Operation      string `json:"operation"` // CREATE, WRITE, DELETE, RENAME, CHMOD
	Path           string `json:"path"`
	FileType       string `json:"file_type,omitempty"` // "python_script", "config", "binary" тощо
	SizeBytes      int64  `json:"size_bytes,omitempty"`
	SHA256         string `json:"sha256,omitempty"`
	ContentPreview string `json:"content_preview,omitempty"`
	Copied         bool   `json:"copied,omitempty"` // true якщо файл скопійовано в copied_files/
}

// --- syscall-monitor ---

// SyscallEvent — системний виклик.
// Джерело: eBPF tracepoints на цільових syscalls.
type SyscallEvent struct {
	Type       string   `json:"type"` // "syscall"
	Timestamp  string   `json:"timestamp"`
	MachineID  string   `json:"machine_id"`
	CTFEventID string   `json:"ctf_event_id"`
	PID        int      `json:"pid"`
	TID        int      `json:"tid"`
	Comm       string   `json:"comm"`    // Ім'я процесу (comm з /proc)
	Syscall    string   `json:"syscall"` // "connect", "execve", "mmap" тощо
	Args       []string `json:"args,omitempty"`
	RetVal     int64    `json:"ret_val"`
}

// ============================================================================
// Довідники (maps) — використовуються watchers для класифікації подій.
// ============================================================================

// CTFToolMap — відображення імені бінарника → категорія CTF-інструменту.
// Використовується proc-monitor для тегування process_spawn подій.
var CTFToolMap = map[string]string{
	// recon — розвідка та сканування
	"nmap": "recon", "masscan": "recon", "gobuster": "recon",
	"ffuf": "recon", "nikto": "recon", "dirbuster": "recon",
	"feroxbuster": "recon", "amass": "recon", "subfinder": "recon",
	"zenmap": "recon",

	// web — веб-атаки та інструменти
	"burpsuite": "web", "sqlmap": "web", "wfuzz": "web",
	"hydra": "web", "curl": "web", "wget": "web",
	"httpx": "web", "nuclei": "web",

	// exploit — експлуатація вразливостей
	"msfconsole": "exploit", "msfvenom": "exploit", "searchsploit": "exploit",
	"metasploit": "exploit",

	// pwn — binary exploitation
	"gdb": "pwn", "pwndbg": "pwn", "checksec": "pwn",
	"pwntools": "pwn", "ropper": "pwn", "ropgadget": "pwn",

	// reverse — реверс-інженерія
	"ghidra": "reverse", "radare2": "reverse", "r2": "reverse",
	"ltrace": "reverse", "strace": "reverse", "ida": "reverse",
	"cutter": "reverse",

	// crypto — криптоаналіз
	"hashcat": "crypto", "john": "crypto", "openssl": "crypto",
	"hashid": "crypto",

	// forensics — цифрова криміналістика
	"binwalk": "forensics", "volatility": "forensics", "strings": "forensics",
	"xxd": "forensics", "file": "forensics", "exiftool": "forensics",
	"foremost": "forensics", "steghide": "forensics",

	// network — мережеві інструменти
	"wireshark": "network", "tcpdump": "network", "netcat": "network",
	"socat": "network", "ncat": "network", "nc": "network",
	"tshark": "network",

	// uav — безпілотники (SkyRift сценарій)
	"mavproxy.py": "uav", "pymavlink": "uav",

	// ad_attack — Active Directory атаки
	"rubeus": "ad_attack", "mimikatz": "ad_attack", "crackmapexec": "ad_attack",
	"evil-winrm": "ad_attack", "bloodhound": "ad_attack", "impacket": "ad_attack",
	"kerbrute": "ad_attack", "responder": "ad_attack",

	// rdp — віддалений доступ
	"xfreerdp": "rdp", "xfreerdp3": "rdp", "rdesktop": "rdp",

	// ssh — SSH інструменти
	"ssh": "ssh", "scp": "ssh", "sftp": "ssh", "ssh-keygen": "ssh",

	// privesc — підвищення привілеїв
	"linpeas": "privesc", "winpeas": "privesc", "linenum": "privesc",
	"pspy": "privesc", "sudo": "privesc",
}

// InteractiveTargetProcesses — процеси, stdin яких перехоплює interactive-watcher.
// Це REPL-інструменти, де стандартні shell hooks не працюють.
var InteractiveTargetProcesses = map[string]bool{
	"gdb":          true,
	"pwndbg":       true,
	"msfconsole":   true,
	"python3":      true,
	"python":       true,
	"python2":      true,
	"ipython":      true,
	"ipython3":     true,
	"sqlmap":       true,
	"radare2":      true,
	"r2":           true,
	"nc":           true,
	"ncat":         true,
	"socat":        true,
	"mavproxy.py":  true,
	"mysql":        true,
	"psql":         true,
	"sqlite3":      true,
	"ssh":          true,
	"ftp":          true,
	"telnet":       true,
	"irb":          true,
	"node":         true,
	"lua":          true,
	"php":          true,
	"evil-winrm":   true,
	"crackmapexec": true,
	"impacket-smbexec":  true,
	"impacket-wmiexec":  true,
	"impacket-psexec":   true,
	"impacket-atexec":   true,
	"responder":         true,
}

// CopyableExtensions — розширення файлів, які fs-monitor копіює в copied_files/.
// Це скрипти та конфіги учасника, важливі для відтворення траєкторії.
var CopyableExtensions = map[string]bool{
	".py": true, ".sh": true, ".php": true, ".rb": true,
	".c": true, ".cpp": true, ".h": true,
	".txt": true, ".md": true,
	".pl": true, ".js": true, ".ts": true,
	".ps1": true, ".bat": true, ".cmd": true,
	".conf": true, ".cfg": true, ".ini": true,
	".yml": true, ".yaml": true, ".json": true, ".xml": true,
	".sql": true, ".html": true, ".css": true,
	".asm": true, ".nasm": true,
	".exp": true, // pwntools exploit scripts
}

// TargetSyscalls — системні виклики, які відстежує syscall-monitor.
var TargetSyscalls = []string{
	"connect",  // Мережеві з'єднання
	"bind",     // Прослуховування портів
	"execve",   // Запуск процесів
	"openat",   // Відкриття файлів
	"read",     // Читання (для цільових fd)
	"write",    // Запис (для цільових fd)
	"mmap",     // Маппінг пам'яті (shellcode)
	"mprotect", // Зміна захисту пам'яті (RWX)
	"setuid",   // Зміна UID (privesc)
	"ptrace",   // Дебаг / injection
	"fork",     // Створення процесу
	"clone",    // Створення потоку/процесу
}
