package config

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// Config — кореневий конфіг, єдиний для всіх модулів.
// Зберігається в /home/iron/config.yaml
type Config struct {
	Agent       AgentConfig       `yaml:"agent"`
	Storage     StorageConfig     `yaml:"storage"`
	Shell       ShellConfig       `yaml:"shell"`
	Interactive InteractiveConfig `yaml:"interactive"`
	Proc        ProcConfig        `yaml:"proc"`
	Net         NetConfig         `yaml:"net"`
	Browser     BrowserConfig     `yaml:"browser"`
	FS          FSConfig          `yaml:"fs"`
	Syscall     SyscallConfig     `yaml:"syscall"`
}

// AgentConfig — ідентифікація агента та CTF-події.
type AgentConfig struct {
	Type       string `yaml:"type"`         // "client_machine" | "linux_machine"
	Version    string `yaml:"version"`      // "2.0"
	CTFEventID string `yaml:"ctf_event_id"` // ID події, задається при інсталяції
	MachineID  string `yaml:"machine_id"`   // hostname_sha256(mac)[:8]
	PlayerID   string `yaml:"player_id"`    // UUID учасника
}

// StorageConfig — загальні параметри зберігання даних.
type StorageConfig struct {
	BasePath     string `yaml:"base_path"`      // /home/iron/watchers
	RotateSizeMB int    `yaml:"rotate_size_mb"` // Ротація JSONL файлу при досягненні розміру (MB)
	ExportPath   string `yaml:"export_path"`    // /home/iron/exports
}

// ShellConfig — налаштування shell-watcher.
type ShellConfig struct {
	Enabled        bool   `yaml:"enabled"`
	SocketPath     string `yaml:"socket_path"`      // UNIX socket для прийому подій від bash/zsh hooks
	MaxStdoutBytes int64  `yaml:"max_stdout_bytes"` // Максимальний розмір stdout preview
	MaxStderrBytes int64  `yaml:"max_stderr_bytes"`
}

// InteractiveConfig — налаштування interactive-watcher (eBPF).
type InteractiveConfig struct {
	Enabled         bool   `yaml:"enabled"`
	ScanIntervalSec int    `yaml:"scan_interval_sec"` // Інтервал сканування /proc на цільові процеси
	EbpfObjectPath  string `yaml:"ebpf_object_path"`  // Шлях до скомпільованого eBPF .o
}

// ProcConfig — налаштування proc-monitor.
type ProcConfig struct {
	Enabled      bool `yaml:"enabled"`
	PollInterval int  `yaml:"poll_interval_ms"` // Інтервал сканування /proc (мс)
	UseAuditd    bool `yaml:"use_auditd"`       // Використовувати auditd як додаткове джерело
}

// NetConfig — налаштування net-sniffer.
type NetConfig struct {
	Enabled    bool     `yaml:"enabled"`
	Interfaces []string `yaml:"interfaces"`        // Мережеві інтерфейси для захоплення
	BPFFilter  string   `yaml:"bpf_filter,omitempty"` // Опціональний BPF фільтр
	CaptureDNS bool     `yaml:"capture_dns"`       // Захоплювати DNS запити
}

// BrowserConfig — налаштування browser-watcher (mitmproxy).
type BrowserConfig struct {
	Enabled        bool   `yaml:"enabled"`
	MitmproxyPort  int    `yaml:"mitmproxy_port"`         // Порт transparent proxy
	MaxBodyPreview int64  `yaml:"max_body_preview_bytes"` // Розмір preview тіла HTTP
	SocketPath     string `yaml:"socket_path"`            // UNIX socket для mitmproxy addon
}

// FSConfig — налаштування fs-monitor.
type FSConfig struct {
	Enabled        bool     `yaml:"enabled"`
	WatchPaths     []string `yaml:"watch_paths"`            // Директорії для моніторингу
	ExcludePaths   []string `yaml:"exclude_paths"`          // Виключення
	MaxPreviewSize int64    `yaml:"max_preview_size_bytes"` // Розмір preview тексту файлів
	CopyFiles      bool     `yaml:"copy_files"`             // Копіювати скрипти в copied_files/
}

// SyscallConfig — налаштування syscall-monitor (eBPF).
type SyscallConfig struct {
	Enabled        bool   `yaml:"enabled"`
	EbpfObjectPath string `yaml:"ebpf_object_path"` // Шлях до скомпільованого eBPF .o
}

// Load читає та парсить конфіг з YAML-файлу.
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %s: %w", path, err)
	}

	cfg := &Config{}
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("parse config: %w", err)
	}

	if err := cfg.validate(); err != nil {
		return nil, fmt.Errorf("config validation: %w", err)
	}

	cfg.setDefaults()
	return cfg, nil
}

// validate перевіряє обов'язкові поля.
func (c *Config) validate() error {
	if c.Agent.CTFEventID == "" {
		return fmt.Errorf("agent.ctf_event_id is required")
	}
	if c.Agent.MachineID == "" {
		return fmt.Errorf("agent.machine_id is required")
	}
	if c.Agent.Type == "" {
		return fmt.Errorf("agent.type is required")
	}
	if c.Storage.BasePath == "" {
		return fmt.Errorf("storage.base_path is required")
	}
	return nil
}

// setDefaults заповнює пропущені поля значеннями за замовчуванням.
func (c *Config) setDefaults() {
	if c.Agent.Version == "" {
		c.Agent.Version = "2.0"
	}

	// Storage
	if c.Storage.RotateSizeMB == 0 {
		c.Storage.RotateSizeMB = 50
	}
	if c.Storage.ExportPath == "" {
		c.Storage.ExportPath = "/home/iron/exports"
	}

	// Shell
	if c.Shell.SocketPath == "" {
		c.Shell.SocketPath = "/home/iron/watchers/shell-watcher/shell.sock"
	}
	if c.Shell.MaxStdoutBytes == 0 {
		c.Shell.MaxStdoutBytes = 65536 // 64KB
	}
	if c.Shell.MaxStderrBytes == 0 {
		c.Shell.MaxStderrBytes = 65536
	}

	// Interactive
	if c.Interactive.ScanIntervalSec == 0 {
		c.Interactive.ScanIntervalSec = 2
	}
	if c.Interactive.EbpfObjectPath == "" {
		c.Interactive.EbpfObjectPath = "/home/iron/watchers/interactive-watcher/interactive.o"
	}

	// Proc
	if c.Proc.PollInterval == 0 {
		c.Proc.PollInterval = 500
	}

	// Net
	if len(c.Net.Interfaces) == 0 {
		c.Net.Interfaces = []string{"eth0"}
	}

	// Browser
	if c.Browser.MitmproxyPort == 0 {
		c.Browser.MitmproxyPort = 8080
	}
	if c.Browser.MaxBodyPreview == 0 {
		c.Browser.MaxBodyPreview = 4096 // 4KB
	}
	if c.Browser.SocketPath == "" {
		c.Browser.SocketPath = "/home/iron/watchers/browser-watcher/mitmproxy.sock"
	}

	// FS
	if len(c.FS.WatchPaths) == 0 {
		c.FS.WatchPaths = []string{"/home", "/tmp", "/var/tmp", "/opt"}
	}
	if c.FS.MaxPreviewSize == 0 {
		c.FS.MaxPreviewSize = 2048 // 2KB
	}

	// Syscall
	if c.Syscall.EbpfObjectPath == "" {
		c.Syscall.EbpfObjectPath = "/home/iron/watchers/syscall-monitor/syscall.o"
	}
}
