#!/bin/bash
# ============================================================================
# Cyber Polygon — Linux_Machine v3 Installer
#
# Встановлює систему збору поведінкових даних CTF на цільову Linux-машину.
# 9 окремих watcher-сервісів + exporter утиліта.
#
# Використання:
#   sudo bash install.sh --event-id cyberpolygon-2026-spring
#
# Вимоги:
#   - Debian/Ubuntu Linux
#   - Root доступ
#   - Інтернет (для завантаження залежностей та Go)
# ============================================================================

set -euo pipefail

# ============================================================================
# Кольори та логування
# ============================================================================
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

log_info()  { echo -e "${CYAN}[INFO]${NC}  $1"; }
log_ok()    { echo -e "${GREEN}[ OK ]${NC}  $1"; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
log_error() { echo -e "${RED}[FAIL]${NC} $1"; }
log_step()  { echo ""; echo -e "${BOLD}${CYAN}═══ $1 ═══${NC}"; }

# ============================================================================
# Константи
# ============================================================================
IRON_USER="iron"
IRON_PASSWORD="IronAgent_password"
IRON_HOME="/home/iron"
GO_VERSION="1.22.5"
GO_URL="https://go.dev/dl/go${GO_VERSION}.linux-amd64.tar.gz"

# Список watchers (порядок важливий для відображення)
WATCHERS=(
    "auth-monitor"
    "fs-monitor"
    "service-monitor"
    "proc-monitor"
    "shell-watcher"
    "net-sniffer"
    "interactive-watcher"
    "syscall-monitor"
    "browser-watcher"
)

# Watchers з eBPF (потребують clang компіляції)
EBPF_WATCHERS=("interactive-watcher" "syscall-monitor")

# Watchers що потребують CGO (libpcap)
CGO_WATCHERS=("net-sniffer")

# ============================================================================
# Банер
# ============================================================================
echo ""
echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${CYAN}║                                                               ║${NC}"
echo -e "${CYAN}║        ${BOLD}Cyber Polygon — Linux_Machine v3 Installer${NC}${CYAN}            ║${NC}"
echo -e "${CYAN}║        CTF Behavioral Data Collection System                  ║${NC}"
echo -e "${CYAN}║                                                               ║${NC}"
echo -e "${CYAN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""

# ============================================================================
# Парсинг аргументів
# ============================================================================
EVENT_ID=""
NET_INTERFACE="eth0"
SKIP_BROWSER=0

while [[ $# -gt 0 ]]; do
    case $1 in
        --event-id)      EVENT_ID="$2"; shift 2 ;;
        --interface)     NET_INTERFACE="$2"; shift 2 ;;
        --skip-browser)  SKIP_BROWSER=1; shift ;;
        -h|--help)
            echo "Usage: sudo bash install.sh --event-id <event_id> [options]"
            echo ""
            echo "Required:"
            echo "  --event-id <id>    CTF event identifier (e.g. cyberpolygon-2026-spring)"
            echo ""
            echo "Options:"
            echo "  --interface <if>   Network interface (default: eth0)"
            echo "  --skip-browser     Skip browser-watcher (no mitmproxy)"
            echo "  -h, --help         Show this help"
            exit 0
            ;;
        *) log_error "Unknown option: $1"; exit 1 ;;
    esac
done

if [[ -z "$EVENT_ID" ]]; then
    log_error "Missing required: --event-id"
    echo "Usage: sudo bash install.sh --event-id cyberpolygon-2026-spring"
    exit 1
fi

if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run as root (sudo)"
    exit 1
fi

# Визначаємо директорію проекту (де лежить цей скрипт)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Перевіряємо що ми в правильній директорії
if [[ ! -d "$SCRIPT_DIR/shared" ]] || [[ ! -d "$SCRIPT_DIR/watchers" ]]; then
    log_error "Script must be run from cp-collector/ project directory"
    log_error "Expected directories: shared/, watchers/, exporter/"
    exit 1
fi

log_info "Project dir: $SCRIPT_DIR"
log_info "Event ID:    $EVENT_ID"
log_info "Interface:   $NET_INTERFACE"
log_info "Browser:     $([ $SKIP_BROWSER -eq 0 ] && echo 'enabled' || echo 'disabled')"

# ============================================================================
# КРОК 1: Створення користувача iron
# ============================================================================
log_step "КРОК 1/9: Створення користувача iron"

if id "$IRON_USER" &>/dev/null; then
    log_warn "User '$IRON_USER' already exists, updating password"
    echo "${IRON_USER}:${IRON_PASSWORD}" | chpasswd
else
    useradd -m -s /bin/bash "$IRON_USER"
    echo "${IRON_USER}:${IRON_PASSWORD}" | chpasswd
    log_ok "User '$IRON_USER' created"
fi

# Максимально закриваємо /home/iron
# Власник root:iron, тільки root і iron мають доступ
chown root:${IRON_USER} "${IRON_HOME}"
chmod 750 "${IRON_HOME}"

# Створюємо структуру директорій
mkdir -p "${IRON_HOME}"/{bin,config,ebpf,addon,logs,exports,files}
chown -R root:${IRON_USER} "${IRON_HOME}"
chmod 750 "${IRON_HOME}"/{bin,config,ebpf,addon,logs,exports,files}

# Логи та exports пишуться сервісами від root — iron може тільки читати
chmod 750 "${IRON_HOME}/logs"
chmod 750 "${IRON_HOME}/exports"
chmod 750 "${IRON_HOME}/files"

log_ok "Directory structure: ${IRON_HOME}/{bin,config,ebpf,addon,logs,exports,files}"

# ============================================================================
# КРОК 2: Генерація ідентифікаторів
# ============================================================================
log_step "КРОК 2/9: Генерація ідентифікаторів"

HOSTNAME_VAL=$(hostname)

# MAC адреса — шукаємо вказаний інтерфейс, потім будь-який не-lo
MAC_ADDR=$(cat "/sys/class/net/${NET_INTERFACE}/address" 2>/dev/null || \
           cat "/sys/class/net/$(ls /sys/class/net/ | grep -v lo | head -1)/address" 2>/dev/null || \
           echo "00:00:00:00:00:00")
MAC_HASH=$(echo -n "$MAC_ADDR" | sha256sum | cut -c1-8)
MACHINE_ID="${HOSTNAME_VAL}_${MAC_HASH}"

# player_id — унікальний для кожної інсталяції
PLAYER_ID=$(uuidgen 2>/dev/null || cat /proc/sys/kernel/random/uuid 2>/dev/null || echo "unknown")

log_ok "machine_id:  ${MACHINE_ID}"
log_ok "player_id:   ${PLAYER_ID}"

# ============================================================================
# КРОК 3: Встановлення системних залежностей
# ============================================================================
log_step "КРОК 3/9: Встановлення системних залежностей"

export DEBIAN_FRONTEND=noninteractive

log_info "Оновлення пакетного менеджера..."
apt-get update -qq

# Базові інструменти
log_info "Встановлення базових інструментів..."
apt-get install -y -qq \
    build-essential \
    wget \
    curl \
    git \
    ca-certificates \
    gnupg \
    lsb-release \
    uuid-runtime \
    jq \
    2>/dev/null
log_ok "Базові інструменти"

# eBPF та мережеві залежності
log_info "Встановлення eBPF та мережевих залежностей..."
apt-get install -y -qq \
    clang \
    llvm \
    libbpf-dev \
    bpfcc-tools \
    libpcap-dev \
    socat \
    auditd \
    2>/dev/null
log_ok "eBPF + мережеві залежності"

# Kernel headers
KHEADERS="linux-headers-$(uname -r)"
log_info "Встановлення kernel headers: ${KHEADERS}..."
apt-get install -y -qq "$KHEADERS" 2>/dev/null || {
    log_warn "Kernel headers '${KHEADERS}' not found"
    log_warn "eBPF watchers (interactive, syscall) may not compile"
    log_warn "Install manually: apt install linux-headers-\$(uname -r)"
}

# NTP для синхронізації часу між агентами
log_info "Встановлення NTP..."
apt-get install -y -qq ntp ntpdate 2>/dev/null || \
    apt-get install -y -qq systemd-timesyncd 2>/dev/null || true
log_ok "NTP"

# Python + mitmproxy (якщо browser-watcher увімкнений)
if [[ $SKIP_BROWSER -eq 0 ]]; then
    log_info "Встановлення Python та mitmproxy..."
    apt-get install -y -qq python3 python3-pip python3-venv 2>/dev/null
    pip3 install --break-system-packages mitmproxy 2>/dev/null || \
        pip3 install mitmproxy 2>/dev/null || {
            log_warn "mitmproxy install failed — browser-watcher disabled"
            SKIP_BROWSER=1
        }
    if [[ $SKIP_BROWSER -eq 0 ]]; then
        log_ok "Python + mitmproxy"
    fi
fi

log_ok "Всі системні залежності встановлено"

# ============================================================================
# КРОК 4: Встановлення Go
# ============================================================================
log_step "КРОК 4/9: Встановлення Go ${GO_VERSION}"

if command -v go &>/dev/null; then
    CURRENT_GO=$(go version 2>/dev/null | awk '{print $3}' | sed 's/go//')
    log_info "Go вже встановлений: ${CURRENT_GO}"
else
    log_info "Завантаження Go ${GO_VERSION}..."
    wget -q "${GO_URL}" -O /tmp/go.tar.gz
    rm -rf /usr/local/go
    tar -C /usr/local -xzf /tmp/go.tar.gz
    rm -f /tmp/go.tar.gz
    log_ok "Go ${GO_VERSION} встановлено в /usr/local/go"
fi

# Додаємо Go в PATH для поточного скрипта
export PATH="/usr/local/go/bin:${PATH}"
export GOPATH="/root/go"
export GOCACHE="/tmp/go-cache"

GO_VER=$(go version 2>/dev/null | awk '{print $3}')
log_ok "Go: ${GO_VER}"

# ============================================================================
# КРОК 5: Компіляція eBPF програм
# ============================================================================
log_step "КРОК 5/9: Компіляція eBPF програм"

ARCH=$(uname -m | sed 's/x86_64/x86/' | sed 's/aarch64/arm64/')

# Знаходимо libbpf headers
LIBBPF_INCLUDE=$(pkg-config --cflags-only-I libbpf 2>/dev/null | sed 's/-I//' || echo "")
if [[ -z "$LIBBPF_INCLUDE" ]]; then
    if [[ -f /usr/include/bpf/bpf_helpers.h ]]; then
        LIBBPF_INCLUDE="/usr/include/bpf"
    else
        LIBBPF_INCLUDE="/usr/include"
    fi
fi

log_info "eBPF: arch=${ARCH} libbpf=${LIBBPF_INCLUDE}"

for watcher in "${EBPF_WATCHERS[@]}"; do
    EBPF_DIR="${SCRIPT_DIR}/watchers/${watcher}/ebpf"
    if [[ ! -d "$EBPF_DIR" ]]; then
        log_warn "eBPF dir not found: ${EBPF_DIR}"
        continue
    fi

    for src in "${EBPF_DIR}"/*.c; do
        [[ -f "$src" ]] || continue
        obj="${src%.c}.o"
        base=$(basename "$src")

        log_info "Compiling ${watcher}/${base}..."
        clang -O2 -g -target bpf \
            -D__TARGET_ARCH_${ARCH} \
            -I"${LIBBPF_INCLUDE}" \
            -c "$src" -o "$obj" 2>&1 || {
                log_warn "Failed to compile ${base} — ${watcher} may not work"
                continue
            }
        log_ok "${watcher}/${base} → $(basename $obj)"
    done
done

# ============================================================================
# КРОК 6: Компіляція Go модулів
# ============================================================================
log_step "КРОК 6/9: Компіляція Go модулів"

cd "$SCRIPT_DIR"

# Завантажуємо залежності shared
log_info "Завантаження Go залежностей..."
cd "${SCRIPT_DIR}/shared"
go mod download 2>/dev/null || true
go mod tidy 2>/dev/null || true
cd "$SCRIPT_DIR"

# Компіляція watchers
for watcher in "${WATCHERS[@]}"; do
    WATCHER_DIR="${SCRIPT_DIR}/watchers/${watcher}"
    if [[ ! -d "$WATCHER_DIR" ]]; then
        log_warn "Watcher dir not found: ${WATCHER_DIR}"
        continue
    fi

    # Пропускаємо browser-watcher якщо --skip-browser
    if [[ "$watcher" == "browser-watcher" ]] && [[ $SKIP_BROWSER -eq 1 ]]; then
        log_warn "Skipping ${watcher} (--skip-browser)"
        continue
    fi

    BINARY_NAME="cp-${watcher}"

    log_info "Building ${BINARY_NAME}..."
    cd "$WATCHER_DIR"

    go mod download 2>/dev/null || true
    go mod tidy 2>/dev/null || true

    # CGO для watchers з libpcap
    CGO_FLAG="CGO_ENABLED=0"
    for cgo_w in "${CGO_WATCHERS[@]}"; do
        if [[ "$watcher" == "$cgo_w" ]]; then
            CGO_FLAG="CGO_ENABLED=1"
            break
        fi
    done

    eval "$CGO_FLAG" go build -ldflags="-s -w" -o "${BINARY_NAME}" . 2>&1 || {
        log_error "Failed to build ${BINARY_NAME}"
        cd "$SCRIPT_DIR"
        continue
    }

    log_ok "${BINARY_NAME}"
    cd "$SCRIPT_DIR"
done

# Компіляція exporter
log_info "Building cp-exporter..."
cd "${SCRIPT_DIR}/exporter"
go mod download 2>/dev/null || true
go mod tidy 2>/dev/null || true
CGO_ENABLED=0 go build -ldflags="-s -w" -o "cp-exporter" . 2>&1 || {
    log_error "Failed to build cp-exporter"
}
log_ok "cp-exporter"
cd "$SCRIPT_DIR"

# ============================================================================
# КРОК 7: Встановлення файлів
# ============================================================================
log_step "КРОК 7/9: Встановлення файлів"

# 7a. Бінарники → /home/iron/bin/ (root:root, 755)
for watcher in "${WATCHERS[@]}"; do
    BINARY="${SCRIPT_DIR}/watchers/${watcher}/cp-${watcher}"
    if [[ -f "$BINARY" ]]; then
        install -o root -g root -m 755 "$BINARY" "${IRON_HOME}/bin/"
        log_ok "bin: cp-${watcher}"
    fi
done

if [[ -f "${SCRIPT_DIR}/exporter/cp-exporter" ]]; then
    install -o root -g root -m 755 "${SCRIPT_DIR}/exporter/cp-exporter" "${IRON_HOME}/bin/"
    log_ok "bin: cp-exporter"
fi

# 7b. eBPF об'єкти → /home/iron/ebpf/ (root:root, 644)
for watcher in "${EBPF_WATCHERS[@]}"; do
    EBPF_DIR="${SCRIPT_DIR}/watchers/${watcher}/ebpf"
    for obj in "${EBPF_DIR}"/*.o; do
        [[ -f "$obj" ]] || continue
        install -o root -g root -m 644 "$obj" "${IRON_HOME}/ebpf/"
        log_ok "ebpf: $(basename $obj)"
    done
done

# 7c. Python addon → /home/iron/addon/ (root:root, 644)
if [[ $SKIP_BROWSER -eq 0 ]]; then
    ADDON_SRC="${SCRIPT_DIR}/watchers/browser-watcher/addon/cp_proxy.py"
    if [[ -f "$ADDON_SRC" ]]; then
        install -o root -g root -m 644 "$ADDON_SRC" "${IRON_HOME}/addon/"
        log_ok "addon: cp_proxy.py"
    fi
fi

# 7d. Shell hooks → /etc/profile.d/ та /etc/zsh/
HOOKS_DIR="${SCRIPT_DIR}/scripts/hooks"

if [[ -f "${HOOKS_DIR}/cp-bash-hook.sh" ]]; then
    install -o root -g root -m 644 "${HOOKS_DIR}/cp-bash-hook.sh" /etc/profile.d/cp-bash-hook.sh
    log_ok "hook: /etc/profile.d/cp-bash-hook.sh"
fi

if [[ -f "${HOOKS_DIR}/cp-zsh-hook.zsh" ]]; then
    mkdir -p /etc/zsh/zshrc.d 2>/dev/null || true
    install -o root -g root -m 644 "${HOOKS_DIR}/cp-zsh-hook.zsh" /etc/zsh/zshrc.d/cp-zsh-hook.zsh 2>/dev/null || true
    if [[ -f /etc/zsh/zshrc ]] && ! grep -q "cp-zsh-hook" /etc/zsh/zshrc 2>/dev/null; then
        echo '[[ -f /etc/zsh/zshrc.d/cp-zsh-hook.zsh ]] && source /etc/zsh/zshrc.d/cp-zsh-hook.zsh' >> /etc/zsh/zshrc
    fi
    log_ok "hook: /etc/zsh/zshrc.d/cp-zsh-hook.zsh"
fi

# 7e. Конфігурація → /home/iron/config/config.yaml (root:root, 600)
BROWSER_ENABLED="true"
[[ $SKIP_BROWSER -eq 1 ]] && BROWSER_ENABLED="false"

cat > "${IRON_HOME}/config/config.yaml" << ENDCONFIG
# ============================================================================
# Cyber Polygon — Linux_Machine v3 configuration
# Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)
# Machine:   ${MACHINE_ID}
# Event:     ${EVENT_ID}
# ============================================================================

agent:
  type: "linux_machine"
  version: "3.0"
  ctf_event_id: "${EVENT_ID}"
  machine_id: "${MACHINE_ID}"

storage:
  base_path: "${IRON_HOME}/logs"
  files_path: "${IRON_HOME}/files"
  max_size_gb: 10
  compression: true
  rotate_size_mb: 100
  flush_interval_ms: 1000

export:
  output_path: "${IRON_HOME}/exports"
  auto_export_on_stop: true
  encrypt: false

shell:
  enabled: true
  socket_path: "${IRON_HOME}/shell-watcher.sock"
  max_stdout_bytes: 65536
  max_stderr_bytes: 65536

interactive:
  enabled: true
  capture_stdout: true
  ebpf_object_path: "${IRON_HOME}/ebpf/interactive.o"
  max_response_bytes: 65536
  response_timeout_sec: 3
  target_tools:
    - msfconsole
    - gdb
    - python3
    - python
    - irb
    - node
    - mavproxy.py
    - mysql
    - psql
    - sqlite3
    - redis-cli
    - ssh

browser:
  enabled: ${BROWSER_ENABLED}
  mitmproxy_port: 8080
  max_body_preview_bytes: 4096
  output_socket_path: "${IRON_HOME}/mitmproxy.sock"

syscall:
  enabled: true
  ebpf_object_path: "${IRON_HOME}/ebpf/syscall.o"

net:
  enabled: true
  interfaces:
    - "${NET_INTERFACE}"
  capture_dns: true
  capture_http: true
  http_ports: [80, 443, 8080, 8443, 8000, 3000, 5000, 9090]
  max_body_preview_bytes: 4096
  scan_detection: true
  scan_threshold_ports: 20
  scan_window_sec: 10

proc:
  enabled: true
  poll_interval_ms: 500
  detect_anomalies: true

fs:
  enabled: true
  watch_paths:
    - "/home"
    - "/tmp"
    - "/var/tmp"
    - "/opt"
    - "/var/www"
    - "/srv"
    - "/etc"
    - "/root"
  exclude_paths:
    - "${IRON_HOME}"
    - "/proc"
    - "/sys"
    - "/dev"
  max_preview_size_bytes: 2048
  copy_files: true

auth:
  enabled: true
  auth_log_path: "/var/log/auth.log"
  poll_interval_ms: 500

service:
  enabled: true
  poll_interval_sec: 10
  watch_crontab: true
  watch_packages: true
  dpkg_log_path: "/var/log/dpkg.log"
ENDCONFIG

chown root:root "${IRON_HOME}/config/config.yaml"
chmod 600 "${IRON_HOME}/config/config.yaml"
log_ok "config: ${IRON_HOME}/config/config.yaml"

# ============================================================================
# КРОК 8: Реєстрація systemd сервісів + mitmproxy + iptables
# ============================================================================
log_step "КРОК 8/9: Реєстрація сервісів та налаштування мережі"

# 8a. Systemd units для кожного watcher
for watcher in "${WATCHERS[@]}"; do
    SERVICE_SRC="${SCRIPT_DIR}/watchers/${watcher}/${watcher}.service"
    SERVICE_DST="/etc/systemd/system/cp-${watcher}.service"

    # Пропускаємо browser-watcher якщо --skip-browser
    if [[ "$watcher" == "browser-watcher" ]] && [[ $SKIP_BROWSER -eq 1 ]]; then
        continue
    fi

    if [[ -f "$SERVICE_SRC" ]]; then
        install -o root -g root -m 644 "$SERVICE_SRC" "$SERVICE_DST"
        log_ok "systemd: cp-${watcher}.service"
    else
        log_warn "Service file not found: ${SERVICE_SRC}"
    fi
done

systemctl daemon-reload

# Вмикаємо всі сервіси
for watcher in "${WATCHERS[@]}"; do
    if [[ "$watcher" == "browser-watcher" ]] && [[ $SKIP_BROWSER -eq 1 ]]; then
        continue
    fi
    if [[ -f "/etc/systemd/system/cp-${watcher}.service" ]]; then
        systemctl enable "cp-${watcher}.service" 2>/dev/null
    fi
done

log_ok "Systemd services registered and enabled"

# 8b. mitmproxy CA сертифікат + iptables (якщо browser-watcher)
if [[ $SKIP_BROWSER -eq 0 ]]; then
    log_info "Налаштування mitmproxy..."

    # Генеруємо CA сертифікат (перший запуск mitmproxy)
    timeout 5 mitmdump --mode transparent -p 18080 &>/dev/null &
    MITM_PID=$!
    sleep 3
    kill $MITM_PID 2>/dev/null; wait $MITM_PID 2>/dev/null || true

    MITM_CERT="/root/.mitmproxy/mitmproxy-ca-cert.pem"
    if [[ -f "$MITM_CERT" ]]; then
        cp "$MITM_CERT" /usr/local/share/ca-certificates/mitmproxy-ca.crt
        update-ca-certificates 2>/dev/null || true
        log_ok "mitmproxy CA certificate installed"
    else
        log_warn "mitmproxy CA not generated"
    fi

    # iptables: перенаправляємо HTTP/HTTPS трафік через mitmproxy
    # ВИКЛЮЧЕННЯ: користувач iron (щоб mitmproxy не перехоплював сам себе)
    IRON_UID=$(id -u ${IRON_USER} 2>/dev/null || echo "")
    if [[ -n "$IRON_UID" ]]; then
        # Очищуємо попередні правила
        iptables -t nat -D OUTPUT -m owner --uid-owner "${IRON_UID}" -j RETURN 2>/dev/null || true
        iptables -t nat -D OUTPUT -p tcp --dport 80 -j REDIRECT --to-port 8080 2>/dev/null || true
        iptables -t nat -D OUTPUT -p tcp --dport 443 -j REDIRECT --to-port 8080 2>/dev/null || true

        # Встановлюємо нові
        iptables -t nat -I OUTPUT -m owner --uid-owner "${IRON_UID}" -j RETURN
        iptables -t nat -A OUTPUT -p tcp --dport 80 -m owner ! --uid-owner 0 -j REDIRECT --to-port 8080
        iptables -t nat -A OUTPUT -p tcp --dport 443 -m owner ! --uid-owner 0 -j REDIRECT --to-port 8080
        log_ok "iptables rules set (exclude iron + root)"
    fi
fi

# 8c. Приховуємо сервіси та файли від CTF-учасників
log_info "Закриття доступу до сервісів..."

# Фінальні права на /home/iron — тільки root може читати/писати
chown -R root:root "${IRON_HOME}/bin"
chown -R root:root "${IRON_HOME}/config"
chown -R root:root "${IRON_HOME}/ebpf"
chown -R root:root "${IRON_HOME}/addon"
chmod 700 "${IRON_HOME}/bin"
chmod 700 "${IRON_HOME}/config"
chmod 700 "${IRON_HOME}/ebpf"
chmod 700 "${IRON_HOME}/addon"

# /home/iron корінь: root:iron 710
# iron може зайти (x) щоб shell hooks могли писати у socket, але не читати (не r)
chown root:${IRON_USER} "${IRON_HOME}"
chmod 710 "${IRON_HOME}"

# Socket для shell-watcher буде створений сервісом з правами 666
# (hooks працюють від різних користувачів)

# Systemd service файли — забороняємо звичайним користувачам бачити
for watcher in "${WATCHERS[@]}"; do
    SVC="/etc/systemd/system/cp-${watcher}.service"
    [[ -f "$SVC" ]] && chmod 644 "$SVC"
done

# Приховуємо shell hooks від очей (вони все одно завантажуються автоматично)
chmod 644 /etc/profile.d/cp-bash-hook.sh 2>/dev/null || true

log_ok "Файли та сервіси захищені"

# ============================================================================
# КРОК 9: Запуск та перевірка
# ============================================================================
log_step "КРОК 9/9: Запуск сервісів"

STARTED=0
FAILED=0

for watcher in "${WATCHERS[@]}"; do
    SERVICE="cp-${watcher}.service"

    if [[ "$watcher" == "browser-watcher" ]] && [[ $SKIP_BROWSER -eq 1 ]]; then
        continue
    fi

    if [[ ! -f "/etc/systemd/system/${SERVICE}" ]]; then
        continue
    fi

    log_info "Starting ${SERVICE}..."
    systemctl start "$SERVICE" 2>/dev/null

    # Чекаємо 2 секунди і перевіряємо
    sleep 2
    if systemctl is-active --quiet "$SERVICE"; then
        log_ok "${SERVICE} is running"
        ((STARTED++))
    else
        log_error "${SERVICE} failed to start"
        journalctl -u "$SERVICE" -n 5 --no-pager 2>/dev/null | while read -r line; do
            echo "    $line"
        done
        ((FAILED++))
    fi
done

# ============================================================================
# Підсумок
# ============================================================================
echo ""
echo -e "${GREEN}╔═══════════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║             Installation complete! v3 (modular)              ║${NC}"
echo -e "${GREEN}╚═══════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Agent:       ${CYAN}Linux_Machine v3${NC}"
echo -e "  Event ID:    ${CYAN}${EVENT_ID}${NC}"
echo -e "  Machine ID:  ${CYAN}${MACHINE_ID}${NC}"
echo -e "  Player ID:   ${CYAN}${PLAYER_ID}${NC}"
echo -e "  Interface:   ${CYAN}${NET_INTERFACE}${NC}"
echo ""
echo -e "  User:        ${CYAN}${IRON_USER}${NC}"
echo -e "  Password:    ${CYAN}${IRON_PASSWORD}${NC}"
echo ""
echo -e "  Services:    ${GREEN}${STARTED} running${NC}, ${RED}${FAILED} failed${NC}"
echo ""
echo -e "  ${BOLD}Paths:${NC}"
echo -e "    Config:    ${IRON_HOME}/config/config.yaml"
echo -e "    Binaries:  ${IRON_HOME}/bin/"
echo -e "    Logs:      ${IRON_HOME}/logs/"
echo -e "    Exports:   ${IRON_HOME}/exports/"
echo ""
echo -e "  ${BOLD}Commands:${NC}"
echo -e "    Status all:   ${CYAN}systemctl list-units 'cp-*' --type=service${NC}"
echo -e "    Status one:   ${CYAN}systemctl status cp-auth-monitor${NC}"
echo -e "    View logs:    ${CYAN}journalctl -u cp-auth-monitor -f${NC}"
echo -e "    Export data:  ${CYAN}${IRON_HOME}/bin/cp-exporter -config ${IRON_HOME}/config/config.yaml${NC}"
echo -e "    Stop all:     ${CYAN}systemctl stop cp-*.service${NC}"
echo ""
echo -e "  ${YELLOW}⚠ Передайте machine_id організатору події${NC}"
echo ""
