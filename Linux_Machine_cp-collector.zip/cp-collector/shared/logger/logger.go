// Package logger забезпечує єдиний формат логування для всіх watcher-сервісів.
//
// Формат виводу:
//
//	[watcher-name] 2026-03-30 12:00:00.000000 INFO  message
//	[watcher-name] 2026-03-30 12:00:00.000000 ERROR message
//
// Логи пишуться в stdout/stderr та потрапляють у journald через systemd.
// Кожен watcher створює свій логер через logger.New("watcher-name").
package logger

import (
	"fmt"
	"io"
	"os"
	"sync"
	"time"
)

// Level визначає рівень логування.
type Level int

const (
	LevelDebug Level = iota
	LevelInfo
	LevelWarn
	LevelError
)

// String повертає текстове представлення рівня (фіксована ширина 5 символів).
func (l Level) String() string {
	switch l {
	case LevelDebug:
		return "DEBUG"
	case LevelInfo:
		return "INFO "
	case LevelWarn:
		return "WARN "
	case LevelError:
		return "ERROR"
	default:
		return "?????"
	}
}

// Logger — логер для конкретного watcher-сервісу.
type Logger struct {
	mu      sync.Mutex
	name    string
	level   Level
	out     io.Writer
	errOut  io.Writer
}

// New створює логер з іменем watcher-сервісу.
// INFO та нижче пишуться в stdout, ERROR — в stderr.
func New(watcherName string) *Logger {
	return &Logger{
		name:   watcherName,
		level:  LevelInfo,
		out:    os.Stdout,
		errOut: os.Stderr,
	}
}

// SetLevel встановлює мінімальний рівень логування.
func (l *Logger) SetLevel(level Level) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.level = level
}

// SetOutput замінює writer для stdout (для тестування).
func (l *Logger) SetOutput(w io.Writer) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.out = w
}

// SetErrorOutput замінює writer для stderr (для тестування).
func (l *Logger) SetErrorOutput(w io.Writer) {
	l.mu.Lock()
	defer l.mu.Unlock()
	l.errOut = w
}

// Debug логує повідомлення рівня DEBUG.
func (l *Logger) Debug(format string, args ...interface{}) {
	l.log(LevelDebug, format, args...)
}

// Info логує повідомлення рівня INFO.
func (l *Logger) Info(format string, args ...interface{}) {
	l.log(LevelInfo, format, args...)
}

// Warn логує повідомлення рівня WARN.
func (l *Logger) Warn(format string, args ...interface{}) {
	l.log(LevelWarn, format, args...)
}

// Error логує повідомлення рівня ERROR.
func (l *Logger) Error(format string, args ...interface{}) {
	l.log(LevelError, format, args...)
}

// log — внутрішня функція запису.
func (l *Logger) log(level Level, format string, args ...interface{}) {
	l.mu.Lock()
	defer l.mu.Unlock()

	if level < l.level {
		return
	}

	ts := time.Now().UTC().Format("2006-01-02 15:04:05.000000")
	msg := fmt.Sprintf(format, args...)
	line := fmt.Sprintf("[%s] %s %s %s\n", l.name, ts, level.String(), msg)

	if level >= LevelError {
		fmt.Fprint(l.errOut, line)
	} else {
		fmt.Fprint(l.out, line)
	}
}
