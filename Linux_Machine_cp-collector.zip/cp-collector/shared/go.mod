module github.com/cyber-polygon/cp-collector/shared

go 1.22

require gopkg.in/yaml.v3 v3.0.1
