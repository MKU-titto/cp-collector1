module github.com/cyber-polygon/cp-collector/shared

go 1.22.5

toolchain go1.22.5

require gopkg.in/yaml.v3 v3.0.1
