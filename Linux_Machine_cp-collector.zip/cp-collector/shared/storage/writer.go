// Package storage забезпечує запис подій у JSONL-файли з gzip-компресією,
// автоматичною ротацією по розміру та періодичним flush.
//
// Кожен watcher створює свій Writer через NewWriter(), який пише у свою підпапку:
//
//	/home/iron/logs/<watcher-name>/<timestamp>.cplog.gz
//
// Writer є thread-safe — можна викликати Write() з різних goroutines.
package storage

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
)

// Writer записує події у JSONL .cplog.gz файли з ротацією.
type Writer struct {
	mu sync.Mutex

	// Параметри
	watcherName    string
	logDir         string
	rotateSizeBytes int64
	compression    bool
	flushInterval  time.Duration
	machineID      string
	ctfEventID     string

	// Поточний стан
	currentFile    *os.File
	gzWriter       *gzip.Writer
	currentSize    int64
	currentPath    string
	eventCount     int64
	totalEvents    int64

	// Flush timer
	flushTicker *time.Ticker
	done        chan struct{}
}

// NewWriter створює новий Writer для конкретного watcher.
//
// Створює директорію /home/iron/logs/<watcherName>/ якщо не існує.
// Запускає фоновий flush timer.
func NewWriter(watcherName string, agent config.AgentConfig, stor config.StorageConfig) (*Writer, error) {
	logDir := filepath.Join(stor.BasePath, watcherName)
	if err := os.MkdirAll(logDir, 0700); err != nil {
		return nil, fmt.Errorf("create log dir %s: %w", logDir, err)
	}

	w := &Writer{
		watcherName:     watcherName,
		logDir:          logDir,
		rotateSizeBytes: int64(stor.RotateSizeMB) * 1024 * 1024,
		compression:     stor.Compression,
		flushInterval:   time.Duration(stor.FlushIntervalMs) * time.Millisecond,
		machineID:       agent.MachineID,
		ctfEventID:      agent.CTFEventID,
		done:            make(chan struct{}),
	}

	if err := w.rotate(); err != nil {
		return nil, fmt.Errorf("create initial log file: %w", err)
	}

	// Запускаємо періодичний flush
	w.flushTicker = time.NewTicker(w.flushInterval)
	go w.flushLoop()

	return w, nil
}

// Write серіалізує подію в JSON та записує один рядок у поточний файл.
// Автоматично виконує ротацію якщо файл перевищив rotateSizeBytes.
// Thread-safe.
func (w *Writer) Write(event interface{}) error {
	data, err := json.Marshal(event)
	if err != nil {
		return fmt.Errorf("marshal event: %w", err)
	}
	data = append(data, '\n')

	w.mu.Lock()
	defer w.mu.Unlock()

	// Ротація якщо файл занадто великий
	if w.currentSize+int64(len(data)) > w.rotateSizeBytes {
		if err := w.rotateLocked(); err != nil {
			return fmt.Errorf("rotate: %w", err)
		}
	}

	var n int
	if w.compression && w.gzWriter != nil {
		n, err = w.gzWriter.Write(data)
	} else if w.currentFile != nil {
		n, err = w.currentFile.Write(data)
	} else {
		return fmt.Errorf("writer is closed")
	}

	if err != nil {
		return fmt.Errorf("write event: %w", err)
	}

	w.currentSize += int64(n)
	w.eventCount++
	w.totalEvents++

	return nil
}

// Flush примусово скидає буфери на диск. Thread-safe.
func (w *Writer) Flush() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.flushLocked()
}

// Close завершує запис: flush, закриття gzip та файлу, зупинка flush timer.
// Після Close() виклики Write() повернуть помилку.
func (w *Writer) Close() error {
	// Зупиняємо flush timer
	if w.flushTicker != nil {
		w.flushTicker.Stop()
	}
	close(w.done)

	w.mu.Lock()
	defer w.mu.Unlock()

	return w.closeLocked()
}

// Stats повертає статистику writer.
func (w *Writer) Stats() WriterStats {
	w.mu.Lock()
	defer w.mu.Unlock()
	return WriterStats{
		WatcherName:      w.watcherName,
		CurrentFile:      w.currentPath,
		CurrentSizeBytes: w.currentSize,
		EventsInFile:     w.eventCount,
		TotalEvents:      w.totalEvents,
		LogDir:           w.logDir,
	}
}

// WriterStats — статистика поточного writer.
type WriterStats struct {
	WatcherName      string `json:"watcher_name"`
	CurrentFile      string `json:"current_file"`
	CurrentSizeBytes int64  `json:"current_size_bytes"`
	EventsInFile     int64  `json:"events_in_file"`
	TotalEvents      int64  `json:"total_events"`
	LogDir           string `json:"log_dir"`
}

// ============================================================================
// Internal methods (caller must hold w.mu)
// ============================================================================

// rotate закриває поточний файл та відкриває новий. НЕ thread-safe.
func (w *Writer) rotate() error {
	w.mu.Lock()
	defer w.mu.Unlock()
	return w.rotateLocked()
}

// rotateLocked — ротація без блокування (caller тримає lock).
func (w *Writer) rotateLocked() error {
	// Закриваємо попередній файл
	if err := w.closeLocked(); err != nil {
		return err
	}

	// Генеруємо ім'я файлу з timestamp
	ts := time.Now().UTC().Format("20060102T150405Z")
	var filename string
	if w.compression {
		filename = fmt.Sprintf("%s_%s.cplog.gz", w.watcherName, ts)
	} else {
		filename = fmt.Sprintf("%s_%s.cplog", w.watcherName, ts)
	}

	w.currentPath = filepath.Join(w.logDir, filename)

	f, err := os.OpenFile(w.currentPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0600)
	if err != nil {
		return fmt.Errorf("open log file %s: %w", w.currentPath, err)
	}
	w.currentFile = f

	if w.compression {
		w.gzWriter, err = gzip.NewWriterLevel(f, gzip.BestSpeed)
		if err != nil {
			f.Close()
			return fmt.Errorf("create gzip writer: %w", err)
		}
	}

	w.currentSize = 0
	w.eventCount = 0

	return nil
}

// flushLocked скидає буфери на диск без блокування.
func (w *Writer) flushLocked() error {
	if w.compression && w.gzWriter != nil {
		if err := w.gzWriter.Flush(); err != nil {
			return fmt.Errorf("flush gzip: %w", err)
		}
	}
	if w.currentFile != nil {
		if err := w.currentFile.Sync(); err != nil {
			return fmt.Errorf("sync file: %w", err)
		}
	}
	return nil
}

// closeLocked закриває gzip writer та файл без блокування.
func (w *Writer) closeLocked() error {
	var firstErr error

	if w.gzWriter != nil {
		if err := w.gzWriter.Close(); err != nil && firstErr == nil {
			firstErr = fmt.Errorf("close gzip: %w", err)
		}
		w.gzWriter = nil
	}

	if w.currentFile != nil {
		if err := w.currentFile.Close(); err != nil && firstErr == nil {
			firstErr = fmt.Errorf("close file: %w", err)
		}
		w.currentFile = nil
	}

	return firstErr
}

// flushLoop — фоновий цикл періодичного flush.
func (w *Writer) flushLoop() {
	for {
		select {
		case <-w.flushTicker.C:
			w.mu.Lock()
			_ = w.flushLocked()
			w.mu.Unlock()
		case <-w.done:
			return
		}
	}
}
