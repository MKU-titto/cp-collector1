// Package types defines event structures for all Linux_Machine watchers.
// Every watcher imports this package to construct typed events before writing to storage.
package types

import "time"

// ============================================================================
// Base event — спільні поля для всіх подій
// ============================================================================

// BaseEvent містить поля, присутні в кожній події.
// Вбудовується (embedded) у кожну конкретну структуру.
type BaseEvent struct {
	Type       string `json:"type"`
	Timestamp  string `json:"timestamp"`
	MachineID  string `json:"machine_id"`
	CTFEventID string `json:"ctf_event_id"`
}

// NewBaseEvent створює BaseEvent з поточним UTC-часом.
func NewBaseEvent(eventType, machineID, ctfEventID string) BaseEvent {
	return BaseEvent{
		Type:       eventType,
		Timestamp:  time.Now().UTC().Format(time.RFC3339Nano),
		MachineID:  machineID,
		CTFEventID: ctfEventID,
	}
}

// ============================================================================
// Agent lifecycle events
// ============================================================================

// AgentStartEvent записується при запуску watcher-сервісу.
type AgentStartEvent struct {
	BaseEvent
	WatcherName string `json:"watcher_name"`
	Version     string `json:"version"`
}

// AgentStopEvent записується при зупинці watcher-сервісу.
type AgentStopEvent struct {
	BaseEvent
	WatcherName string `json:"watcher_name"`
	Uptime      string `json:"uptime"`
}

// ============================================================================
// shell-watcher events
// ============================================================================

// ShellCommandEvent — команда, введена в bash/zsh.
// Джерело: preexec hook → socat → UNIX socket.
type ShellCommandEvent struct {
	BaseEvent
	Command       string `json:"command"`
	Shell         string `json:"shell"`                    // bash, zsh
	User          string `json:"user"`
	WorkingDir    string `json:"working_dir"`
	ExitCode      int    `json:"exit_code"`
	StdoutPreview string `json:"stdout_preview,omitempty"` // перші N байт
	StderrPreview string `json:"stderr_preview,omitempty"`
	DurationMs    int64  `json:"duration_ms"`
}

// ============================================================================
// interactive-watcher events
// ============================================================================

// InteractiveInputEvent — введення + відповідь в інтерактивному інструменті.
// Джерело: eBPF tracepoints sys_read (fd=0) + sys_write (fd=1,2).
type InteractiveInputEvent struct {
	BaseEvent
	ProcessName       string `json:"process_name"`                  // msfconsole, gdb, python3...
	PID               int    `json:"pid"`
	InputLine         string `json:"input_line"`
	ResponsePreview   string `json:"response_preview,omitempty"`    // перші N байт stdout
	ResponseSizeBytes int64  `json:"response_size_bytes,omitempty"`
	User              string `json:"user"`
}

// ============================================================================
// browser-watcher events
// ============================================================================

// BrowserRequestEvent — HTTP/HTTPS запит через mitmproxy.
type BrowserRequestEvent struct {
	BaseEvent
	Method              string `json:"method"`
	URL                 string `json:"url"`
	Host                string `json:"host"`
	StatusCode          int    `json:"status_code"`
	ContentType         string `json:"content_type,omitempty"`
	RequestBodyPreview  string `json:"request_body_preview,omitempty"`
	ResponseBodyPreview string `json:"response_body_preview,omitempty"`
	DurationMs          int64  `json:"duration_ms"`
	User                string `json:"user"`
}

// ============================================================================
// syscall-monitor events
// ============================================================================

// SyscallEvent — перехоплений системний виклик через eBPF.
type SyscallEvent struct {
	BaseEvent
	SyscallName string `json:"syscall_name"` // connect, execve, ptrace, mmap...
	PID         int    `json:"pid"`
	PPID        int    `json:"ppid"`
	Comm        string `json:"comm"`         // process name (16 chars max)
	UID         uint32 `json:"uid"`
	ReturnCode  int    `json:"return_code"`
	Args        string `json:"args,omitempty"` // serialized arguments
}

// ============================================================================
// proc-monitor events
// ============================================================================

// ToolCategory — категорія CTF-інструменту.
type ToolCategory string

const (
	ToolRecon          ToolCategory = "recon"
	ToolExploit        ToolCategory = "exploit"
	ToolC2             ToolCategory = "c2"
	ToolPrivesc        ToolCategory = "privesc"
	ToolCredAccess     ToolCategory = "cred_access"
	ToolLateralMove    ToolCategory = "lateral_move"
	ToolPersistence    ToolCategory = "persistence"
	ToolExfiltration   ToolCategory = "exfiltration"
	ToolWebTool        ToolCategory = "web_tool"
	ToolReversing      ToolCategory = "reversing"
	ToolCrypto         ToolCategory = "crypto"
	ToolGeneral        ToolCategory = "general"
	ToolUnknown        ToolCategory = "unknown"
)

// ProcessSpawnEvent — запуск нового процесу.
// Джерело: polling /proc.
type ProcessSpawnEvent struct {
	BaseEvent
	PID          int          `json:"pid"`
	PPID         int          `json:"ppid"`
	Comm         string       `json:"comm"`
	Cmdline      string       `json:"cmdline"`
	User         string       `json:"user"`
	ToolCategory ToolCategory `json:"tool_category"`
	SHA256       string       `json:"sha256,omitempty"` // хеш бінарника
	ExePath      string       `json:"exe_path"`
}

// AnomalyType — тип аномалії процесу.
type AnomalyType string

const (
	AnomalyWebshellSpawn AnomalyType = "webshell_spawn"
	AnomalyReverseShell  AnomalyType = "reverse_shell"
	AnomalySuspiciousBin AnomalyType = "suspicious_binary"
	AnomalyPrivesc       AnomalyType = "privilege_escalation"
)

// AnomalousProcessEvent — процес з ознаками аномалії.
type AnomalousProcessEvent struct {
	BaseEvent
	PID            int         `json:"pid"`
	PPID           int         `json:"ppid"`
	Comm           string      `json:"comm"`
	Cmdline        string      `json:"cmdline"`
	User           string      `json:"user"`
	ParentComm     string      `json:"parent_comm"`
	ExePath        string      `json:"exe_path"`
	AnomalyType    AnomalyType `json:"anomaly_type"`
	AnomalyDetails string      `json:"anomaly_details"`
}

// ============================================================================
// net-sniffer events
// ============================================================================

// NetworkConnectionEvent — TCP/UDP з'єднання (inbound або outbound).
// Джерело: libpcap.
type NetworkConnectionEvent struct {
	BaseEvent
	Direction string `json:"direction"` // inbound, outbound
	Protocol  string `json:"protocol"`  // tcp, udp
	SrcIP     string `json:"src_ip"`
	SrcPort   int    `json:"src_port"`
	DstIP     string `json:"dst_ip"`
	DstPort   int    `json:"dst_port"`
	PID       int    `json:"pid,omitempty"`
	Comm      string `json:"comm,omitempty"`
}

// InboundHTTPEvent — HTTP-запит до машини (вебшели, API).
type InboundHTTPEvent struct {
	BaseEvent
	Method      string `json:"method"`
	URI         string `json:"uri"`
	Host        string `json:"host"`
	SrcIP       string `json:"src_ip"`
	SrcPort     int    `json:"src_port"`
	UserAgent   string `json:"user_agent,omitempty"`
	BodyPreview string `json:"body_preview,omitempty"`
	ContentType string `json:"content_type,omitempty"`
}

// DNSQueryEvent — DNS-запит (перехоплений з мережевого трафіку).
type DNSQueryEvent struct {
	BaseEvent
	QueryName  string   `json:"query_name"`
	QueryType  string   `json:"query_type"` // A, AAAA, CNAME, MX...
	Answers    []string `json:"answers,omitempty"`
	SrcIP      string   `json:"src_ip"`
	ResponseMs int64    `json:"response_ms,omitempty"`
}

// PortScanDetectedEvent — виявлення сканування портів.
type PortScanDetectedEvent struct {
	BaseEvent
	SourceIP   string `json:"source_ip"`
	PortsCount int    `json:"ports_count"`
	WindowSec  int    `json:"window_sec"`
	SamplePorts []int `json:"sample_ports,omitempty"` // перші N портів
}

// ============================================================================
// fs-monitor events
// ============================================================================

// FSEventCategory — категорія файлової події.
type FSEventCategory string

const (
	FSCategoryUpload       FSEventCategory = "upload"
	FSCategoryConfigChange FSEventCategory = "config_change"
	FSCategoryLogDeletion  FSEventCategory = "log_deletion"
	FSCategorySystemChange FSEventCategory = "system_change"
	FSCategoryGeneral      FSEventCategory = "general"
)

// FSEvent — файлова подія (створення, зміна, видалення).
// Джерело: fsnotify (inotify).
type FSEvent struct {
	BaseEvent
	Path        string          `json:"path"`
	Operation   string          `json:"operation"` // create, write, remove, rename, chmod
	Category    FSEventCategory `json:"category"`
	FileSize    int64           `json:"file_size,omitempty"`
	FilePreview string          `json:"file_preview,omitempty"` // перші N байт
	SHA256      string          `json:"sha256,omitempty"`
	IsDir       bool            `json:"is_dir"`
}

// ============================================================================
// auth-monitor events
// ============================================================================

// AuthEventType — тип події аутентифікації.
type AuthEventType string

const (
	AuthSSHLogin  AuthEventType = "ssh_login"
	AuthSSHFail   AuthEventType = "ssh_fail"
	AuthSudo      AuthEventType = "sudo"
	AuthSu        AuthEventType = "su"
	AuthUserAdd   AuthEventType = "useradd"
	AuthUserDel   AuthEventType = "userdel"
	AuthPasswd    AuthEventType = "passwd"
	AuthGroupAdd  AuthEventType = "groupadd"
)

// AuthEvent — подія аутентифікації/авторизації.
// Джерело: tail /var/log/auth.log.
type AuthEvent struct {
	BaseEvent
	AuthType  AuthEventType `json:"auth_type"`
	User      string        `json:"user"`
	SourceIP  string        `json:"source_ip,omitempty"`
	Success   bool          `json:"success"`
	Details   string        `json:"details,omitempty"`
	TargetUser string       `json:"target_user,omitempty"` // для sudo/su
}

// ============================================================================
// service-monitor events
// ============================================================================

// ServiceEvent — зміна стану systemd сервісу.
type ServiceEvent struct {
	BaseEvent
	ServiceName   string `json:"service_name"`
	Action        string `json:"action"` // started, stopped, enabled, disabled, restarted
	PreviousState string `json:"previous_state,omitempty"`
	CurrentState  string `json:"current_state"`
}

// CrontabChangeEvent — зміна crontab.
type CrontabChangeEvent struct {
	BaseEvent
	User       string `json:"user"`
	Action     string `json:"action"` // added, removed, modified
	CronLine   string `json:"cron_line,omitempty"`
	PrevHash   string `json:"prev_hash"`
	NewHash    string `json:"new_hash"`
}

// PackageEvent — встановлення/видалення пакету.
// Джерело: tail /var/log/dpkg.log.
type PackageEvent struct {
	BaseEvent
	Action      string `json:"action"`  // install, remove, upgrade, configure
	PackageName string `json:"package_name"`
	Version     string `json:"version,omitempty"`
	PrevVersion string `json:"prev_version,omitempty"` // для upgrade
}
