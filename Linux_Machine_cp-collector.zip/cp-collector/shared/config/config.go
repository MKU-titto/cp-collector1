// Package config завантажує YAML-конфігурацію та надає типізовані структури
// для кожного watcher-сервісу Linux_Machine.
//
// Кожен watcher при старті викликає config.Load(path) і читає свою секцію + agent + storage.
package config

import (
	"fmt"
	"os"

	"gopkg.in/yaml.v3"
)

// ============================================================================
// Root config
// ============================================================================

// Config — кореневий конфіг, що містить усі секції.
type Config struct {
	Agent       AgentConfig       `yaml:"agent"`
	Storage     StorageConfig     `yaml:"storage"`
	Export      ExportConfig      `yaml:"export"`
	Shell       ShellConfig       `yaml:"shell"`
	Interactive InteractiveConfig `yaml:"interactive"`
	Browser     BrowserConfig     `yaml:"browser"`
	Syscall     SyscallConfig     `yaml:"syscall"`
	Net         NetConfig         `yaml:"net"`
	Proc        ProcConfig        `yaml:"proc"`
	FS          FSConfig          `yaml:"fs"`
	Auth        AuthConfig        `yaml:"auth"`
	Service     ServiceConfig     `yaml:"service"`
}

// ============================================================================
// Agent — ідентифікація агента
// ============================================================================

type AgentConfig struct {
	Type       string `yaml:"type"`
	Version    string `yaml:"version"`
	CTFEventID string `yaml:"ctf_event_id"`
	MachineID  string `yaml:"machine_id"`
}

// ============================================================================
// Storage — параметри запису логів
// ============================================================================

type StorageConfig struct {
	BasePath        string `yaml:"base_path"`
	FilesPath       string `yaml:"files_path"`
	MaxSizeGB       int    `yaml:"max_size_gb"`
	Compression     bool   `yaml:"compression"`
	RotateSizeMB    int    `yaml:"rotate_size_mb"`
	FlushIntervalMs int    `yaml:"flush_interval_ms"`
}

// ============================================================================
// Export — параметри експорту після CTF
// ============================================================================

type ExportConfig struct {
	OutputPath       string `yaml:"output_path"`
	AutoExportOnStop bool   `yaml:"auto_export_on_stop"`
	Encrypt          bool   `yaml:"encrypt"`
}

// ============================================================================
// shell-watcher
// ============================================================================

type ShellConfig struct {
	Enabled        bool   `yaml:"enabled"`
	SocketPath     string `yaml:"socket_path"`
	MaxStdoutBytes int64  `yaml:"max_stdout_bytes"`
	MaxStderrBytes int64  `yaml:"max_stderr_bytes"`
}

// ============================================================================
// interactive-watcher
// ============================================================================

type InteractiveConfig struct {
	Enabled            bool     `yaml:"enabled"`
	CaptureStdout      bool     `yaml:"capture_stdout"`
	EBPFObjectPath     string   `yaml:"ebpf_object_path"`
	MaxResponseBytes   int64    `yaml:"max_response_bytes"`
	ResponseTimeoutSec int      `yaml:"response_timeout_sec"`
	TargetTools        []string `yaml:"target_tools"`
}

// ============================================================================
// browser-watcher
// ============================================================================

type BrowserConfig struct {
	Enabled             bool   `yaml:"enabled"`
	MitmproxyPort       int    `yaml:"mitmproxy_port"`
	MaxBodyPreviewBytes int64  `yaml:"max_body_preview_bytes"`
	OutputSocketPath    string `yaml:"output_socket_path"`
}

// ============================================================================
// syscall-monitor
// ============================================================================

type SyscallConfig struct {
	Enabled        bool   `yaml:"enabled"`
	EBPFObjectPath string `yaml:"ebpf_object_path"`
}

// ============================================================================
// net-sniffer
// ============================================================================

type NetConfig struct {
	Enabled             bool     `yaml:"enabled"`
	Interfaces          []string `yaml:"interfaces"`
	BPFFilter           string   `yaml:"bpf_filter,omitempty"`
	CaptureDNS          bool     `yaml:"capture_dns"`
	CaptureHTTP         bool     `yaml:"capture_http"`
	HTTPPorts           []int    `yaml:"http_ports"`
	MaxBodyPreviewBytes int64    `yaml:"max_body_preview_bytes"`
	ScanDetection       bool     `yaml:"scan_detection"`
	ScanThresholdPorts  int      `yaml:"scan_threshold_ports"`
	ScanWindowSec       int      `yaml:"scan_window_sec"`
}

// ============================================================================
// proc-monitor
// ============================================================================

type ProcConfig struct {
	Enabled         bool `yaml:"enabled"`
	PollIntervalMs  int  `yaml:"poll_interval_ms"`
	DetectAnomalies bool `yaml:"detect_anomalies"`
}

// ============================================================================
// fs-monitor
// ============================================================================

type FSConfig struct {
	Enabled             bool     `yaml:"enabled"`
	WatchPaths          []string `yaml:"watch_paths"`
	ExcludePaths        []string `yaml:"exclude_paths"`
	MaxPreviewSizeBytes int64    `yaml:"max_preview_size_bytes"`
	CopyFiles           bool     `yaml:"copy_files"`
}

// ============================================================================
// auth-monitor
// ============================================================================

type AuthConfig struct {
	Enabled        bool   `yaml:"enabled"`
	AuthLogPath    string `yaml:"auth_log_path"`
	PollIntervalMs int    `yaml:"poll_interval_ms"`
}

// ============================================================================
// service-monitor
// ============================================================================

type ServiceConfig struct {
	Enabled         bool   `yaml:"enabled"`
	PollIntervalSec int    `yaml:"poll_interval_sec"`
	WatchCrontab    bool   `yaml:"watch_crontab"`
	WatchPackages   bool   `yaml:"watch_packages"`
	DpkgLogPath     string `yaml:"dpkg_log_path"`
}

// ============================================================================
// Load, Validate, Defaults
// ============================================================================

// Load читає YAML-файл та повертає заповнену Config структуру.
// Виконує валідацію обов'язкових полів та підставляє значення за замовчуванням.
func Load(path string) (*Config, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, fmt.Errorf("read config %s: %w", path, err)
	}

	cfg := &Config{}
	if err := yaml.Unmarshal(data, cfg); err != nil {
		return nil, fmt.Errorf("parse config %s: %w", path, err)
	}

	if err := cfg.validate(); err != nil {
		return nil, fmt.Errorf("config validation: %w", err)
	}

	cfg.setDefaults()
	return cfg, nil
}

// validate перевіряє обов'язкові поля.
func (c *Config) validate() error {
	if c.Agent.CTFEventID == "" {
		return fmt.Errorf("agent.ctf_event_id is required")
	}
	if c.Agent.MachineID == "" {
		return fmt.Errorf("agent.machine_id is required")
	}
	if c.Storage.BasePath == "" {
		return fmt.Errorf("storage.base_path is required")
	}
	return nil
}

// setDefaults підставляє значення за замовчуванням для незаповнених полів.
func (c *Config) setDefaults() {
	// Agent
	if c.Agent.Type == "" {
		c.Agent.Type = "linux_machine"
	}
	if c.Agent.Version == "" {
		c.Agent.Version = "3.0"
	}

	// Storage
	if c.Storage.FilesPath == "" {
		c.Storage.FilesPath = "/home/iron/files"
	}
	if c.Storage.MaxSizeGB == 0 {
		c.Storage.MaxSizeGB = 10
	}
	if c.Storage.RotateSizeMB == 0 {
		c.Storage.RotateSizeMB = 100
	}
	if c.Storage.FlushIntervalMs == 0 {
		c.Storage.FlushIntervalMs = 1000
	}

	// Export
	if c.Export.OutputPath == "" {
		c.Export.OutputPath = "/home/iron/exports"
	}

	// Shell
	if c.Shell.SocketPath == "" {
		c.Shell.SocketPath = "/home/iron/shell-watcher.sock"
	}
	if c.Shell.MaxStdoutBytes == 0 {
		c.Shell.MaxStdoutBytes = 65536
	}
	if c.Shell.MaxStderrBytes == 0 {
		c.Shell.MaxStderrBytes = 65536
	}

	// Interactive
	if c.Interactive.EBPFObjectPath == "" {
		c.Interactive.EBPFObjectPath = "/home/iron/ebpf/interactive.o"
	}
	if c.Interactive.MaxResponseBytes == 0 {
		c.Interactive.MaxResponseBytes = 65536
	}
	if c.Interactive.ResponseTimeoutSec == 0 {
		c.Interactive.ResponseTimeoutSec = 3
	}
	if len(c.Interactive.TargetTools) == 0 {
		c.Interactive.TargetTools = []string{
			"msfconsole", "gdb", "python3", "python", "irb", "node",
			"mavproxy.py", "mysql", "psql", "sqlite3", "redis-cli", "ssh",
		}
	}

	// Browser
	if c.Browser.MitmproxyPort == 0 {
		c.Browser.MitmproxyPort = 8080
	}
	if c.Browser.MaxBodyPreviewBytes == 0 {
		c.Browser.MaxBodyPreviewBytes = 4096
	}
	if c.Browser.OutputSocketPath == "" {
		c.Browser.OutputSocketPath = "/home/iron/mitmproxy.sock"
	}

	// Syscall
	if c.Syscall.EBPFObjectPath == "" {
		c.Syscall.EBPFObjectPath = "/home/iron/ebpf/syscall.o"
	}

	// Net
	if len(c.Net.Interfaces) == 0 {
		c.Net.Interfaces = []string{"eth0"}
	}
	if len(c.Net.HTTPPorts) == 0 {
		c.Net.HTTPPorts = []int{80, 443, 8080, 8443, 8000, 3000, 5000, 9090}
	}
	if c.Net.MaxBodyPreviewBytes == 0 {
		c.Net.MaxBodyPreviewBytes = 4096
	}
	if c.Net.ScanThresholdPorts == 0 {
		c.Net.ScanThresholdPorts = 20
	}
	if c.Net.ScanWindowSec == 0 {
		c.Net.ScanWindowSec = 10
	}

	// Proc
	if c.Proc.PollIntervalMs == 0 {
		c.Proc.PollIntervalMs = 500
	}

	// FS
	if len(c.FS.WatchPaths) == 0 {
		c.FS.WatchPaths = []string{
			"/home", "/tmp", "/var/tmp", "/opt",
			"/var/www", "/srv", "/etc", "/root",
		}
	}
	if len(c.FS.ExcludePaths) == 0 {
		c.FS.ExcludePaths = []string{
			"/home/iron", "/proc", "/sys", "/dev",
		}
	}
	if c.FS.MaxPreviewSizeBytes == 0 {
		c.FS.MaxPreviewSizeBytes = 2048
	}

	// Auth
	if c.Auth.AuthLogPath == "" {
		c.Auth.AuthLogPath = "/var/log/auth.log"
	}
	if c.Auth.PollIntervalMs == 0 {
		c.Auth.PollIntervalMs = 500
	}

	// Service
	if c.Service.PollIntervalSec == 0 {
		c.Service.PollIntervalSec = 10
	}
	if c.Service.DpkgLogPath == "" {
		c.Service.DpkgLogPath = "/var/log/dpkg.log"
	}
}
