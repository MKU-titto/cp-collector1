package main

import (
	"bufio"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher моніторить systemd units, crontab та dpkg.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	// Стан systemd units: service_name → ActiveState
	unitStates map[string]string

	// Стан crontab: username → sha256 hash вмісту
	crontabHashes map[string]string
}

// NewWatcher створює новий service-monitor watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:           cfg,
		writer:        writer,
		log:           log,
		unitStates:    make(map[string]string),
		crontabHashes: make(map[string]string),
	}
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run запускає три підсистеми моніторингу у паралельних goroutines.
func (w *Watcher) Run(ctx context.Context) error {
	// Знімаємо початковий snapshot systemd та crontab
	w.snapshotUnits()
	w.snapshotCrontabs()

	pollInterval := time.Duration(w.cfg.Service.PollIntervalSec) * time.Second
	ticker := time.NewTicker(pollInterval)
	defer ticker.Stop()

	w.log.Info("monitoring started: %d initial units, poll=%v", len(w.unitStates), pollInterval)

	// Запускаємо dpkg.log tail в окремій goroutine
	if w.cfg.Service.WatchPackages {
		go w.tailDpkgLog(ctx)
	}

	for {
		select {
		case <-ctx.Done():
			w.log.Info("context cancelled, stopping")
			return nil
		case <-ticker.C:
			w.pollUnits()
			if w.cfg.Service.WatchCrontab {
				w.pollCrontabs()
			}
		}
	}
}

// ============================================================================
// Systemd unit monitoring
// ============================================================================

// unitInfo зберігає стан одного systemd unit.
type unitInfo struct {
	Name        string
	ActiveState string // active, inactive, failed, activating, deactivating
	SubState    string // running, dead, exited, waiting, etc.
}

// snapshotUnits зберігає початковий стан усіх units.
func (w *Watcher) snapshotUnits() {
	units := w.listUnits()
	for _, u := range units {
		w.unitStates[u.Name] = u.ActiveState
	}
}

// pollUnits порівнює поточний стан units з попереднім і записує зміни.
func (w *Watcher) pollUnits() {
	currentUnits := w.listUnits()
	currentMap := make(map[string]unitInfo)

	for _, u := range currentUnits {
		currentMap[u.Name] = u

		prevState, existed := w.unitStates[u.Name]

		if !existed {
			// Новий unit — з'явився після старту
			w.writeServiceEvent(u.Name, "appeared", "", u.ActiveState)
			w.unitStates[u.Name] = u.ActiveState
			continue
		}

		if prevState != u.ActiveState {
			// Стан змінився
			action := w.detectAction(prevState, u.ActiveState)
			w.writeServiceEvent(u.Name, action, prevState, u.ActiveState)
			w.unitStates[u.Name] = u.ActiveState
		}
	}

	// Перевіряємо зниклі units
	for name, prevState := range w.unitStates {
		if _, exists := currentMap[name]; !exists {
			w.writeServiceEvent(name, "removed", prevState, "")
			delete(w.unitStates, name)
		}
	}
}

// listUnits отримує список systemd units через systemctl.
func (w *Watcher) listUnits() []unitInfo {
	// systemctl list-units --type=service --all --no-legend --no-pager --plain
	cmd := exec.Command("systemctl", "list-units",
		"--type=service", "--all", "--no-legend", "--no-pager", "--plain")
	output, err := cmd.Output()
	if err != nil {
		w.log.Error("systemctl list-units: %v", err)
		return nil
	}

	var units []unitInfo
	scanner := bufio.NewScanner(strings.NewReader(string(output)))
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" {
			continue
		}

		// Формат: UNIT LOAD ACTIVE SUB DESCRIPTION...
		fields := strings.Fields(line)
		if len(fields) < 4 {
			continue
		}

		name := fields[0]
		activeState := fields[2]
		subState := fields[3]

		// Ігноруємо наші власні сервіси
		if strings.HasPrefix(name, "cp-") {
			continue
		}

		units = append(units, unitInfo{
			Name:        name,
			ActiveState: activeState,
			SubState:    subState,
		})
	}

	return units
}

// detectAction визначає тип дії з переходу станів.
func (w *Watcher) detectAction(prev, current string) string {
	switch {
	case prev == "inactive" && current == "active":
		return "started"
	case prev == "active" && current == "inactive":
		return "stopped"
	case prev == "active" && current == "failed":
		return "failed"
	case prev == "failed" && current == "active":
		return "restarted"
	case prev == "inactive" && current == "failed":
		return "failed"
	case current == "activating":
		return "starting"
	case current == "deactivating":
		return "stopping"
	default:
		return fmt.Sprintf("changed_%s_to_%s", prev, current)
	}
}

// writeServiceEvent записує ServiceEvent.
func (w *Watcher) writeServiceEvent(name, action, prevState, currentState string) {
	event := types.ServiceEvent{
		BaseEvent:     types.NewBaseEvent("service_event", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		ServiceName:   name,
		Action:        action,
		PreviousState: prevState,
		CurrentState:  currentState,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write service event: %v", err)
		return
	}

	w.log.Info("service: %s %s (%s → %s)", name, action, prevState, currentState)
}

// ============================================================================
// Crontab monitoring
// ============================================================================

// snapshotCrontabs зберігає початкові хеші crontab для всіх користувачів.
func (w *Watcher) snapshotCrontabs() {
	users := w.listCrontabUsers()
	for _, user := range users {
		content := w.readCrontab(user)
		if content != "" {
			w.crontabHashes[user] = hashString(content)
		}
	}
	w.log.Info("initial crontab snapshot: %d users", len(w.crontabHashes))
}

// pollCrontabs перевіряє зміни в crontab для всіх користувачів.
func (w *Watcher) pollCrontabs() {
	users := w.listCrontabUsers()
	currentHashes := make(map[string]string)

	for _, user := range users {
		content := w.readCrontab(user)
		if content == "" {
			continue
		}

		newHash := hashString(content)
		currentHashes[user] = newHash

		prevHash, existed := w.crontabHashes[user]

		if !existed {
			// Новий crontab
			w.writeCrontabEvent(user, "added", "", newHash, content)
			continue
		}

		if prevHash != newHash {
			// Crontab змінився
			w.writeCrontabEvent(user, "modified", prevHash, newHash, content)
		}
	}

	// Перевіряємо видалені crontab
	for user, prevHash := range w.crontabHashes {
		if _, exists := currentHashes[user]; !exists {
			w.writeCrontabEvent(user, "removed", prevHash, "", "")
		}
	}

	w.crontabHashes = currentHashes
}

// listCrontabUsers повертає список користувачів, які мають crontab.
func (w *Watcher) listCrontabUsers() []string {
	var users []string

	// Системні crontab файли
	spoolDir := "/var/spool/cron/crontabs"
	entries, err := os.ReadDir(spoolDir)
	if err == nil {
		for _, e := range entries {
			if !e.IsDir() {
				users = append(users, e.Name())
			}
		}
	}

	// Перевіряємо також root через crontab -l
	if _, err := exec.Command("crontab", "-l", "-u", "root").Output(); err == nil {
		found := false
		for _, u := range users {
			if u == "root" {
				found = true
				break
			}
		}
		if !found {
			users = append(users, "root")
		}
	}

	return users
}

// readCrontab читає вміст crontab для конкретного користувача.
func (w *Watcher) readCrontab(user string) string {
	// Спочатку пробуємо файл у spool
	spoolPath := filepath.Join("/var/spool/cron/crontabs", user)
	data, err := os.ReadFile(spoolPath)
	if err == nil {
		return string(data)
	}

	// Fallback: crontab -l -u user
	output, err := exec.Command("crontab", "-l", "-u", user).Output()
	if err != nil {
		return ""
	}
	return string(output)
}

// writeCrontabEvent записує CrontabChangeEvent.
func (w *Watcher) writeCrontabEvent(user, action, prevHash, newHash, content string) {
	// Витягуємо останній доданий/змінений рядок (для інформативності)
	cronLine := ""
	if content != "" {
		lines := strings.Split(strings.TrimSpace(content), "\n")
		for i := len(lines) - 1; i >= 0; i-- {
			line := strings.TrimSpace(lines[i])
			if line != "" && !strings.HasPrefix(line, "#") {
				cronLine = line
				break
			}
		}
	}

	event := types.CrontabChangeEvent{
		BaseEvent: types.NewBaseEvent("crontab_change", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		User:      user,
		Action:    action,
		CronLine:  cronLine,
		PrevHash:  prevHash,
		NewHash:   newHash,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write crontab event: %v", err)
		return
	}

	w.log.Info("crontab: user=%s action=%s", user, action)
}

// ============================================================================
// dpkg.log monitoring
// ============================================================================

// Regex для парсингу dpkg.log:
// 2026-03-30 12:00:00 install libpcap-dev:amd64 <none> 1.10.4-4
// 2026-03-30 12:00:00 upgrade openssh-server:amd64 1:8.9p1-3 1:9.0p1-1
// 2026-03-30 12:00:00 remove netcat:amd64 1.219-1
var reDpkg = regexp.MustCompile(
	`^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+(install|remove|upgrade|configure|trigproc)\s+(\S+)\s+(\S+)\s*(\S*)`,
)

// tailDpkgLog слідкує за dpkg.log та записує PackageEvent.
func (w *Watcher) tailDpkgLog(ctx context.Context) {
	dpkgPath := w.cfg.Service.DpkgLogPath

	file, err := os.Open(dpkgPath)
	if err != nil {
		w.log.Warn("open %s: %v (package monitoring disabled)", dpkgPath, err)
		return
	}
	defer file.Close()

	// Seek to end — читаємо тільки нові записи
	if _, err := file.Seek(0, io.SeekEnd); err != nil {
		w.log.Error("seek dpkg.log: %v", err)
		return
	}

	w.log.Info("tailing %s", dpkgPath)

	reader := bufio.NewReader(file)
	ticker := time.NewTicker(time.Duration(w.cfg.Service.PollIntervalSec) * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.readDpkgLines(reader, file, dpkgPath)
		}
	}
}

// readDpkgLines читає нові рядки з dpkg.log.
func (w *Watcher) readDpkgLines(reader *bufio.Reader, file *os.File, path string) {
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				// Перевіряємо ротацію
				w.checkDpkgRotation(file, path)
				return
			}
			w.log.Error("read dpkg.log: %v", err)
			return
		}

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		w.parseDpkgLine(line)
	}
}

// checkDpkgRotation перевіряє чи dpkg.log не був ротований.
func (w *Watcher) checkDpkgRotation(file *os.File, path string) {
	currentPos, err := file.Seek(0, io.SeekCurrent)
	if err != nil {
		return
	}
	stat, err := os.Stat(path)
	if err != nil {
		return
	}
	if stat.Size() < currentPos {
		w.log.Warn("dpkg.log rotated, seeking to start")
		file.Seek(0, io.SeekStart)
	}
}

// parseDpkgLine парсить один рядок dpkg.log.
func (w *Watcher) parseDpkgLine(line string) {
	m := reDpkg.FindStringSubmatch(line)
	if m == nil {
		return
	}

	action := m[1]
	packageFull := m[2] // package:arch
	versionOrPrev := m[3]
	versionNew := m[4]

	// Ігноруємо trigproc та configure — це внутрішні dpkg стадії
	if action == "trigproc" || action == "configure" {
		return
	}

	// Витягуємо ім'я пакету без архітектури
	packageName := packageFull
	if idx := strings.Index(packageFull, ":"); idx > 0 {
		packageName = packageFull[:idx]
	}

	event := types.PackageEvent{
		BaseEvent:   types.NewBaseEvent("package_event", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		Action:      action,
		PackageName: packageName,
	}

	switch action {
	case "install":
		event.Version = versionNew
		if versionOrPrev != "<none>" {
			event.PrevVersion = versionOrPrev
		}
	case "upgrade":
		event.PrevVersion = versionOrPrev
		event.Version = versionNew
	case "remove":
		event.Version = versionOrPrev
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write package event: %v", err)
		return
	}

	w.log.Info("package: %s %s %s", action, packageName, event.Version)
}

// ============================================================================
// Утиліти
// ============================================================================

// hashString повертає SHA256 хеш рядка.
func hashString(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}
