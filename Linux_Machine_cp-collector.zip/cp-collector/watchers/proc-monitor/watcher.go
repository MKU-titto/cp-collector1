package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher моніторить процеси через /proc та записує ProcessSpawnEvent / AnomalousProcessEvent.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	// Відомі PIDs — щоб не дублювати події
	knownPIDs map[int]bool
}

// NewWatcher створює новий proc-monitor watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:       cfg,
		writer:    writer,
		log:       log,
		knownPIDs: make(map[int]bool),
	}
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run запускає polling /proc з заданим інтервалом.
func (w *Watcher) Run(ctx context.Context) error {
	pollInterval := time.Duration(w.cfg.Proc.PollIntervalMs) * time.Millisecond

	// Початковий snapshot — запам'ятовуємо існуючі PIDs
	w.snapshotCurrentPIDs()
	w.log.Info("initial snapshot: %d existing processes, poll=%v", len(w.knownPIDs), pollInterval)

	ticker := time.NewTicker(pollInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			w.log.Info("context cancelled, stopping")
			return nil
		case <-ticker.C:
			w.poll()
		}
	}
}

// ============================================================================
// Polling /proc
// ============================================================================

// snapshotCurrentPIDs зберігає всі поточні PIDs без генерації подій.
func (w *Watcher) snapshotCurrentPIDs() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		w.log.Error("read /proc: %v", err)
		return
	}

	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue // не PID-директорія
		}
		w.knownPIDs[pid] = true
	}
}

// poll сканує /proc і обробляє нові процеси.
func (w *Watcher) poll() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		w.log.Error("read /proc: %v", err)
		return
	}

	currentPIDs := make(map[int]bool)

	for _, entry := range entries {
		pid, err := strconv.Atoi(entry.Name())
		if err != nil {
			continue
		}
		currentPIDs[pid] = true

		// Пропускаємо вже відомі процеси
		if w.knownPIDs[pid] {
			continue
		}

		// Новий процес — збираємо інформацію
		info := w.readProcessInfo(pid)
		if info == nil {
			continue // процес вже завершився
		}

		// Ігноруємо kernel threads та наші власні процеси
		if info.comm == "" || strings.HasPrefix(info.comm, "cp-") {
			w.knownPIDs[pid] = true
			continue
		}

		// Записуємо подію
		w.processNewProcess(info)
	}

	// Очищуємо зниклі PIDs з пам'яті
	w.knownPIDs = currentPIDs
}

// ============================================================================
// Читання інформації з /proc
// ============================================================================

// procInfo — інформація про процес з /proc.
type procInfo struct {
	pid     int
	ppid    int
	comm    string
	cmdline string
	user    string
	uid     int
	exePath string

	// Для anomaly detection
	parentComm string
}

// readProcessInfo збирає інформацію про процес з /proc/<pid>/.
func (w *Watcher) readProcessInfo(pid int) *procInfo {
	procDir := fmt.Sprintf("/proc/%d", pid)

	// Перевіряємо чи процес ще існує
	if _, err := os.Stat(procDir); err != nil {
		return nil
	}

	info := &procInfo{pid: pid}

	// comm — ім'я процесу
	if data, err := os.ReadFile(filepath.Join(procDir, "comm")); err == nil {
		info.comm = strings.TrimSpace(string(data))
	}

	// cmdline — повний командний рядок
	if data, err := os.ReadFile(filepath.Join(procDir, "cmdline")); err == nil {
		// cmdline розділений null-байтами
		info.cmdline = strings.Join(strings.Split(strings.TrimRight(string(data), "\x00"), "\x00"), " ")
	}

	// status — PID, PPID, UID
	if data, err := os.ReadFile(filepath.Join(procDir, "status")); err == nil {
		for _, line := range strings.Split(string(data), "\n") {
			if strings.HasPrefix(line, "PPid:") {
				fmt.Sscanf(strings.TrimPrefix(line, "PPid:"), "%d", &info.ppid)
			}
			if strings.HasPrefix(line, "Uid:") {
				fields := strings.Fields(line)
				if len(fields) >= 2 {
					fmt.Sscanf(fields[1], "%d", &info.uid)
				}
			}
		}
	}

	// exe — шлях до бінарника
	if link, err := os.Readlink(filepath.Join(procDir, "exe")); err == nil {
		info.exePath = link
	}

	// username по UID
	info.user = w.uidToUser(info.uid)

	// Parent comm (для anomaly detection)
	if info.ppid > 0 {
		parentComm := fmt.Sprintf("/proc/%d/comm", info.ppid)
		if data, err := os.ReadFile(parentComm); err == nil {
			info.parentComm = strings.TrimSpace(string(data))
		}
	}

	return info
}

// uidToUser конвертує UID у username через /etc/passwd.
func (w *Watcher) uidToUser(uid int) string {
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return fmt.Sprintf("uid:%d", uid)
	}

	target := fmt.Sprintf(":%d:", uid)
	for _, line := range strings.Split(string(data), "\n") {
		if strings.Contains(line, target) {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) > 0 {
				return parts[0]
			}
		}
	}

	return fmt.Sprintf("uid:%d", uid)
}

// ============================================================================
// Обробка нового процесу
// ============================================================================

// processNewProcess обробляє новий процес: класифікує, перевіряє на аномалії, записує подію.
func (w *Watcher) processNewProcess(info *procInfo) {
	// Класифікуємо інструмент
	category := classifyTool(info.comm)

	// SHA256 бінарника (тільки якщо шлях доступний)
	binHash := ""
	if info.exePath != "" && !strings.Contains(info.exePath, "(deleted)") {
		binHash = w.hashFile(info.exePath)
	}

	// Записуємо process_spawn
	spawnEvent := types.ProcessSpawnEvent{
		BaseEvent:    types.NewBaseEvent("process_spawn", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		PID:          info.pid,
		PPID:         info.ppid,
		Comm:         info.comm,
		Cmdline:      info.cmdline,
		User:         info.user,
		ToolCategory: category,
		SHA256:       binHash,
		ExePath:      info.exePath,
	}

	if err := w.writer.Write(spawnEvent); err != nil {
		w.log.Error("write process_spawn: %v", err)
	}

	if category != types.ToolUnknown && category != types.ToolGeneral {
		w.log.Info("process: pid=%d comm=%s user=%s category=%s", info.pid, info.comm, info.user, category)
	}

	// Anomaly detection
	if w.cfg.Proc.DetectAnomalies {
		w.detectAnomalies(info)
	}
}

// ============================================================================
// Anomaly detection
// ============================================================================

// webServiceUsers — користувачі, від яких працюють веб-сервери.
// Shell від цих користувачів — ознака webshell exploitation.
var webServiceUsers = map[string]bool{
	"www-data": true,
	"apache":   true,
	"httpd":    true,
	"nginx":    true,
	"tomcat":   true,
	"nobody":   true,
}

// webServiceProcs — процеси веб-серверів (parent для webshell detection).
var webServiceProcs = map[string]bool{
	"apache2":  true,
	"httpd":    true,
	"nginx":    true,
	"java":     true, // Tomcat, etc.
	"php-fpm":  true,
	"php-cgi":  true,
	"uwsgi":    true,
	"gunicorn": true,
	"node":     true,
}

// shells — процеси, що є інтерактивними оболонками.
var shells = map[string]bool{
	"bash": true, "sh": true, "zsh": true, "dash": true,
	"fish": true, "csh": true, "tcsh": true, "ksh": true,
}

// detectAnomalies перевіряє процес на ознаки атаки.
func (w *Watcher) detectAnomalies(info *procInfo) {
	// 1. Webshell spawn: shell запущений від веб-сервера
	if w.detectWebshellSpawn(info) {
		return
	}

	// 2. Reverse shell patterns
	if w.detectReverseShell(info) {
		return
	}

	// 3. Suspicious binary: виконання з /tmp, /var/tmp, /dev/shm
	if w.detectSuspiciousBinary(info) {
		return
	}

	// 4. Privilege escalation: процес від root з parent від непривілейованого
	if w.detectPrivesc(info) {
		return
	}
}

// detectWebshellSpawn — shell запущений від www-data / apache / nginx.
func (w *Watcher) detectWebshellSpawn(info *procInfo) bool {
	if !shells[info.comm] {
		return false
	}

	// Перевіряємо чи parent — веб-сервер або user — веб-сервер
	if webServiceUsers[info.user] || webServiceProcs[info.parentComm] {
		w.writeAnomaly(info, types.AnomalyWebshellSpawn,
			fmt.Sprintf("shell '%s' spawned by '%s' as user '%s'", info.comm, info.parentComm, info.user))
		return true
	}

	return false
}

// detectReverseShell — патерни reverse shell у cmdline.
func (w *Watcher) detectReverseShell(info *procInfo) bool {
	cmdline := strings.ToLower(info.cmdline)

	patterns := []string{
		"/dev/tcp/",
		"/dev/udp/",
		"bash -i",
		"bash -c /bin/sh",
		"nc -e",
		"ncat -e",
		"netcat -e",
		"python -c 'import socket",
		"python3 -c 'import socket",
		"python -c \"import socket",
		"python3 -c \"import socket",
		"perl -e 'use socket",
		"php -r '$sock=fsockopen",
		"ruby -rsocket",
		"mkfifo /tmp/",
		"0<&196;exec 196<>/dev/tcp",
		"exec 5<>/dev/tcp",
	}

	for _, pattern := range patterns {
		if strings.Contains(cmdline, pattern) {
			w.writeAnomaly(info, types.AnomalyReverseShell,
				fmt.Sprintf("reverse shell pattern detected: '%s'", pattern))
			return true
		}
	}

	return false
}

// detectSuspiciousBinary — виконання з тимчасових/підозрілих директорій.
func (w *Watcher) detectSuspiciousBinary(info *procInfo) bool {
	suspiciousDirs := []string{
		"/tmp/", "/var/tmp/", "/dev/shm/",
		"/var/www/uploads/", "/var/www/html/uploads/",
	}

	for _, dir := range suspiciousDirs {
		if strings.HasPrefix(info.exePath, dir) {
			w.writeAnomaly(info, types.AnomalySuspiciousBin,
				fmt.Sprintf("binary executed from suspicious path: %s", info.exePath))
			return true
		}
	}

	return false
}

// detectPrivesc — процес від root з parent від непривілейованого користувача.
func (w *Watcher) detectPrivesc(info *procInfo) bool {
	if info.uid != 0 || info.ppid <= 1 {
		return false
	}

	// Читаємо UID parent процесу
	parentStatus := fmt.Sprintf("/proc/%d/status", info.ppid)
	data, err := os.ReadFile(parentStatus)
	if err != nil {
		return false
	}

	parentUID := -1
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "Uid:") {
			fields := strings.Fields(line)
			if len(fields) >= 2 {
				fmt.Sscanf(fields[1], "%d", &parentUID)
			}
		}
	}

	// Якщо parent не root і поточний root — підозріло
	if parentUID > 0 && parentUID != 0 {
		// Ігноруємо відомі легітимні випадки
		if info.comm == "sudo" || info.comm == "su" || info.comm == "pkexec" ||
			info.comm == "polkitd" || info.parentComm == "sudo" || info.parentComm == "su" {
			return false
		}

		w.writeAnomaly(info, types.AnomalyPrivesc,
			fmt.Sprintf("root process '%s' spawned by non-root parent '%s' (uid=%d)",
				info.comm, info.parentComm, parentUID))
		return true
	}

	return false
}

// writeAnomaly записує AnomalousProcessEvent.
func (w *Watcher) writeAnomaly(info *procInfo, anomalyType types.AnomalyType, details string) {
	event := types.AnomalousProcessEvent{
		BaseEvent:      types.NewBaseEvent("anomalous_process", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		PID:            info.pid,
		PPID:           info.ppid,
		Comm:           info.comm,
		Cmdline:        info.cmdline,
		User:           info.user,
		ParentComm:     info.parentComm,
		ExePath:        info.exePath,
		AnomalyType:    anomalyType,
		AnomalyDetails: details,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write anomaly: %v", err)
		return
	}

	w.log.Warn("ANOMALY: type=%s pid=%d comm=%s details=%s", anomalyType, info.pid, info.comm, details)
}

// ============================================================================
// Утиліти
// ============================================================================

// hashFile обчислює SHA256 файлу.
func (w *Watcher) hashFile(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}

	return hex.EncodeToString(h.Sum(nil))
}
