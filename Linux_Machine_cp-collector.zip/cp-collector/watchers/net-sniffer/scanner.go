package main

import (
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// ScanDetector виявляє port scan за кількістю SYN-пакетів з одного IP
// у заданому часовому вікні.
type ScanDetector struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	mu       sync.Mutex
	// sourceIP → список {port, timestamp}
	tracking map[string][]portHit

	// sourceIP → true (вже повідомили про сканування в поточному вікні)
	alerted  map[string]bool
}

// portHit — один SYN-пакет на конкретний порт.
type portHit struct {
	Port      int
	Timestamp time.Time
}

// NewScanDetector створює новий port scan detector.
func NewScanDetector(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *ScanDetector {
	sd := &ScanDetector{
		cfg:      cfg,
		writer:   writer,
		log:      log,
		tracking: make(map[string][]portHit),
		alerted:  make(map[string]bool),
	}

	// Запускаємо фоновий cleanup
	go sd.cleanupLoop()

	return sd
}

// TrackSYN реєструє SYN-пакет від sourceIP на dstPort.
// Якщо кількість унікальних портів від цього IP перевищує поріг — генерує подію.
func (sd *ScanDetector) TrackSYN(sourceIP string, dstPort int) {
	sd.mu.Lock()
	defer sd.mu.Unlock()

	now := time.Now()
	window := time.Duration(sd.cfg.Net.ScanWindowSec) * time.Second
	threshold := sd.cfg.Net.ScanThresholdPorts

	// Додаємо новий hit
	sd.tracking[sourceIP] = append(sd.tracking[sourceIP], portHit{
		Port:      dstPort,
		Timestamp: now,
	})

	// Фільтруємо тільки hits у межах вікна
	hits := sd.tracking[sourceIP]
	var recent []portHit
	for _, h := range hits {
		if now.Sub(h.Timestamp) <= window {
			recent = append(recent, h)
		}
	}
	sd.tracking[sourceIP] = recent

	// Рахуємо унікальні порти
	uniquePorts := make(map[int]bool)
	for _, h := range recent {
		uniquePorts[h.Port] = true
	}

	// Перевіряємо поріг
	if len(uniquePorts) >= threshold && !sd.alerted[sourceIP] {
		sd.alerted[sourceIP] = true

		// Збираємо sample портів
		var samplePorts []int
		count := 0
		for port := range uniquePorts {
			if count >= 20 {
				break
			}
			samplePorts = append(samplePorts, port)
			count++
		}

		sd.writeScanEvent(sourceIP, len(uniquePorts), sd.cfg.Net.ScanWindowSec, samplePorts)
	}
}

// writeScanEvent записує PortScanDetectedEvent.
func (sd *ScanDetector) writeScanEvent(sourceIP string, portsCount, windowSec int, samplePorts []int) {
	event := types.PortScanDetectedEvent{
		BaseEvent:   types.NewBaseEvent("port_scan_detected", sd.cfg.Agent.MachineID, sd.cfg.Agent.CTFEventID),
		SourceIP:    sourceIP,
		PortsCount:  portsCount,
		WindowSec:   windowSec,
		SamplePorts: samplePorts,
	}

	if err := sd.writer.Write(event); err != nil {
		sd.log.Error("write port_scan: %v", err)
		return
	}

	sd.log.Warn("PORT SCAN detected: src=%s ports=%d window=%ds", sourceIP, portsCount, windowSec)
}

// cleanupLoop періодично очищує старі записи та скидає alerted map.
func (sd *ScanDetector) cleanupLoop() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		sd.mu.Lock()

		now := time.Now()
		window := time.Duration(sd.cfg.Net.ScanWindowSec) * time.Second

		// Очищуємо старі hits
		for ip, hits := range sd.tracking {
			var recent []portHit
			for _, h := range hits {
				if now.Sub(h.Timestamp) <= window {
					recent = append(recent, h)
				}
			}
			if len(recent) == 0 {
				delete(sd.tracking, ip)
				delete(sd.alerted, ip)
			} else {
				sd.tracking[ip] = recent
			}
		}

		// Скидаємо alerted для IP, у яких сканування припинилось
		for ip := range sd.alerted {
			if _, exists := sd.tracking[ip]; !exists {
				delete(sd.alerted, ip)
			}
		}

		sd.mu.Unlock()
	}
}
