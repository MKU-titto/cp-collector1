package main

import (
	"fmt"
	"strings"

	"github.com/google/gopacket/layers"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// processDNS обробляє DNS пакет та записує DNSQueryEvent.
func (w *Watcher) processDNS(dns *layers.DNS, srcIP, dstIP string) {
	// Обробляємо тільки запити (QR=false) та відповіді з answers
	if !dns.QR {
		// Це запит — записуємо query
		for _, q := range dns.Questions {
			w.writeDNSQuery(string(q.Name), dnsTypeString(q.Type), srcIP, nil)
		}
		return
	}

	// Це відповідь — витягуємо answers
	if len(dns.Questions) == 0 {
		return
	}

	queryName := string(dns.Questions[0].Name)
	queryType := dnsTypeString(dns.Questions[0].Type)

	var answers []string
	for _, a := range dns.Answers {
		answer := formatDNSAnswer(a)
		if answer != "" {
			answers = append(answers, answer)
		}
	}

	w.writeDNSQuery(queryName, queryType, dstIP, answers)
}

// writeDNSQuery записує DNSQueryEvent.
func (w *Watcher) writeDNSQuery(queryName, queryType, srcIP string, answers []string) {
	event := types.DNSQueryEvent{
		BaseEvent: types.NewBaseEvent("dns_query", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		QueryName: queryName,
		QueryType: queryType,
		Answers:   answers,
		SrcIP:     srcIP,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write dns_query: %v", err)
		return
	}

	answersStr := ""
	if len(answers) > 0 {
		answersStr = " → " + strings.Join(answers, ", ")
	}
	w.log.Debug("DNS: %s %s from %s%s", queryType, queryName, srcIP, answersStr)
}

// ============================================================================
// DNS helpers
// ============================================================================

// dnsTypeString конвертує DNS тип у рядок.
func dnsTypeString(t layers.DNSType) string {
	switch t {
	case layers.DNSTypeA:
		return "A"
	case layers.DNSTypeAAAA:
		return "AAAA"
	case layers.DNSTypeCNAME:
		return "CNAME"
	case layers.DNSTypeMX:
		return "MX"
	case layers.DNSTypeNS:
		return "NS"
	case layers.DNSTypeTXT:
		return "TXT"
	case layers.DNSTypePTR:
		return "PTR"
	case layers.DNSTypeSOA:
		return "SOA"
	case layers.DNSTypeSRV:
		return "SRV"
	default:
		return fmt.Sprintf("TYPE%d", t)
	}
}

// formatDNSAnswer форматує DNS answer у рядок.
func formatDNSAnswer(a layers.DNSResourceRecord) string {
	switch a.Type {
	case layers.DNSTypeA, layers.DNSTypeAAAA:
		if a.IP != nil {
			return a.IP.String()
		}
	case layers.DNSTypeCNAME, layers.DNSTypeNS, layers.DNSTypePTR:
		return string(a.CNAME)
	case layers.DNSTypeMX:
		return string(a.MX.Name)
	case layers.DNSTypeTXT:
		var parts []string
		for _, txt := range a.TXTs {
			parts = append(parts, string(txt))
		}
		return strings.Join(parts, " ")
	}
	return ""
}
