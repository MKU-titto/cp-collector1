package main

import (
	"bytes"
	"strings"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// HTTPParser витягує HTTP-запити з TCP payload.
type HTTPParser struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger
}

// NewHTTPParser створює новий HTTP parser.
func NewHTTPParser(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *HTTPParser {
	return &HTTPParser{
		cfg:    cfg,
		writer: writer,
		log:    log,
	}
}

// HTTP methods для визначення початку запиту
var httpMethods = [][]byte{
	[]byte("GET "),
	[]byte("POST "),
	[]byte("PUT "),
	[]byte("DELETE "),
	[]byte("HEAD "),
	[]byte("OPTIONS "),
	[]byte("PATCH "),
	[]byte("CONNECT "),
	[]byte("TRACE "),
}

// ProcessPayload парсить TCP payload як HTTP-запит (якщо це HTTP).
func (p *HTTPParser) ProcessPayload(payload []byte, srcIP string, srcPort int, dstIP string, dstPort int, direction string) {
	// Перевіряємо чи це HTTP-запит
	if !isHTTPRequest(payload) {
		return
	}

	// Парсимо запит
	method, uri, host, contentType, body := parseHTTPRequest(payload, p.cfg.Net.MaxBodyPreviewBytes)

	if method == "" || uri == "" {
		return
	}

	// Записуємо InboundHTTPEvent для inbound трафіку
	if direction == "inbound" {
		event := types.InboundHTTPEvent{
			BaseEvent:   types.NewBaseEvent("inbound_http", p.cfg.Agent.MachineID, p.cfg.Agent.CTFEventID),
			Method:      method,
			URI:         uri,
			Host:        host,
			SrcIP:       srcIP,
			SrcPort:     srcPort,
			UserAgent:   extractHeader(payload, "User-Agent"),
			BodyPreview: body,
			ContentType: contentType,
		}

		if err := p.writer.Write(event); err != nil {
			p.log.Error("write inbound_http: %v", err)
			return
		}

		p.log.Info("HTTP inbound: %s %s from %s:%d", method, truncateStr(uri, 80), srcIP, srcPort)
	}
}

// ============================================================================
// HTTP parsing helpers
// ============================================================================

// isHTTPRequest перевіряє чи payload починається з HTTP method.
func isHTTPRequest(payload []byte) bool {
	for _, method := range httpMethods {
		if bytes.HasPrefix(payload, method) {
			return true
		}
	}
	return false
}

// parseHTTPRequest парсить HTTP request з payload.
// Повертає: method, uri, host, contentType, bodyPreview.
func parseHTTPRequest(payload []byte, maxBodyBytes int64) (method, uri, host, contentType, body string) {
	// Знаходимо кінець першого рядка (request line)
	lineEnd := bytes.IndexByte(payload, '\n')
	if lineEnd < 0 {
		return
	}

	requestLine := strings.TrimSpace(string(payload[:lineEnd]))
	parts := strings.SplitN(requestLine, " ", 3)
	if len(parts) < 2 {
		return
	}

	method = parts[0]
	uri = parts[1]

	// Витягуємо headers
	host = extractHeader(payload, "Host")
	contentType = extractHeader(payload, "Content-Type")

	// Витягуємо body (після \r\n\r\n)
	bodyStart := bytes.Index(payload, []byte("\r\n\r\n"))
	if bodyStart < 0 {
		bodyStart = bytes.Index(payload, []byte("\n\n"))
	}

	if bodyStart >= 0 {
		bodyStart += 4 // пропускаємо \r\n\r\n
		if bodyStart < len(payload) {
			bodyBytes := payload[bodyStart:]
			if int64(len(bodyBytes)) > maxBodyBytes {
				bodyBytes = bodyBytes[:maxBodyBytes]
			}
			// Тільки текстовий body
			if isTextContent(contentType) && !isBinaryData(bodyBytes) {
				body = string(bodyBytes)
			}
		}
	}

	return
}

// extractHeader витягує значення HTTP header з payload.
func extractHeader(payload []byte, headerName string) string {
	// Шукаємо "HeaderName: value\r\n"
	search := []byte(headerName + ": ")
	searchLower := []byte(strings.ToLower(headerName) + ": ")

	payloadStr := payload

	idx := bytes.Index(payloadStr, search)
	if idx < 0 {
		// Case-insensitive fallback
		idx = bytes.Index(bytes.ToLower(payloadStr), searchLower)
	}

	if idx < 0 {
		return ""
	}

	// Знаходимо початок значення
	valueStart := idx + len(search)
	if valueStart >= len(payload) {
		return ""
	}

	// Знаходимо кінець рядка
	lineEnd := bytes.IndexAny(payload[valueStart:], "\r\n")
	if lineEnd < 0 {
		lineEnd = len(payload) - valueStart
	}

	value := string(payload[valueStart : valueStart+lineEnd])
	return strings.TrimSpace(value)
}

// isTextContent перевіряє чи Content-Type є текстовим.
func isTextContent(contentType string) bool {
	if contentType == "" {
		return true // за замовчуванням вважаємо текстовим
	}
	ct := strings.ToLower(contentType)
	textTypes := []string{
		"text/", "application/json", "application/xml",
		"application/x-www-form-urlencoded", "multipart/form-data",
		"application/javascript", "application/soap",
	}
	for _, t := range textTypes {
		if strings.Contains(ct, t) {
			return true
		}
	}
	return false
}

// isBinaryData перевіряє чи дані містять null-байти.
func isBinaryData(data []byte) bool {
	for _, b := range data {
		if b == 0 {
			return true
		}
	}
	return false
}

// truncateStr обрізає рядок.
func truncateStr(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
