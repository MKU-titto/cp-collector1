module github.com/cyber-polygon/cp-collector/watchers/net-sniffer

go 1.22.5

toolchain go1.22.5

require (
	github.com/cyber-polygon/cp-collector/shared v0.0.0
	github.com/google/gopacket v1.1.19
	gopkg.in/yaml.v3 v3.0.1
)

require golang.org/x/sys v0.20.0 // indirect

replace github.com/cyber-polygon/cp-collector/shared => ../../shared
