package main

import (
	"context"
	"fmt"
	"net"
	"sync"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
	"github.com/google/gopacket/pcap"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher захоплює мережевий трафік через libpcap.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	// Локальні IP-адреси машини (для визначення direction)
	localIPs map[string]bool

	// Port scan detector
	scanDetector *ScanDetector

	// HTTP parser
	httpParser *HTTPParser

	// Дедуплікація TCP з'єднань: "srcIP:srcPort-dstIP:dstPort" → true
	mu          sync.Mutex
	seenConns   map[string]bool
}

// NewWatcher створює новий net-sniffer.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	w := &Watcher{
		cfg:       cfg,
		writer:    writer,
		log:       log,
		localIPs:  make(map[string]bool),
		seenConns: make(map[string]bool),
	}

	if cfg.Net.ScanDetection {
		w.scanDetector = NewScanDetector(cfg, writer, log)
	}

	if cfg.Net.CaptureHTTP {
		w.httpParser = NewHTTPParser(cfg, writer, log)
	}

	return w
}

// ============================================================================
// Run — основний цикл захоплення
// ============================================================================

// Run запускає libpcap захоплення на всіх сконфігурованих інтерфейсах.
func (w *Watcher) Run(ctx context.Context) error {
	// Збираємо локальні IP-адреси
	w.collectLocalIPs()
	w.log.Info("local IPs: %v", w.localIPsList())

	// Запускаємо захоплення на кожному інтерфейсі
	errCh := make(chan error, len(w.cfg.Net.Interfaces))

	for _, iface := range w.cfg.Net.Interfaces {
		go func(ifaceName string) {
			errCh <- w.captureInterface(ctx, ifaceName)
		}(iface)
	}

	// Чекаємо першу помилку або контекст
	select {
	case <-ctx.Done():
		return nil
	case err := <-errCh:
		return err
	}
}

// captureInterface запускає pcap на одному інтерфейсі.
func (w *Watcher) captureInterface(ctx context.Context, ifaceName string) error {
	// Відкриваємо pcap handle
	handle, err := pcap.OpenLive(ifaceName, 65535, true, pcap.BlockForever)
	if err != nil {
		return fmt.Errorf("open pcap %s: %w", ifaceName, err)
	}
	defer handle.Close()

	// Застосовуємо BPF фільтр якщо заданий
	if w.cfg.Net.BPFFilter != "" {
		if err := handle.SetBPFFilter(w.cfg.Net.BPFFilter); err != nil {
			w.log.Warn("set BPF filter '%s': %v", w.cfg.Net.BPFFilter, err)
		}
	}

	w.log.Info("capturing on %s (snaplen=65535, promisc=true)", ifaceName)

	packetSource := gopacket.NewPacketSource(handle, handle.LinkType())
	packets := packetSource.Packets()

	for {
		select {
		case <-ctx.Done():
			w.log.Info("stopping capture on %s", ifaceName)
			return nil
		case packet, ok := <-packets:
			if !ok {
				return fmt.Errorf("packet channel closed on %s", ifaceName)
			}
			w.processPacket(packet)
		}
	}
}

// ============================================================================
// Обробка пакетів
// ============================================================================

// processPacket обробляє один мережевий пакет.
func (w *Watcher) processPacket(packet gopacket.Packet) {
	// Витягуємо IP layer
	ipLayer := packet.Layer(layers.LayerTypeIPv4)
	if ipLayer == nil {
		return
	}
	ip, ok := ipLayer.(*layers.IPv4)
	if !ok {
		return
	}

	srcIP := ip.SrcIP.String()
	dstIP := ip.DstIP.String()

	// DNS обробка (UDP port 53)
	if w.cfg.Net.CaptureDNS {
		if dnsLayer := packet.Layer(layers.LayerTypeDNS); dnsLayer != nil {
			w.processDNS(dnsLayer.(*layers.DNS), srcIP, dstIP)
			return
		}
	}

	// TCP
	if tcpLayer := packet.Layer(layers.LayerTypeTCP); tcpLayer != nil {
		tcp, ok := tcpLayer.(*layers.TCP)
		if !ok {
			return
		}
		w.processTCP(srcIP, dstIP, tcp, packet)
		return
	}

	// UDP (не DNS)
	if udpLayer := packet.Layer(layers.LayerTypeUDP); udpLayer != nil {
		udp, ok := udpLayer.(*layers.UDP)
		if !ok {
			return
		}
		w.processUDP(srcIP, dstIP, udp)
	}
}

// processTCP обробляє TCP пакет.
func (w *Watcher) processTCP(srcIP, dstIP string, tcp *layers.TCP, packet gopacket.Packet) {
	srcPort := int(tcp.SrcPort)
	dstPort := int(tcp.DstPort)

	// Визначаємо напрямок
	direction := w.detectDirection(srcIP, dstIP)

	// Записуємо тільки SYN пакети (нові з'єднання) для дедуплікації
	if tcp.SYN && !tcp.ACK {
		connKey := fmt.Sprintf("%s:%d-%s:%d", srcIP, srcPort, dstIP, dstPort)

		w.mu.Lock()
		if w.seenConns[connKey] {
			w.mu.Unlock()
			return
		}
		w.seenConns[connKey] = true
		// Очищуємо map якщо занадто великий
		if len(w.seenConns) > 100000 {
			w.seenConns = make(map[string]bool)
		}
		w.mu.Unlock()

		w.writeConnection("tcp", direction, srcIP, srcPort, dstIP, dstPort)

		// Port scan detection
		if w.scanDetector != nil && direction == "inbound" {
			w.scanDetector.TrackSYN(srcIP, dstPort)
		}
	}

	// HTTP парсинг (тільки для пакетів з payload)
	if w.httpParser != nil && len(tcp.Payload) > 0 {
		if w.isHTTPPort(srcPort) || w.isHTTPPort(dstPort) {
			w.httpParser.ProcessPayload(tcp.Payload, srcIP, srcPort, dstIP, dstPort, direction)
		}
	}
}

// processUDP обробляє UDP пакет.
func (w *Watcher) processUDP(srcIP, dstIP string, udp *layers.UDP) {
	srcPort := int(udp.SrcPort)
	dstPort := int(udp.DstPort)

	// Пропускаємо DNS (обробляється окремо)
	if srcPort == 53 || dstPort == 53 {
		return
	}

	direction := w.detectDirection(srcIP, dstIP)
	w.writeConnection("udp", direction, srcIP, srcPort, dstIP, dstPort)
}

// ============================================================================
// Direction detection
// ============================================================================

// collectLocalIPs збирає всі IP-адреси локальних інтерфейсів.
func (w *Watcher) collectLocalIPs() {
	ifaces, err := net.Interfaces()
	if err != nil {
		w.log.Error("list interfaces: %v", err)
		return
	}

	for _, iface := range ifaces {
		addrs, err := iface.Addrs()
		if err != nil {
			continue
		}
		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip != nil {
				w.localIPs[ip.String()] = true
			}
		}
	}
}

// localIPsList повертає список локальних IP для логування.
func (w *Watcher) localIPsList() []string {
	var ips []string
	for ip := range w.localIPs {
		ips = append(ips, ip)
	}
	return ips
}

// detectDirection визначає напрямок з'єднання.
func (w *Watcher) detectDirection(srcIP, dstIP string) string {
	srcLocal := w.localIPs[srcIP]
	dstLocal := w.localIPs[dstIP]

	switch {
	case !srcLocal && dstLocal:
		return "inbound"
	case srcLocal && !dstLocal:
		return "outbound"
	case srcLocal && dstLocal:
		return "local"
	default:
		return "unknown"
	}
}

// isHTTPPort перевіряє чи порт є HTTP-портом.
func (w *Watcher) isHTTPPort(port int) bool {
	for _, p := range w.cfg.Net.HTTPPorts {
		if port == p {
			return true
		}
	}
	return false
}

// ============================================================================
// Запис подій
// ============================================================================

// writeConnection записує NetworkConnectionEvent.
func (w *Watcher) writeConnection(protocol, direction, srcIP string, srcPort int, dstIP string, dstPort int) {
	event := types.NetworkConnectionEvent{
		BaseEvent: types.NewBaseEvent("network_connection", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		Direction: direction,
		Protocol:  protocol,
		SrcIP:     srcIP,
		SrcPort:   srcPort,
		DstIP:     dstIP,
		DstPort:   dstPort,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write connection: %v", err)
		return
	}

	w.log.Debug("conn: %s %s %s:%d → %s:%d", direction, protocol, srcIP, srcPort, dstIP, dstPort)
}
