package main

import (
	"bufio"
	"context"
	"io"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher моніторить /var/log/auth.log та записує AuthEvent.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger
}

// NewWatcher створює новий auth-monitor watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:    cfg,
		writer: writer,
		log:    log,
	}
}

// ============================================================================
// Regex patterns для парсингу auth.log
// ============================================================================

var (
	// SSH: Accepted publickey for admin from 192.168.1.5 port 54321 ssh2
	// SSH: Accepted password for admin from 192.168.1.5 port 54321 ssh2
	reSSHAccepted = regexp.MustCompile(
		`sshd\[\d+\]:\s+Accepted\s+\S+\s+for\s+(\S+)\s+from\s+(\S+)\s+port\s+(\d+)`,
	)

	// SSH: Failed password for admin from 192.168.1.5 port 54321 ssh2
	// SSH: Failed password for invalid user test from 192.168.1.5 port 54321 ssh2
	reSSHFailed = regexp.MustCompile(
		`sshd\[\d+\]:\s+Failed\s+\S+\s+for\s+(?:invalid\s+user\s+)?(\S+)\s+from\s+(\S+)\s+port\s+(\d+)`,
	)

	// sudo: admin : TTY=pts/0 ; PWD=/home/admin ; USER=root ; COMMAND=/bin/cat /etc/shadow
	reSudo = regexp.MustCompile(
		`sudo:\s+(\S+)\s+:.*USER=(\S+)\s+;\s+COMMAND=(.+)$`,
	)

	// su: (to root) admin on pts/0
	// su: pam_unix(su:session): session opened for user root(uid=0) by admin(uid=1000)
	reSuSession = regexp.MustCompile(
		`su.*:\s+.*session\s+opened\s+for\s+user\s+(\S+).*by\s+(\S+)`,
	)

	// useradd[1234]: new user: name=testuser, UID=1001, ...
	reUserAdd = regexp.MustCompile(
		`useradd\[\d+\]:\s+new\s+user:\s+name=(\S+),`,
	)

	// userdel[1234]: delete user 'testuser'
	reUserDel = regexp.MustCompile(
		`userdel\[\d+\]:\s+delete\s+user\s+'(\S+)'`,
	)

	// passwd[1234]: pam_unix(passwd:chauthtok): password changed for testuser
	rePasswd = regexp.MustCompile(
		`passwd.*:\s+password\s+changed\s+for\s+(\S+)`,
	)

	// groupadd[1234]: new group: name=testgroup, GID=1001
	reGroupAdd = regexp.MustCompile(
		`groupadd\[\d+\]:\s+new\s+group:\s+name=(\S+),`,
	)

	// SSH: pam_unix(sshd:auth): authentication failure; ... user=admin
	reSSHAuthFailure = regexp.MustCompile(
		`sshd.*:\s+authentication\s+failure;.*rhost=(\S+).*user=(\S+)`,
	)

	// sudo: pam_unix(sudo:auth): authentication failure; ... user=admin
	reSudoAuthFailure = regexp.MustCompile(
		`sudo.*:\s+.*authentication\s+failure;.*user=(\S+)`,
	)
)

// ============================================================================
// Run — основний цикл watcher
// ============================================================================

// Run запускає tail auth.log та парсить нові рядки до скасування контексту.
func (w *Watcher) Run(ctx context.Context) error {
	authLogPath := w.cfg.Auth.AuthLogPath
	pollInterval := time.Duration(w.cfg.Auth.PollIntervalMs) * time.Millisecond

	w.log.Info("opening %s", authLogPath)

	file, err := os.Open(authLogPath)
	if err != nil {
		return err
	}
	defer file.Close()

	// Переміщуємось в кінець файлу — читаємо тільки нові рядки
	if _, err := file.Seek(0, io.SeekEnd); err != nil {
		return err
	}

	w.log.Info("tailing %s (poll=%v)", authLogPath, pollInterval)

	reader := bufio.NewReader(file)
	ticker := time.NewTicker(pollInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			w.log.Info("context cancelled, stopping")
			return nil
		case <-ticker.C:
			w.readNewLines(reader, file, authLogPath)
		}
	}
}

// readNewLines читає нові рядки з auth.log.
// Обробляє ротацію файлу (якщо файл зменшився — переоткриваємо).
func (w *Watcher) readNewLines(reader *bufio.Reader, file *os.File, path string) {
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			if err == io.EOF {
				// Перевіряємо чи файл не був ротований
				w.checkRotation(file, path)
				return
			}
			w.log.Error("read error: %v", err)
			return
		}

		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}

		w.parseLine(line)
	}
}

// checkRotation перевіряє чи auth.log не був ротований (logrotate).
// Якщо поточна позиція більша за розмір файлу — файл був замінений.
func (w *Watcher) checkRotation(file *os.File, path string) {
	currentPos, err := file.Seek(0, io.SeekCurrent)
	if err != nil {
		return
	}

	stat, err := os.Stat(path)
	if err != nil {
		return
	}

	if stat.Size() < currentPos {
		w.log.Warn("auth.log rotated (size %d < pos %d), seeking to start", stat.Size(), currentPos)
		file.Seek(0, io.SeekStart)
	}
}

// ============================================================================
// Парсинг рядків auth.log
// ============================================================================

// parseLine парсить один рядок auth.log та записує відповідну подію.
func (w *Watcher) parseLine(line string) {
	// SSH accepted
	if m := reSSHAccepted.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthSSHLogin, m[1], m[2], true,
			"Accepted login from "+m[2]+":"+m[3], "")
		return
	}

	// SSH failed
	if m := reSSHFailed.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthSSHFail, m[1], m[2], false,
			"Failed login from "+m[2]+":"+m[3], "")
		return
	}

	// SSH auth failure (pam)
	if m := reSSHAuthFailure.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthSSHFail, m[2], m[1], false,
			"PAM auth failure from "+m[1], "")
		return
	}

	// sudo
	if m := reSudo.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthSudo, m[1], "", true,
			"COMMAND="+strings.TrimSpace(m[3]), m[2])
		return
	}

	// sudo auth failure
	if m := reSudoAuthFailure.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthSudo, m[1], "", false,
			"sudo authentication failure", "root")
		return
	}

	// su session opened
	if m := reSuSession.FindStringSubmatch(line); m != nil {
		// m[1] = target user (root), m[2] = source user (admin(uid=1000))
		sourceUser := m[2]
		// Видаляємо (uid=...) якщо є
		if idx := strings.Index(sourceUser, "("); idx > 0 {
			sourceUser = sourceUser[:idx]
		}
		w.writeEvent(types.AuthSu, sourceUser, "", true,
			"su to "+m[1], m[1])
		return
	}

	// useradd
	if m := reUserAdd.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthUserAdd, "", "", true,
			"new user: "+m[1], m[1])
		return
	}

	// userdel
	if m := reUserDel.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthUserDel, "", "", true,
			"deleted user: "+m[1], m[1])
		return
	}

	// passwd
	if m := rePasswd.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthPasswd, "", "", true,
			"password changed for "+m[1], m[1])
		return
	}

	// groupadd
	if m := reGroupAdd.FindStringSubmatch(line); m != nil {
		w.writeEvent(types.AuthGroupAdd, "", "", true,
			"new group: "+m[1], "")
		return
	}
}

// writeEvent створює AuthEvent та записує через storage writer.
func (w *Watcher) writeEvent(
	authType types.AuthEventType,
	user string,
	sourceIP string,
	success bool,
	details string,
	targetUser string,
) {
	event := types.AuthEvent{
		BaseEvent:  types.NewBaseEvent("auth_event", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		AuthType:   authType,
		User:       user,
		SourceIP:   sourceIP,
		Success:    success,
		Details:    details,
		TargetUser: targetUser,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write event: %v", err)
		return
	}

	if success {
		w.log.Info("event: %s user=%s src=%s", authType, user, sourceIP)
	} else {
		w.log.Warn("event: %s user=%s src=%s (failed)", authType, user, sourceIP)
	}
}
