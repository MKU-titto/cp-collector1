package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher слухає UNIX socket та записує ShellCommandEvent.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	// Pending commands — чекають на END повідомлення
	mu       sync.Mutex
	pending  map[string]*pendingCommand
}

// pendingCommand — команда, що очікує на завершення (END).
type pendingCommand struct {
	Command   string
	Shell     string
	User      string
	WorkDir   string
	StartTime time.Time
}

// hookMessage — JSON повідомлення від shell hook.
type hookMessage struct {
	Action     string `json:"action"`      // "start" або "end"
	CmdID      string `json:"cmd_id"`      // унікальний ID команди (PID_TIMESTAMP)
	Command    string `json:"command"`      // команда (тільки в start)
	Shell      string `json:"shell"`        // bash/zsh (тільки в start)
	User       string `json:"user"`         // username (тільки в start)
	Pwd        string `json:"pwd"`          // working directory (тільки в start)
	ExitCode   int    `json:"exit_code"`    // код завершення (тільки в end)
	DurationMs int64  `json:"duration_ms"`  // тривалість мс (тільки в end)
}

// NewWatcher створює новий shell-watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:     cfg,
		writer:  writer,
		log:     log,
		pending: make(map[string]*pendingCommand),
	}
}

// ============================================================================
// Run — UNIX socket listener
// ============================================================================

// Run створює UNIX socket та слухає вхідні з'єднання від shell hooks.
func (w *Watcher) Run(ctx context.Context) error {
	socketPath := w.cfg.Shell.SocketPath

	// Видаляємо старий socket якщо існує
	os.Remove(socketPath)

	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", socketPath, err)
	}
	defer listener.Close()
	defer os.Remove(socketPath)

	// Робимо socket доступним для всіх (shell hooks працюють від різних користувачів)
	if err := os.Chmod(socketPath, 0666); err != nil {
		w.log.Warn("chmod socket: %v", err)
	}

	w.log.Info("listening on %s", socketPath)

	// Запускаємо cleanup горутину для pending commands з таймаутом
	go w.cleanupLoop(ctx)

	// Accept loop
	go func() {
		<-ctx.Done()
		listener.Close()
	}()

	for {
		conn, err := listener.Accept()
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				w.log.Error("accept: %v", err)
				continue
			}
		}

		go w.handleConnection(conn)
	}
}

// handleConnection обробляє одне з'єднання від shell hook.
// Кожне з'єднання може містити одне або кілька JSON повідомлень (по рядку).
func (w *Watcher) handleConnection(conn net.Conn) {
	defer conn.Close()

	// Таймаут на читання — hook не повинен висіти довго
	conn.SetReadDeadline(time.Now().Add(5 * time.Second))

	scanner := bufio.NewScanner(conn)
	// Збільшуємо буфер для довгих команд
	scanner.Buffer(make([]byte, 0, 64*1024), 64*1024)

	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}

		var msg hookMessage
		if err := json.Unmarshal([]byte(line), &msg); err != nil {
			w.log.Debug("invalid JSON from hook: %v", err)
			continue
		}

		switch msg.Action {
		case "start":
			w.handleStart(msg)
		case "end":
			w.handleEnd(msg)
		default:
			w.log.Debug("unknown action: %s", msg.Action)
		}
	}
}

// ============================================================================
// START / END handlers
// ============================================================================

// handleStart зберігає команду в pending map, чекаючи на END.
func (w *Watcher) handleStart(msg hookMessage) {
	if msg.CmdID == "" || msg.Command == "" {
		return
	}

	// Ігноруємо порожні та внутрішні команди hook
	if isHookInternal(msg.Command) {
		return
	}

	w.mu.Lock()
	w.pending[msg.CmdID] = &pendingCommand{
		Command:   msg.Command,
		Shell:     msg.Shell,
		User:      msg.User,
		WorkDir:   msg.Pwd,
		StartTime: time.Now(),
	}
	w.mu.Unlock()

	w.log.Debug("start: cmd_id=%s user=%s cmd=%s", msg.CmdID, msg.User, truncate(msg.Command, 80))
}

// handleEnd знаходить pending команду, створює повну подію та записує.
func (w *Watcher) handleEnd(msg hookMessage) {
	if msg.CmdID == "" {
		return
	}

	w.mu.Lock()
	cmd, exists := w.pending[msg.CmdID]
	if exists {
		delete(w.pending, msg.CmdID)
	}
	w.mu.Unlock()

	if !exists {
		w.log.Debug("end: no pending start for cmd_id=%s", msg.CmdID)
		return
	}

	// Обчислюємо тривалість
	durationMs := msg.DurationMs
	if durationMs == 0 {
		durationMs = time.Since(cmd.StartTime).Milliseconds()
	}

	event := types.ShellCommandEvent{
		BaseEvent:  types.NewBaseEvent("shell_command", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		Command:    cmd.Command,
		Shell:      cmd.Shell,
		User:       cmd.User,
		WorkingDir: cmd.WorkDir,
		ExitCode:   msg.ExitCode,
		DurationMs: durationMs,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write event: %v", err)
		return
	}

	w.log.Info("command: user=%s exit=%d dur=%dms cmd=%s",
		cmd.User, msg.ExitCode, durationMs, truncate(cmd.Command, 100))
}

// ============================================================================
// Cleanup — видалення застарілих pending commands
// ============================================================================

// cleanupLoop періодично видаляє pending commands, які не отримали END.
// Це може статися якщо команда була перервана (Ctrl+C) або shell hook не спрацював.
func (w *Watcher) cleanupLoop(ctx context.Context) {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.cleanupStale()
		}
	}
}

// cleanupStale видаляє pending commands старші за 5 хвилин.
// Такі команди записуються з exit_code=-1 (невідомий).
func (w *Watcher) cleanupStale() {
	w.mu.Lock()
	defer w.mu.Unlock()

	staleThreshold := 5 * time.Minute
	now := time.Now()

	for cmdID, cmd := range w.pending {
		if now.Sub(cmd.StartTime) > staleThreshold {
			// Записуємо як незавершену команду
			event := types.ShellCommandEvent{
				BaseEvent:  types.NewBaseEvent("shell_command", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
				Command:    cmd.Command,
				Shell:      cmd.Shell,
				User:       cmd.User,
				WorkingDir: cmd.WorkDir,
				ExitCode:   -1, // невідомий
				DurationMs: now.Sub(cmd.StartTime).Milliseconds(),
			}

			if err := w.writer.Write(event); err != nil {
				w.log.Error("write stale event: %v", err)
			}

			w.log.Debug("stale command flushed: cmd_id=%s cmd=%s", cmdID, truncate(cmd.Command, 60))
			delete(w.pending, cmdID)
		}
	}
}

// ============================================================================
// Утиліти
// ============================================================================

// isHookInternal перевіряє чи команда є внутрішньою командою hook.
// Ці команди генеруються самим hook-скриптом і не повинні записуватись.
func isHookInternal(cmd string) bool {
	internals := []string{
		"__cp_preexec",
		"__cp_precmd",
		"__cp_send",
		"_cp_hook",
	}
	for _, prefix := range internals {
		if len(cmd) >= len(prefix) && cmd[:len(prefix)] == prefix {
			return true
		}
	}
	return false
}

// truncate обрізає рядок до maxLen символів, додаючи "..." якщо обрізано.
func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
