package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/fsnotify/fsnotify"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher моніторить файлову систему через fsnotify та записує FSEvent.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger
}

// NewWatcher створює новий fs-monitor watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:    cfg,
		writer: writer,
		log:    log,
	}
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run запускає fsnotify watcher на сконфігурованих шляхах.
func (w *Watcher) Run(ctx context.Context) error {
	fsWatcher, err := fsnotify.NewWatcher()
	if err != nil {
		return fmt.Errorf("create fsnotify watcher: %w", err)
	}
	defer fsWatcher.Close()

	// Додаємо всі watch paths рекурсивно
	watchCount := 0
	for _, root := range w.cfg.FS.WatchPaths {
		added, err := w.addRecursive(fsWatcher, root)
		if err != nil {
			w.log.Warn("add watch path %s: %v", root, err)
			continue
		}
		watchCount += added
	}

	w.log.Info("watching %d directories across %d root paths", watchCount, len(w.cfg.FS.WatchPaths))

	// Обробка подій
	for {
		select {
		case <-ctx.Done():
			w.log.Info("context cancelled, stopping")
			return nil

		case event, ok := <-fsWatcher.Events:
			if !ok {
				return fmt.Errorf("fsnotify events channel closed")
			}
			w.handleEvent(fsWatcher, event)

		case err, ok := <-fsWatcher.Errors:
			if !ok {
				return fmt.Errorf("fsnotify errors channel closed")
			}
			w.log.Error("fsnotify error: %v", err)
		}
	}
}

// ============================================================================
// Рекурсивне додавання директорій
// ============================================================================

// addRecursive додає директорію та всі піддиректорії до fsnotify watcher.
// Повертає кількість доданих директорій.
func (w *Watcher) addRecursive(fsWatcher *fsnotify.Watcher, root string) (int, error) {
	count := 0

	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		if err != nil {
			return nil // Пропускаємо недоступні
		}

		if !info.IsDir() {
			return nil
		}

		// Перевіряємо exclude paths
		if w.isExcluded(path) {
			return filepath.SkipDir
		}

		if err := fsWatcher.Add(path); err != nil {
			w.log.Debug("skip watch %s: %v", path, err)
			return nil
		}

		count++
		return nil
	})

	return count, err
}

// isExcluded перевіряє чи шлях або будь-який з його батьків в exclude списку.
func (w *Watcher) isExcluded(path string) bool {
	for _, excl := range w.cfg.FS.ExcludePaths {
		if path == excl || strings.HasPrefix(path, excl+"/") {
			return true
		}
	}
	return false
}

// ============================================================================
// Обробка подій fsnotify
// ============================================================================

// handleEvent обробляє одну fsnotify подію.
func (w *Watcher) handleEvent(fsWatcher *fsnotify.Watcher, event fsnotify.Event) {
	path := event.Name

	// Ігноруємо excluded шляхи
	if w.isExcluded(path) {
		return
	}

	// Ігноруємо тимчасові файли редакторів
	if w.isEditorTempFile(path) {
		return
	}

	operation := w.operationString(event.Op)
	if operation == "" {
		return
	}

	// Отримуємо інформацію про файл
	stat, statErr := os.Lstat(path)
	isDir := statErr == nil && stat.IsDir()

	// Якщо створено нову директорію — додаємо до watch
	if event.Op&fsnotify.Create != 0 && isDir {
		if added, err := w.addRecursive(fsWatcher, path); err == nil && added > 0 {
			w.log.Debug("added new directory to watch: %s (+%d)", path, added)
		}
	}

	// Категоризуємо подію
	category := w.categorize(path, operation)

	// Будуємо подію
	fsEvent := types.FSEvent{
		BaseEvent: types.NewBaseEvent("fs_event", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		Path:      path,
		Operation: operation,
		Category:  category,
		IsDir:     isDir,
	}

	// Для файлів (не директорій) — додаємо розмір, preview, SHA256
	if statErr == nil && !isDir {
		fsEvent.FileSize = stat.Size()

		// Preview та SHA256 тільки для create/write (не для remove)
		if operation != "remove" {
			fsEvent.FilePreview = w.readPreview(path)
			fsEvent.SHA256 = w.hashFile(path)

			// Копіюємо файл якщо увімкнено
			if w.cfg.FS.CopyFiles {
				w.copyFile(path, category)
			}
		}
	}

	if err := w.writer.Write(fsEvent); err != nil {
		w.log.Error("write event: %v", err)
		return
	}

	w.log.Info("event: %s op=%s cat=%s size=%d", path, operation, category, fsEvent.FileSize)
}

// ============================================================================
// Категоризація
// ============================================================================

// categorize визначає категорію файлової події на основі шляху та операції.
func (w *Watcher) categorize(path, operation string) types.FSEventCategory {
	// Видалення логів
	if operation == "remove" && isLogPath(path) {
		return types.FSCategoryLogDeletion
	}

	// Зміни конфігів
	if isConfigPath(path) {
		return types.FSCategoryConfigChange
	}

	// Uploads (нові файли у web-директоріях, /tmp)
	if operation == "create" && isUploadPath(path) {
		return types.FSCategoryUpload
	}

	// Системні зміни (/root, системні бінарники)
	if isSystemPath(path) {
		return types.FSCategorySystemChange
	}

	return types.FSCategoryGeneral
}

// isLogPath — чи є шлях логовим файлом.
func isLogPath(path string) bool {
	logDirs := []string{"/var/log/", "/var/log"}
	for _, d := range logDirs {
		if strings.HasPrefix(path, d) {
			return true
		}
	}
	logExts := []string{".log", ".log.1", ".log.gz"}
	for _, ext := range logExts {
		if strings.HasSuffix(path, ext) {
			return true
		}
	}
	return false
}

// isConfigPath — чи є шлях конфігураційним файлом.
func isConfigPath(path string) bool {
	configDirs := []string{"/etc/"}
	for _, d := range configDirs {
		if strings.HasPrefix(path, d) {
			return true
		}
	}
	configFiles := []string{
		".conf", ".cfg", ".ini", ".yaml", ".yml", ".json", ".xml",
		".htaccess", ".htpasswd", ".env",
		"authorized_keys", "sshd_config", "sudoers",
	}
	base := filepath.Base(path)
	for _, cf := range configFiles {
		if strings.HasSuffix(base, cf) || base == cf {
			return true
		}
	}
	return false
}

// isUploadPath — чи є шлях у директорії, куди типово завантажують файли.
func isUploadPath(path string) bool {
	uploadDirs := []string{
		"/var/www/", "/srv/", "/tmp/", "/var/tmp/",
		"/opt/", "/home/",
	}
	for _, d := range uploadDirs {
		if strings.HasPrefix(path, d) {
			return true
		}
	}
	// Типові розширення вебшелів та payload
	suspiciousExts := []string{
		".php", ".jsp", ".asp", ".aspx", ".py", ".pl", ".cgi",
		".sh", ".elf", ".bin", ".so",
	}
	for _, ext := range suspiciousExts {
		if strings.HasSuffix(path, ext) {
			return true
		}
	}
	return false
}

// isSystemPath — чи є шлях системним.
func isSystemPath(path string) bool {
	systemDirs := []string{
		"/root/", "/usr/local/bin/", "/usr/bin/", "/usr/sbin/",
		"/sbin/", "/bin/",
	}
	for _, d := range systemDirs {
		if strings.HasPrefix(path, d) {
			return true
		}
	}
	return false
}

// ============================================================================
// Утиліти
// ============================================================================

// operationString конвертує fsnotify.Op у читабельний рядок.
func (w *Watcher) operationString(op fsnotify.Op) string {
	switch {
	case op&fsnotify.Create != 0:
		return "create"
	case op&fsnotify.Write != 0:
		return "write"
	case op&fsnotify.Remove != 0:
		return "remove"
	case op&fsnotify.Rename != 0:
		return "rename"
	case op&fsnotify.Chmod != 0:
		return "chmod"
	default:
		return ""
	}
}

// readPreview читає перші N байт файлу як preview.
func (w *Watcher) readPreview(path string) string {
	maxSize := w.cfg.FS.MaxPreviewSizeBytes
	if maxSize == 0 {
		maxSize = 2048
	}

	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	buf := make([]byte, maxSize)
	n, err := f.Read(buf)
	if n == 0 {
		return ""
	}

	// Перевіряємо чи контент текстовий (не бінарний)
	content := buf[:n]
	if isBinary(content) {
		return fmt.Sprintf("[binary, %d bytes]", n)
	}

	return string(content)
}

// isBinary перевіряє чи дані містять null-байти (ознака бінарного файлу).
func isBinary(data []byte) bool {
	for _, b := range data {
		if b == 0 {
			return true
		}
	}
	return false
}

// hashFile обчислює SHA256 файлу.
func (w *Watcher) hashFile(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}

	return hex.EncodeToString(h.Sum(nil))
}

// copyFile копіює файл у /home/iron/files/ зі збереженням структури шляху.
// Наприклад: /var/www/uploads/cmd.php → /home/iron/files/var/www/uploads/cmd.php
func (w *Watcher) copyFile(srcPath string, category types.FSEventCategory) {
	// Копіюємо тільки uploads та підозрілі файли
	if category != types.FSCategoryUpload && category != types.FSCategorySystemChange {
		return
	}

	// Перевіряємо розмір — не копіюємо файли більше 10 MB
	stat, err := os.Stat(srcPath)
	if err != nil || stat.Size() > 10*1024*1024 {
		return
	}

	// Будуємо шлях призначення
	// /var/www/uploads/cmd.php → /home/iron/files/var/www/uploads/cmd.php
	relPath := strings.TrimPrefix(srcPath, "/")
	dstPath := filepath.Join(w.cfg.Storage.FilesPath, relPath)

	// Створюємо директорію
	dstDir := filepath.Dir(dstPath)
	if err := os.MkdirAll(dstDir, 0700); err != nil {
		w.log.Debug("create copy dir %s: %v", dstDir, err)
		return
	}

	// Додаємо timestamp до імені щоб уникнути перезапису
	ext := filepath.Ext(dstPath)
	base := strings.TrimSuffix(dstPath, ext)
	ts := time.Now().UTC().Format("20060102T150405Z")
	dstPath = fmt.Sprintf("%s_%s%s", base, ts, ext)

	// Копіюємо
	src, err := os.Open(srcPath)
	if err != nil {
		return
	}
	defer src.Close()

	dst, err := os.OpenFile(dstPath, os.O_CREATE|os.O_WRONLY, 0600)
	if err != nil {
		return
	}
	defer dst.Close()

	if _, err := io.Copy(dst, src); err != nil {
		w.log.Debug("copy file %s: %v", srcPath, err)
		return
	}

	w.log.Debug("copied %s → %s", srcPath, dstPath)
}

// isEditorTempFile перевіряє чи файл є тимчасовим файлом текстового редактора.
// Ці файли створюються vim, nano, emacs та іншими редакторами і є шумом.
func (w *Watcher) isEditorTempFile(path string) bool {
	base := filepath.Base(path)

	// vim: .file.swp, .file.swo, file~, 4913
	if strings.HasPrefix(base, ".") && (strings.HasSuffix(base, ".swp") || strings.HasSuffix(base, ".swo")) {
		return true
	}
	if base == "4913" { // vim test file
		return true
	}

	// emacs: #file#, file~
	if strings.HasPrefix(base, "#") && strings.HasSuffix(base, "#") {
		return true
	}

	// Загальне: file~, .#file
	if strings.HasSuffix(base, "~") {
		return true
	}
	if strings.HasPrefix(base, ".#") {
		return true
	}

	return false
}
