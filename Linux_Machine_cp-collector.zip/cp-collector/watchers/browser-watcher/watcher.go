package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Watcher керує mitmproxy та читає події через UNIX socket.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger
}

// NewWatcher створює новий browser-watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:    cfg,
		writer: writer,
		log:    log,
	}
}

// proxyEvent — JSON повідомлення від mitmproxy addon.
type proxyEvent struct {
	Method              string `json:"method"`
	URL                 string `json:"url"`
	Host                string `json:"host"`
	StatusCode          int    `json:"status_code"`
	ContentType         string `json:"content_type"`
	RequestBodyPreview  string `json:"request_body"`
	ResponseBodyPreview string `json:"response_body"`
	DurationMs          int64  `json:"duration_ms"`
	User                string `json:"user"`
	ClientIP            string `json:"client_ip"`
	Timestamp           string `json:"timestamp"`
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run запускає mitmproxy та UNIX socket listener паралельно.
func (w *Watcher) Run(ctx context.Context) error {
	socketPath := w.cfg.Browser.OutputSocketPath

	// Видаляємо старий socket
	os.Remove(socketPath)

	// Запускаємо UNIX socket listener
	listener, err := net.Listen("unix", socketPath)
	if err != nil {
		return fmt.Errorf("listen %s: %w", socketPath, err)
	}
	defer listener.Close()
	defer os.Remove(socketPath)

	if err := os.Chmod(socketPath, 0666); err != nil {
		w.log.Warn("chmod socket: %v", err)
	}

	w.log.Info("socket listening on %s", socketPath)

	// Запускаємо mitmproxy як дочірній процес
	mitmCtx, mitmCancel := context.WithCancel(ctx)
	defer mitmCancel()

	go w.runMitmproxy(mitmCtx)

	// Accept loop
	go func() {
		<-ctx.Done()
		listener.Close()
	}()

	for {
		conn, err := listener.Accept()
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
				w.log.Error("accept: %v", err)
				continue
			}
		}

		go w.handleConnection(conn)
	}
}

// ============================================================================
// mitmproxy management
// ============================================================================

// runMitmproxy запускає mitmdump з Python addon.
// Перезапускає при краші (до скасування контексту).
func (w *Watcher) runMitmproxy(ctx context.Context) {
	port := w.cfg.Browser.MitmproxyPort
	socketPath := w.cfg.Browser.OutputSocketPath

	// Шлях до addon — поруч з бінарником або в /home/iron/
	addonPath := w.findAddonPath()
	if addonPath == "" {
		w.log.Error("mitmproxy addon not found (cp_proxy.py)")
		return
	}

	w.log.Info("mitmproxy addon: %s", addonPath)

	for {
		select {
		case <-ctx.Done():
			return
		default:
		}

		w.log.Info("starting mitmdump on port %d (transparent mode)", port)

		cmd := exec.CommandContext(ctx, "mitmdump",
			"--mode", "transparent",
			"-p", fmt.Sprintf("%d", port),
			"--set", fmt.Sprintf("cp_socket=%s", socketPath),
			"--set", fmt.Sprintf("cp_max_body=%d", w.cfg.Browser.MaxBodyPreviewBytes),
			"-s", addonPath,
			"--quiet",
			"--set", "flow_detail=0",
		)

		cmd.Stdout = os.Stdout
		cmd.Stderr = os.Stderr

		// Запускаємо від iron щоб iptables виключення працювало
		// (iptables правило: -m owner --uid-owner iron -j RETURN)
		cmd.SysProcAttr = nil // наслідує від parent

		if err := cmd.Run(); err != nil {
			select {
			case <-ctx.Done():
				return
			default:
				w.log.Warn("mitmdump exited: %v, restarting in 5s...", err)
				time.Sleep(5 * time.Second)
			}
		}
	}
}

// findAddonPath шукає Python addon файл у типових шляхах.
func (w *Watcher) findAddonPath() string {
	searchPaths := []string{
		"/home/iron/addon/cp_proxy.py",
		"/home/iron/cp_proxy.py",
		// Відносно бінарника
		"addon/cp_proxy.py",
		"cp_proxy.py",
	}

	// Також шукаємо поруч з бінарником
	if exe, err := os.Executable(); err == nil {
		dir := filepath.Dir(exe)
		searchPaths = append(searchPaths,
			filepath.Join(dir, "addon", "cp_proxy.py"),
			filepath.Join(dir, "cp_proxy.py"),
		)
	}

	for _, p := range searchPaths {
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}

	return ""
}

// ============================================================================
// UNIX socket — обробка з'єднань від mitmproxy addon
// ============================================================================

// handleConnection читає JSON рядки від mitmproxy addon.
func (w *Watcher) handleConnection(conn net.Conn) {
	defer conn.Close()

	conn.SetReadDeadline(time.Now().Add(10 * time.Second))

	scanner := bufio.NewScanner(conn)
	scanner.Buffer(make([]byte, 0, 128*1024), 128*1024)

	for scanner.Scan() {
		line := scanner.Text()
		if line == "" {
			continue
		}

		var event proxyEvent
		if err := json.Unmarshal([]byte(line), &event); err != nil {
			w.log.Debug("invalid JSON from addon: %v", err)
			continue
		}

		w.processEvent(event)
	}
}

// processEvent конвертує proxyEvent у BrowserRequestEvent та записує.
func (w *Watcher) processEvent(pe proxyEvent) {
	// Ігноруємо внутрішні запити mitmproxy
	if strings.Contains(pe.URL, "mitm.it") {
		return
	}

	// Ігноруємо запити до нашого socket
	if strings.Contains(pe.URL, "shell-watcher") || strings.Contains(pe.URL, "mitmproxy.sock") {
		return
	}

	event := types.BrowserRequestEvent{
		BaseEvent:           types.NewBaseEvent("browser_request", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		Method:              pe.Method,
		URL:                 pe.URL,
		Host:                pe.Host,
		StatusCode:          pe.StatusCode,
		ContentType:         pe.ContentType,
		RequestBodyPreview:  pe.RequestBodyPreview,
		ResponseBodyPreview: pe.ResponseBodyPreview,
		DurationMs:          pe.DurationMs,
		User:                pe.User,
	}

	if err := w.writer.Write(event); err != nil {
		w.log.Error("write event: %v", err)
		return
	}

	w.log.Info("request: %s %s → %d (%dms)",
		pe.Method, truncate(pe.URL, 80), pe.StatusCode, pe.DurationMs)
}

// truncate обрізає рядок.
func truncate(s string, maxLen int) string {
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
