module github.com/cyber-polygon/cp-collector/watchers/browser-watcher

go 1.22.5

toolchain go1.22.5

require (
	github.com/cyber-polygon/cp-collector/shared v0.0.0
	gopkg.in/yaml.v3 v3.0.1
)

replace github.com/cyber-polygon/cp-collector/shared => ../../shared
