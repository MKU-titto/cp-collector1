"""
cp_proxy.py — mitmproxy addon для Cyber Polygon browser-watcher.

Перехоплює HTTP/HTTPS request+response та надсилає JSON
через UNIX socket до Go-процесу browser-watcher.

Використання:
    mitmdump --mode transparent -p 8080 \
        --set cp_socket=/home/iron/mitmproxy.sock \
        --set cp_max_body=4096 \
        -s cp_proxy.py

Кожна подія — один JSON рядок:
{
    "method": "GET",
    "url": "https://example.com/path",
    "host": "example.com",
    "status_code": 200,
    "content_type": "text/html",
    "request_body": "",
    "response_body": "<!DOCTYPE html>...",
    "duration_ms": 123,
    "user": "",
    "client_ip": "127.0.0.1",
    "timestamp": "2026-03-30T12:00:00.000Z"
}
"""

import json
import socket
import time
import os
import logging
from datetime import datetime, timezone

from mitmproxy import http, ctx

logger = logging.getLogger("cp_proxy")


class CyberPolygonAddon:
    """mitmproxy addon для відправки подій на UNIX socket."""

    def __init__(self):
        self.socket_path = "/home/iron/mitmproxy.sock"
        self.max_body = 4096
        # Зберігаємо час початку запиту по flow.id
        self.flow_start: dict[str, float] = {}

    def load(self, loader):
        """Реєструємо опції mitmproxy."""
        loader.add_option(
            name="cp_socket",
            typespec=str,
            default="/home/iron/mitmproxy.sock",
            help="UNIX socket path for browser-watcher",
        )
        loader.add_option(
            name="cp_max_body",
            typespec=int,
            default=4096,
            help="Max body preview size in bytes",
        )

    def configure(self, updates):
        """Оновлюємо налаштування."""
        self.socket_path = ctx.options.cp_socket
        self.max_body = ctx.options.cp_max_body
        logger.info(
            f"cp_proxy configured: socket={self.socket_path} max_body={self.max_body}"
        )

    def request(self, flow: http.HTTPFlow):
        """Фіксуємо час початку запиту."""
        self.flow_start[flow.id] = time.time()

    def response(self, flow: http.HTTPFlow):
        """Обробляємо завершений request+response."""
        try:
            self._process_flow(flow)
        except Exception as e:
            logger.debug(f"process flow error: {e}")
        finally:
            # Очищуємо
            self.flow_start.pop(flow.id, None)

    def _process_flow(self, flow: http.HTTPFlow):
        """Формує JSON та надсилає через UNIX socket."""
        request = flow.request
        response = flow.response

        if response is None:
            return

        # Ігноруємо внутрішні запити mitmproxy
        if "mitm.it" in request.pretty_host:
            return

        # Рахуємо тривалість
        start_time = self.flow_start.get(flow.id, time.time())
        duration_ms = int((time.time() - start_time) * 1000)

        # Content-Type
        content_type = response.headers.get("Content-Type", "")

        # Request body preview
        request_body = ""
        if request.content and len(request.content) > 0:
            request_body = self._safe_decode(request.content, self.max_body)

        # Response body preview (тільки текстові)
        response_body = ""
        if response.content and self._is_text_content(content_type):
            response_body = self._safe_decode(response.content, self.max_body)

        # Client IP
        client_ip = ""
        if flow.client_conn and flow.client_conn.peername:
            client_ip = flow.client_conn.peername[0]

        event = {
            "method": request.method,
            "url": request.pretty_url,
            "host": request.pretty_host,
            "status_code": response.status_code,
            "content_type": content_type.split(";")[0].strip(),
            "request_body": request_body,
            "response_body": response_body,
            "duration_ms": duration_ms,
            "user": "",
            "client_ip": client_ip,
            "timestamp": datetime.now(timezone.utc).strftime(
                "%Y-%m-%dT%H:%M:%S.%f"
            )[:-3]
            + "Z",
        }

        self._send_event(event)

    def _send_event(self, event: dict):
        """Надсилає JSON подію через UNIX socket."""
        if not os.path.exists(self.socket_path):
            return

        try:
            sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            sock.settimeout(2)
            sock.connect(self.socket_path)
            data = json.dumps(event, ensure_ascii=False) + "\n"
            sock.sendall(data.encode("utf-8"))
            sock.close()
        except (ConnectionRefusedError, FileNotFoundError, OSError) as e:
            logger.debug(f"send to socket failed: {e}")

    def _safe_decode(self, data: bytes, max_len: int) -> str:
        """Декодує bytes у string, обрізає до max_len."""
        try:
            text = data[:max_len].decode("utf-8", errors="replace")
        except Exception:
            text = data[:max_len].decode("latin-1", errors="replace")

        # Замінюємо null-байти
        text = text.replace("\x00", "")
        return text

    def _is_text_content(self, content_type: str) -> bool:
        """Перевіряє чи Content-Type є текстовим."""
        ct = content_type.lower()
        text_types = [
            "text/",
            "application/json",
            "application/xml",
            "application/javascript",
            "application/x-www-form-urlencoded",
            "application/soap",
            "application/xhtml",
        ]
        return any(t in ct for t in text_types)

    def error(self, flow: http.HTTPFlow):
        """Очищуємо при помилці."""
        self.flow_start.pop(flow.id, None)


addons = [CyberPolygonAddon()]
