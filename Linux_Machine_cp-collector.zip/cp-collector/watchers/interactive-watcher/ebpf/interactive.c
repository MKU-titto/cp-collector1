// interactive.c — eBPF програма для перехоплення stdin/stdout
// інтерактивних CTF-інструментів.
//
// Компіляція:
//   clang -O2 -g -target bpf -D__TARGET_ARCH_x86 \
//     -I/usr/include/bpf -I/usr/include \
//     -c interactive.c -o interactive.o

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

// ============================================================================
// Ручні визначення kernel struct для tracepoints
// (не доступні через <linux/bpf.h> — потрібен vmlinux.h або ручні defs)
// ============================================================================

struct trace_event_raw_sys_enter {
    unsigned short common_type;
    unsigned char  common_flags;
    unsigned char  common_preempt_count;
    int            common_pid;
    long           id;
    unsigned long  args[6];
};

struct trace_event_raw_sys_exit {
    unsigned short common_type;
    unsigned char  common_flags;
    unsigned char  common_preempt_count;
    int            common_pid;
    long           id;
    long           ret;
};

#define MAX_DATA_LEN 4096
#define EVENT_TYPE_READ  1
#define EVENT_TYPE_WRITE 2

struct event_t {
    __u32 pid;
    __u32 uid;
    __u32 fd;
    __u32 event_type;
    __u32 data_len;
    char  comm[16];
    char  data[MAX_DATA_LEN];
};

struct rw_args_t {
    __u64 buf_addr;
    __u32 fd;
};

// BPF Maps
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 24);
} events SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024);
    __type(key, __u32);
    __type(value, __u8);
} target_pids SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 8192);
    __type(key, __u64);
    __type(value, struct rw_args_t);
} active_rw SEC(".maps");

static __always_inline int is_target_pid(__u32 pid) {
    __u8 *val = bpf_map_lookup_elem(&target_pids, &pid);
    return val != NULL;
}

static __always_inline __u64 get_pid_tgid_key(void) {
    return bpf_get_current_pid_tgid();
}

SEC("tracepoint/syscalls/sys_enter_read")
int tp_sys_enter_read(struct trace_event_raw_sys_enter *ctx) {
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    if (!is_target_pid(pid))
        return 0;
    __u32 fd = (__u32)ctx->args[0];
    if (fd != 0)
        return 0;
    __u64 key = get_pid_tgid_key();
    struct rw_args_t args = { .buf_addr = ctx->args[1], .fd = fd };
    bpf_map_update_elem(&active_rw, &key, &args, BPF_ANY);
    return 0;
}

SEC("tracepoint/syscalls/sys_exit_read")
int tp_sys_exit_read(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = get_pid_tgid_key();
    __u32 pid = key >> 32;
    struct rw_args_t *args = bpf_map_lookup_elem(&active_rw, &key);
    if (!args)
        return 0;
    long ret = ctx->ret;
    if (ret <= 0) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }
    // Бітова маска — eBPF verifier вимагає гарантовано позитивний діапазон
    __u32 data_len = (__u32)ret & (MAX_DATA_LEN - 1);
    if (data_len == 0) data_len = 1;

    struct event_t *event = bpf_ringbuf_reserve(&events, sizeof(struct event_t), 0);
    if (!event) { bpf_map_delete_elem(&active_rw, &key); return 0; }

    event->pid = pid;
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->fd = args->fd;
    event->event_type = EVENT_TYPE_READ;
    event->data_len = data_len;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));
    if (bpf_probe_read_user(event->data, data_len, (void *)args->buf_addr) != 0) {
        bpf_ringbuf_discard(event, 0);
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }
    bpf_ringbuf_submit(event, 0);
    bpf_map_delete_elem(&active_rw, &key);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_write")
int tp_sys_enter_write(struct trace_event_raw_sys_enter *ctx) {
    __u32 pid = bpf_get_current_pid_tgid() >> 32;
    if (!is_target_pid(pid))
        return 0;
    __u32 fd = (__u32)ctx->args[0];
    if (fd != 1 && fd != 2)
        return 0;
    __u64 key = get_pid_tgid_key();
    struct rw_args_t args = { .buf_addr = ctx->args[1], .fd = fd };
    bpf_map_update_elem(&active_rw, &key, &args, BPF_ANY);
    return 0;
}

SEC("tracepoint/syscalls/sys_exit_write")
int tp_sys_exit_write(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = get_pid_tgid_key();
    __u32 pid = key >> 32;
    struct rw_args_t *args = bpf_map_lookup_elem(&active_rw, &key);
    if (!args)
        return 0;
    long ret = ctx->ret;
    if (ret <= 0) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }
    __u32 data_len = (__u32)ret & (MAX_DATA_LEN - 1);
    if (data_len == 0) data_len = 1;

    struct event_t *event = bpf_ringbuf_reserve(&events, sizeof(struct event_t), 0);
    if (!event) { bpf_map_delete_elem(&active_rw, &key); return 0; }

    event->pid = pid;
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->fd = args->fd;
    event->event_type = EVENT_TYPE_WRITE;
    event->data_len = data_len;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));
    if (bpf_probe_read_user(event->data, data_len, (void *)args->buf_addr) != 0) {
        bpf_ringbuf_discard(event, 0);
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }
    bpf_ringbuf_submit(event, 0);
    bpf_map_delete_elem(&active_rw, &key);
    return 0;
}

char _license[] SEC("license") = "GPL";
