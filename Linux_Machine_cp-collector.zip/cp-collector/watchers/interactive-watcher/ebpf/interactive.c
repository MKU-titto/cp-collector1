// interactive.c — eBPF програма для перехоплення stdin/stdout
// інтерактивних CTF-інструментів.
//
// Tracepoints:
//   sys_enter_read  — фіксує fd та буфер для read (stdin, fd=0)
//   sys_exit_read   — читає дані з буфера після завершення read
//   sys_enter_write — фіксує fd та буфер для write (stdout=1, stderr=2)
//   sys_exit_write  — читає дані з буфера після завершення write
//
// Фільтрація по PID: Go-код оновлює BPF hash map target_pids,
// eBPF перевіряє кожен syscall.
//
// Компіляція:
//   clang -O2 -g -target bpf -D__TARGET_ARCH_x86 \
//     -I/usr/include/bpf -c interactive.c -o interactive.o

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

#define MAX_DATA_LEN 4096
#define EVENT_TYPE_READ  1
#define EVENT_TYPE_WRITE 2

// Структура події для ring buffer — повинна відповідати Go-стороні
struct event_t {
    __u32 pid;
    __u32 uid;
    __u32 fd;
    __u32 event_type;  // EVENT_TYPE_READ або EVENT_TYPE_WRITE
    __u32 data_len;
    char  comm[16];
    char  data[MAX_DATA_LEN];
};

// Тимчасове зберігання параметрів між enter/exit
struct rw_args_t {
    __u64 buf_addr;
    __u32 fd;
};

// --------------------------------------------------------------------------
// BPF Maps
// --------------------------------------------------------------------------

// Ring buffer для передачі подій у Go userspace
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 24); // 16 MB
} events SEC(".maps");

// Hash map: PID → 1 (target процеси, оновлюється з Go)
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 1024);
    __type(key, __u32);
    __type(value, __u8);
} target_pids SEC(".maps");

// Per-task зберігання аргументів read/write між enter та exit
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 8192);
    __type(key, __u64);   // pid_tgid
    __type(value, struct rw_args_t);
} active_rw SEC(".maps");

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

// Перевіряє чи PID є target процесом
static __always_inline int is_target_pid(__u32 pid) {
    __u8 *val = bpf_map_lookup_elem(&target_pids, &pid);
    return val != NULL;
}

// Генерує ключ для active_rw map
static __always_inline __u64 get_pid_tgid_key(void) {
    return bpf_get_current_pid_tgid();
}

// --------------------------------------------------------------------------
// sys_enter_read — зберігаємо fd та адресу буфера
// --------------------------------------------------------------------------
SEC("tracepoint/syscalls/sys_enter_read")
int tp_sys_enter_read(struct trace_event_raw_sys_enter *ctx) {
    __u32 pid = bpf_get_current_pid_tgid() >> 32;

    if (!is_target_pid(pid))
        return 0;

    // args: fd, buf, count
    __u32 fd = (__u32)ctx->args[0];

    // Фільтруємо: тільки stdin (fd=0)
    if (fd != 0)
        return 0;

    __u64 key = get_pid_tgid_key();
    struct rw_args_t args = {
        .buf_addr = ctx->args[1],
        .fd = fd,
    };
    bpf_map_update_elem(&active_rw, &key, &args, BPF_ANY);

    return 0;
}

// --------------------------------------------------------------------------
// sys_exit_read — читаємо дані з буфера
// --------------------------------------------------------------------------
SEC("tracepoint/syscalls/sys_exit_read")
int tp_sys_exit_read(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = get_pid_tgid_key();
    __u32 pid = key >> 32;

    struct rw_args_t *args = bpf_map_lookup_elem(&active_rw, &key);
    if (!args)
        return 0;

    // ret = кількість прочитаних байт
    long ret = ctx->ret;
    if (ret <= 0) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    __u32 data_len = (__u32)ret;
    if (data_len > MAX_DATA_LEN)
        data_len = MAX_DATA_LEN;

    // Резервуємо місце в ring buffer
    struct event_t *event = bpf_ringbuf_reserve(&events, sizeof(struct event_t), 0);
    if (!event) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    event->pid = pid;
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->fd = args->fd;
    event->event_type = EVENT_TYPE_READ;
    event->data_len = data_len;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));

    // Копіюємо дані з userspace буфера
    // bpf_probe_read_user безпечно читає з userspace
    long err = bpf_probe_read_user(event->data, data_len & (MAX_DATA_LEN - 1), (void *)args->buf_addr);
    if (err != 0) {
        bpf_ringbuf_discard(event, 0);
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    bpf_ringbuf_submit(event, 0);
    bpf_map_delete_elem(&active_rw, &key);

    return 0;
}

// --------------------------------------------------------------------------
// sys_enter_write — зберігаємо fd та адресу буфера
// --------------------------------------------------------------------------
SEC("tracepoint/syscalls/sys_enter_write")
int tp_sys_enter_write(struct trace_event_raw_sys_enter *ctx) {
    __u32 pid = bpf_get_current_pid_tgid() >> 32;

    if (!is_target_pid(pid))
        return 0;

    // args: fd, buf, count
    __u32 fd = (__u32)ctx->args[0];

    // Фільтруємо: тільки stdout (fd=1) та stderr (fd=2)
    if (fd != 1 && fd != 2)
        return 0;

    __u64 key = get_pid_tgid_key();
    struct rw_args_t args = {
        .buf_addr = ctx->args[1],
        .fd = fd,
    };
    bpf_map_update_elem(&active_rw, &key, &args, BPF_ANY);

    return 0;
}

// --------------------------------------------------------------------------
// sys_exit_write — читаємо дані з буфера
// --------------------------------------------------------------------------
SEC("tracepoint/syscalls/sys_exit_write")
int tp_sys_exit_write(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = get_pid_tgid_key();
    __u32 pid = key >> 32;

    struct rw_args_t *args = bpf_map_lookup_elem(&active_rw, &key);
    if (!args)
        return 0;

    long ret = ctx->ret;
    if (ret <= 0) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    __u32 data_len = (__u32)ret;
    if (data_len > MAX_DATA_LEN)
        data_len = MAX_DATA_LEN;

    struct event_t *event = bpf_ringbuf_reserve(&events, sizeof(struct event_t), 0);
    if (!event) {
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    event->pid = pid;
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->fd = args->fd;
    event->event_type = EVENT_TYPE_WRITE;
    event->data_len = data_len;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));

    long err = bpf_probe_read_user(event->data, data_len & (MAX_DATA_LEN - 1), (void *)args->buf_addr);
    if (err != 0) {
        bpf_ringbuf_discard(event, 0);
        bpf_map_delete_elem(&active_rw, &key);
        return 0;
    }

    bpf_ringbuf_submit(event, 0);
    bpf_map_delete_elem(&active_rw, &key);

    return 0;
}

char _license[] SEC("license") = "GPL";
