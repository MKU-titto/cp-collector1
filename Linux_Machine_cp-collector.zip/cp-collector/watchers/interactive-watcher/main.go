// interactive-watcher — watcher-сервіс для перехоплення stdin/stdout
// інтерактивних CTF-інструментів через eBPF.
//
// Перехоплює повний цикл action → response для:
//   - msfconsole, gdb, python3, irb, node, mysql, psql, redis-cli
//   - mavproxy.py, sqlite3, ssh та інші REPL-інструменти
//
// Архітектура:
//   1. eBPF програма (interactive.c) хукає tracepoints:
//      - sys_enter_read / sys_exit_read   (fd=0, stdin)
//      - sys_enter_write / sys_exit_write (fd=1,2, stdout/stderr)
//   2. Go-код фільтрує по PID target-інструментів
//   3. Корелює input → response по таймауту (3 сек)
//   4. Записує InteractiveInputEvent з input_line + response_preview
//
// Запуск:
//
//	cp-interactive-watcher -config /home/iron/config/config.yaml
package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

const (
	watcherName = "interactive-watcher"
	version     = "3.0.0"
)

func main() {
	configPath := flag.String("config", "/home/iron/config/config.yaml", "Path to config file")
	showVersion := flag.Bool("version", false, "Show version and exit")
	flag.Parse()

	if *showVersion {
		fmt.Printf("cp-%s %s\n", watcherName, version)
		os.Exit(0)
	}

	log := logger.New(watcherName)
	log.Info("starting %s v%s", watcherName, version)

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Error("load config: %v", err)
		os.Exit(1)
	}

	if !cfg.Interactive.Enabled {
		log.Info("watcher disabled in config, exiting")
		os.Exit(0)
	}

	writer, err := storage.NewWriter(watcherName, cfg.Agent, cfg.Storage)
	if err != nil {
		log.Error("create storage: %v", err)
		os.Exit(1)
	}
	defer writer.Close()

	startTime := time.Now()
	writer.Write(types.AgentStartEvent{
		BaseEvent:   types.NewBaseEvent("agent_start", cfg.Agent.MachineID, cfg.Agent.CTFEventID),
		WatcherName: watcherName,
		Version:     version,
	})

	log.Info("config: capture_stdout=%v timeout=%ds ebpf=%s targets=%v",
		cfg.Interactive.CaptureStdout, cfg.Interactive.ResponseTimeoutSec,
		cfg.Interactive.EBPFObjectPath, cfg.Interactive.TargetTools)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	watcher := NewWatcher(cfg, writer, log)

	errCh := make(chan error, 1)
	go func() {
		errCh <- watcher.Run(ctx)
	}()

	sigCh := make(chan os.Signal, 1)
	signal.Notify(sigCh, syscall.SIGINT, syscall.SIGTERM)

	select {
	case sig := <-sigCh:
		log.Info("received signal: %v, shutting down...", sig)
		cancel()
	case err := <-errCh:
		if err != nil {
			log.Error("watcher error: %v", err)
		}
	}

	uptime := time.Since(startTime).Round(time.Second).String()
	writer.Write(types.AgentStopEvent{
		BaseEvent:   types.NewBaseEvent("agent_stop", cfg.Agent.MachineID, cfg.Agent.CTFEventID),
		WatcherName: watcherName,
		Uptime:      uptime,
	})

	stats := writer.Stats()
	log.Info("stopped. total_events=%d uptime=%s", stats.TotalEvents, uptime)
}
