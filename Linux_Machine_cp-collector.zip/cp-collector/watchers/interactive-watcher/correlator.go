package main

import (
	"context"
	"strings"
	"sync"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// Correlator корелює stdin input з stdout response по PID та таймауту.
//
// Алгоритм:
//  1. AddInput() зберігає input у pending map
//  2. AddOutput() додає output до відповідного pending input
//  3. Після таймауту (3 сек) або при наступному input — записує подію
type Correlator struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	mu      sync.Mutex
	pending map[uint32]*pendingInput // pid → pending input
}

// pendingInput — input що чекає на response.
type pendingInput struct {
	ProcessName string
	User        string
	InputLine   string
	Response    strings.Builder
	InputTime   time.Time
}

// NewCorrelator створює новий correlator.
func NewCorrelator(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Correlator {
	return &Correlator{
		cfg:     cfg,
		writer:  writer,
		log:     log,
		pending: make(map[uint32]*pendingInput),
	}
}

// AddInput зберігає новий stdin input.
// Якщо є попередній pending input для цього PID — спочатку flush його.
func (c *Correlator) AddInput(pid uint32, processName, user, input string) {
	c.mu.Lock()
	defer c.mu.Unlock()

	// Якщо є pending — flush перед новим input
	if prev, exists := c.pending[pid]; exists {
		c.flushLocked(pid, prev)
	}

	c.pending[pid] = &pendingInput{
		ProcessName: processName,
		User:        user,
		InputLine:   input,
		InputTime:   time.Now(),
	}
}

// AddOutput додає stdout/stderr дані до pending input для PID.
func (c *Correlator) AddOutput(pid uint32, data string) {
	c.mu.Lock()
	defer c.mu.Unlock()

	pending, exists := c.pending[pid]
	if !exists {
		return // немає pending input для цього PID
	}

	maxBytes := c.cfg.Interactive.MaxResponseBytes
	currentLen := int64(pending.Response.Len())

	if currentLen >= maxBytes {
		return // вже зібрали максимум
	}

	// Обрізаємо якщо перевищує ліміт
	remaining := maxBytes - currentLen
	if int64(len(data)) > remaining {
		data = data[:remaining]
	}

	pending.Response.WriteString(data)
}

// FlushLoop періодично перевіряє та flush-ить pending inputs по таймауту.
func (c *Correlator) FlushLoop(ctx context.Context) {
	ticker := time.NewTicker(500 * time.Millisecond)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			// Фінальний flush всіх pending
			c.FlushAll()
			return
		case <-ticker.C:
			c.flushExpired()
		}
	}
}

// flushExpired flush-ить pending inputs старші за таймаут.
func (c *Correlator) flushExpired() {
	c.mu.Lock()
	defer c.mu.Unlock()

	timeout := time.Duration(c.cfg.Interactive.ResponseTimeoutSec) * time.Second
	now := time.Now()

	for pid, pending := range c.pending {
		if now.Sub(pending.InputTime) >= timeout {
			c.flushLocked(pid, pending)
			delete(c.pending, pid)
		}
	}
}

// FlushAll flush-ить всі pending inputs (при shutdown).
func (c *Correlator) FlushAll() {
	c.mu.Lock()
	defer c.mu.Unlock()

	for pid, pending := range c.pending {
		c.flushLocked(pid, pending)
		delete(c.pending, pid)
	}
}

// flushLocked записує InteractiveInputEvent. Caller тримає lock.
func (c *Correlator) flushLocked(pid uint32, pending *pendingInput) {
	responsePreview := strings.TrimSpace(pending.Response.String())
	responseSizeBytes := int64(pending.Response.Len())

	event := types.InteractiveInputEvent{
		BaseEvent:         types.NewBaseEvent("interactive_input", c.cfg.Agent.MachineID, c.cfg.Agent.CTFEventID),
		ProcessName:       pending.ProcessName,
		PID:               int(pid),
		InputLine:         pending.InputLine,
		ResponsePreview:   responsePreview,
		ResponseSizeBytes: responseSizeBytes,
		User:              pending.User,
	}

	if err := c.writer.Write(event); err != nil {
		c.log.Error("write interactive event: %v", err)
		return
	}

	respInfo := ""
	if responseSizeBytes > 0 {
		respInfo = truncateResp(responsePreview, 60)
	}

	c.log.Info("interactive: pid=%d proc=%s input=%s response=%s",
		pid, pending.ProcessName,
		truncateResp(pending.InputLine, 60), respInfo)
}

// truncateResp обрізає рядок для логування.
func truncateResp(s string, maxLen int) string {
	// Беремо тільки перший рядок
	if idx := strings.IndexByte(s, '\n'); idx >= 0 {
		s = s[:idx]
	}
	if len(s) <= maxLen {
		return s
	}
	return s[:maxLen-3] + "..."
}
