module github.com/cyber-polygon/cp-collector/watchers/interactive-watcher

go 1.22

require (
	github.com/cyber-polygon/cp-collector/shared v0.0.0
	github.com/cilium/ebpf v0.15.0
	gopkg.in/yaml.v3 v3.0.1
)

require golang.org/x/sys v0.20.0 // indirect

// Локальна залежність на shared packages
replace github.com/cyber-polygon/cp-collector/shared => ../../shared
