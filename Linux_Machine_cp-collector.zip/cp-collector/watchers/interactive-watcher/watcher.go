package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// ============================================================================
// Константи — мають відповідати interactive.c
// ============================================================================

const (
	maxDataLen = 4096

	// Типи подій з eBPF
	eventTypeRead  = 1 // stdin (fd=0)
	eventTypeWrite = 2 // stdout/stderr (fd=1,2)
)

// bpfEvent — структура події з eBPF ring buffer.
// ВАЖЛИВО: повинна бути ідентична struct event_t у interactive.c.
type bpfEvent struct {
	PID       uint32
	UID       uint32
	FD        uint32
	EventType uint32 // 1=read, 2=write
	DataLen   uint32
	Comm      [16]byte
	Data      [maxDataLen]byte
}

// Watcher перехоплює stdin/stdout інтерактивних інструментів через eBPF.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	// Target PIDs — процеси які ми моніторимо
	mu         sync.RWMutex
	targetPIDs map[uint32]string // pid → process name

	// eBPF map для фільтрації PIDs в kernel space
	pidMap *ebpf.Map

	// Кореляція input → response
	correlator *Correlator
}

// NewWatcher створює новий interactive-watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:        cfg,
		writer:     writer,
		log:        log,
		targetPIDs: make(map[uint32]string),
		correlator: NewCorrelator(cfg, writer, log),
	}
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run завантажує eBPF програму, сканує target PIDs та обробляє події.
func (w *Watcher) Run(ctx context.Context) error {
	// Завантажуємо eBPF object
	spec, err := ebpf.LoadCollectionSpec(w.cfg.Interactive.EBPFObjectPath)
	if err != nil {
		return fmt.Errorf("load eBPF spec %s: %w", w.cfg.Interactive.EBPFObjectPath, err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}
	defer coll.Close()

	// Отримуємо ring buffer map
	eventsMap, ok := coll.Maps["events"]
	if !ok {
		return fmt.Errorf("eBPF map 'events' not found")
	}

	// Отримуємо PID filter map
	pidMap, ok := coll.Maps["target_pids"]
	if !ok {
		return fmt.Errorf("eBPF map 'target_pids' not found")
	}
	w.pidMap = pidMap

	// Attach tracepoints
	links, err := w.attachTracepoints(coll)
	if err != nil {
		return fmt.Errorf("attach tracepoints: %w", err)
	}
	for _, l := range links {
		defer l.Close()
	}

	// Створюємо ring buffer reader
	reader, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ring buffer reader: %w", err)
	}
	defer reader.Close()

	// Запускаємо PID scanner в окремій goroutine
	go w.pidScanLoop(ctx)

	// Запускаємо correlator flush loop
	go w.correlator.FlushLoop(ctx)

	w.log.Info("eBPF loaded, reading events...")

	// Читаємо події з ring buffer
	go func() {
		<-ctx.Done()
		reader.Close()
	}()

	for {
		record, err := reader.Read()
		if err != nil {
			if errors.Is(err, ringbuf.ErrClosed) {
				return nil
			}
			w.log.Error("read ring buffer: %v", err)
			continue
		}

		w.processEvent(record.RawSample)
	}
}

// ============================================================================
// eBPF tracepoint attachment
// ============================================================================

type closeable interface {
	Close() error
}

// attachTracepoints аттачить eBPF програми до tracepoints.
func (w *Watcher) attachTracepoints(coll *ebpf.Collection) ([]closeable, error) {
	var links []closeable

	tracepoints := map[string]string{
		"tp_sys_enter_read":  "sys_enter_read",
		"tp_sys_exit_read":   "sys_exit_read",
		"tp_sys_enter_write": "sys_enter_write",
		"tp_sys_exit_write":  "sys_exit_write",
	}

	for progName, tpName := range tracepoints {
		prog, ok := coll.Programs[progName]
		if !ok {
			w.log.Warn("eBPF program '%s' not found, skipping", progName)
			continue
		}

		// Визначаємо group (syscalls)
		group := "syscalls"

		link, err := attachTracepoint(group, tpName, prog)
		if err != nil {
			w.log.Warn("attach %s/%s: %v", group, tpName, err)
			continue
		}

		links = append(links, link)
		w.log.Info("attached tracepoint: %s/%s", group, tpName)
	}

	if len(links) == 0 {
		return nil, fmt.Errorf("no tracepoints attached")
	}

	return links, nil
}

// attachTracepoint аттачить одну eBPF програму до tracepoint через perf_event.
func attachTracepoint(group, name string, prog *ebpf.Program) (closeable, error) {
	// Читаємо tracepoint ID
	idPath := fmt.Sprintf("/sys/kernel/debug/tracing/events/%s/%s/id", group, name)
	data, err := os.ReadFile(idPath)
	if err != nil {
		// Fallback: /sys/kernel/tracing/
		idPath = fmt.Sprintf("/sys/kernel/tracing/events/%s/%s/id", group, name)
		data, err = os.ReadFile(idPath)
		if err != nil {
			return nil, fmt.Errorf("read tracepoint ID: %w", err)
		}
	}

	tpID, err := strconv.Atoi(strings.TrimSpace(string(data)))
	if err != nil {
		return nil, fmt.Errorf("parse tracepoint ID: %w", err)
	}

	return prog.AttachTracepoint(uint64(tpID))
}

// ============================================================================
// PID scanner — знаходить target-інструменти серед запущених процесів
// ============================================================================

// pidScanLoop періодично сканує /proc для пошуку target-інструментів.
func (w *Watcher) pidScanLoop(ctx context.Context) {
	// Перший скан одразу
	w.scanTargetPIDs()

	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.scanTargetPIDs()
		}
	}
}

// scanTargetPIDs сканує /proc і оновлює список target PIDs.
func (w *Watcher) scanTargetPIDs() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return
	}

	currentPIDs := make(map[uint32]string)

	for _, entry := range entries {
		pid, err := strconv.ParseUint(entry.Name(), 10, 32)
		if err != nil {
			continue
		}

		comm := w.readComm(uint32(pid))
		if comm == "" {
			continue
		}

		if w.isTargetTool(comm) {
			currentPIDs[uint32(pid)] = comm
		}
	}

	// Оновлюємо target PIDs та eBPF map
	w.mu.Lock()
	defer w.mu.Unlock()

	// Видаляємо зниклі PIDs
	for pid := range w.targetPIDs {
		if _, exists := currentPIDs[pid]; !exists {
			w.removePID(pid)
		}
	}

	// Додаємо нові PIDs
	for pid, comm := range currentPIDs {
		if _, exists := w.targetPIDs[pid]; !exists {
			w.addPID(pid, comm)
		}
	}
}

// addPID додає PID до target map та eBPF map.
func (w *Watcher) addPID(pid uint32, comm string) {
	w.targetPIDs[pid] = comm

	// Додаємо до eBPF map для kernel-side фільтрації
	if w.pidMap != nil {
		val := uint8(1)
		if err := w.pidMap.Put(pid, val); err != nil {
			w.log.Debug("add PID %d to eBPF map: %v", pid, err)
		}
	}

	w.log.Info("tracking PID %d (%s)", pid, comm)
}

// removePID видаляє PID з target map та eBPF map.
func (w *Watcher) removePID(pid uint32) {
	comm := w.targetPIDs[pid]
	delete(w.targetPIDs, pid)

	if w.pidMap != nil {
		if err := w.pidMap.Delete(pid); err != nil {
			w.log.Debug("remove PID %d from eBPF map: %v", pid, err)
		}
	}

	w.log.Info("stopped tracking PID %d (%s)", pid, comm)
}

// isTargetTool перевіряє чи ім'я процесу є target-інструментом.
func (w *Watcher) isTargetTool(comm string) bool {
	for _, tool := range w.cfg.Interactive.TargetTools {
		if comm == tool {
			return true
		}
		// Перевіряємо також базове ім'я (python3.11 → python3)
		if strings.HasPrefix(comm, tool) {
			return true
		}
	}
	return false
}

// readComm читає /proc/<pid>/comm.
func (w *Watcher) readComm(pid uint32) string {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}

// ============================================================================
// Обробка подій з eBPF ring buffer
// ============================================================================

// processEvent парсить бінарну подію з ring buffer.
func (w *Watcher) processEvent(raw []byte) {
	if len(raw) < int(unsafe.Sizeof(bpfEvent{})) {
		return
	}

	var event bpfEvent
	if err := binary.Read(bytes.NewReader(raw), binary.LittleEndian, &event); err != nil {
		w.log.Debug("parse eBPF event: %v", err)
		return
	}

	// Перевіряємо що PID ще є в target list
	w.mu.RLock()
	comm, tracked := w.targetPIDs[event.PID]
	w.mu.RUnlock()

	if !tracked {
		return
	}

	// Витягуємо дані
	dataLen := int(event.DataLen)
	if dataLen > maxDataLen {
		dataLen = maxDataLen
	}
	data := string(event.Data[:dataLen])

	// Очищуємо від контрольних символів
	data = cleanData(data)
	if data == "" {
		return
	}

	// Визначаємо username по UID
	user := uidToUsername(event.UID)

	switch event.EventType {
	case eventTypeRead:
		// stdin input
		w.correlator.AddInput(event.PID, comm, user, data)
	case eventTypeWrite:
		// stdout/stderr output
		if w.cfg.Interactive.CaptureStdout {
			w.correlator.AddOutput(event.PID, data)
		}
	}
}

// ============================================================================
// Утиліти
// ============================================================================

// cleanData видаляє контрольні символи та trim-ує дані.
func cleanData(data string) string {
	// Видаляємо \r, trim newlines
	data = strings.ReplaceAll(data, "\r", "")
	data = strings.TrimSpace(data)

	// Видаляємо ANSI escape sequences
	result := make([]byte, 0, len(data))
	inEscape := false
	for i := 0; i < len(data); i++ {
		if data[i] == 0x1b { // ESC
			inEscape = true
			continue
		}
		if inEscape {
			if (data[i] >= 'a' && data[i] <= 'z') || (data[i] >= 'A' && data[i] <= 'Z') {
				inEscape = false
			}
			continue
		}
		// Пропускаємо null та інші непечатні (крім newline, tab)
		if data[i] == 0 {
			continue
		}
		if data[i] < 32 && data[i] != '\n' && data[i] != '\t' {
			continue
		}
		result = append(result, data[i])
	}

	return strings.TrimSpace(string(result))
}

// uidToUsername конвертує UID у username.
func uidToUsername(uid uint32) string {
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return fmt.Sprintf("uid:%d", uid)
	}
	target := fmt.Sprintf(":%d:", uid)
	for _, line := range strings.Split(string(data), "\n") {
		if strings.Contains(line, target) {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) > 0 {
				return parts[0]
			}
		}
	}
	return fmt.Sprintf("uid:%d", uid)
}
