package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"os"
	"strconv"
	"strings"
	"sync"
	"time"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// ============================================================================
// Константи — мають відповідати interactive.c
// ============================================================================

const (
	maxDataLen = 4096

	eventTypeRead  = 1 // stdin (fd=0)
	eventTypeWrite = 2 // stdout/stderr (fd=1,2)
)

// bpfEvent — структура події з eBPF ring buffer.
// ВАЖЛИВО: повинна бути ідентична struct event_t у interactive.c
type bpfEvent struct {
	PID       uint32
	UID       uint32
	FD        uint32
	EventType uint32
	DataLen   uint32
	Comm      [16]byte
	Data      [maxDataLen]byte
}

// Watcher перехоплює stdin/stdout інтерактивних інструментів через eBPF.
type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger

	mu         sync.RWMutex
	targetPIDs map[uint32]string // pid → process name

	pidMap *ebpf.Map

	correlator *Correlator
}

// NewWatcher створює новий interactive-watcher.
func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{
		cfg:        cfg,
		writer:     writer,
		log:        log,
		targetPIDs: make(map[uint32]string),
		correlator: NewCorrelator(cfg, writer, log),
	}
}

// ============================================================================
// Run — основний цикл
// ============================================================================

// Run завантажує eBPF програму, сканує target PIDs та обробляє події.
func (w *Watcher) Run(ctx context.Context) error {
	spec, err := ebpf.LoadCollectionSpec(w.cfg.Interactive.EBPFObjectPath)
	if err != nil {
		return fmt.Errorf("load eBPF spec %s: %w", w.cfg.Interactive.EBPFObjectPath, err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}
	defer coll.Close()

	eventsMap, ok := coll.Maps["events"]
	if !ok {
		return fmt.Errorf("eBPF map 'events' not found")
	}

	pidMap, ok := coll.Maps["target_pids"]
	if !ok {
		return fmt.Errorf("eBPF map 'target_pids' not found")
	}
	w.pidMap = pidMap

	// Attach tracepoints через cilium/ebpf/link API
	links, err := w.attachTracepoints(coll)
	if err != nil {
		return fmt.Errorf("attach tracepoints: %w", err)
	}
	for _, l := range links {
		defer l.Close()
	}

	reader, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ring buffer reader: %w", err)
	}
	defer reader.Close()

	go w.pidScanLoop(ctx)
	go w.correlator.FlushLoop(ctx)

	w.log.Info("eBPF loaded, reading events...")

	go func() {
		<-ctx.Done()
		reader.Close()
	}()

	for {
		record, err := reader.Read()
		if err != nil {
			if errors.Is(err, ringbuf.ErrClosed) {
				return nil
			}
			w.log.Error("read ring buffer: %v", err)
			continue
		}
		w.processEvent(record.RawSample)
	}
}

// ============================================================================
// eBPF tracepoint attachment — ВИПРАВЛЕНИЙ API
// ============================================================================

// attachTracepoints аттачить eBPF програми через link.Tracepoint().
// Це правильний API для cilium/ebpf (не prog.AttachTracepoint).
func (w *Watcher) attachTracepoints(coll *ebpf.Collection) ([]link.Link, error) {
	type tpDef struct {
		progName string
		group    string
		name     string
	}

	defs := []tpDef{
		{"tp_sys_enter_read", "syscalls", "sys_enter_read"},
		{"tp_sys_exit_read", "syscalls", "sys_exit_read"},
		{"tp_sys_enter_write", "syscalls", "sys_enter_write"},
		{"tp_sys_exit_write", "syscalls", "sys_exit_write"},
	}

	var links []link.Link

	for _, d := range defs {
		prog, ok := coll.Programs[d.progName]
		if !ok {
			w.log.Warn("eBPF program '%s' not found, skipping", d.progName)
			continue
		}

		l, err := link.Tracepoint(d.group, d.name, prog, nil)
		if err != nil {
			w.log.Warn("attach %s/%s: %v", d.group, d.name, err)
			continue
		}

		links = append(links, l)
		w.log.Info("attached tracepoint: %s/%s", d.group, d.name)
	}

	if len(links) == 0 {
		return nil, fmt.Errorf("no tracepoints attached")
	}

	return links, nil
}

// ============================================================================
// PID scanner
// ============================================================================

func (w *Watcher) pidScanLoop(ctx context.Context) {
	w.scanTargetPIDs()
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			w.scanTargetPIDs()
		}
	}
}

func (w *Watcher) scanTargetPIDs() {
	entries, err := os.ReadDir("/proc")
	if err != nil {
		return
	}

	currentPIDs := make(map[uint32]string)
	for _, entry := range entries {
		pid, err := strconv.ParseUint(entry.Name(), 10, 32)
		if err != nil {
			continue
		}
		comm := w.readComm(uint32(pid))
		if comm == "" {
			continue
		}
		if w.isTargetTool(comm) {
			currentPIDs[uint32(pid)] = comm
		}
	}

	w.mu.Lock()
	defer w.mu.Unlock()

	for pid := range w.targetPIDs {
		if _, exists := currentPIDs[pid]; !exists {
			w.removePID(pid)
		}
	}
	for pid, comm := range currentPIDs {
		if _, exists := w.targetPIDs[pid]; !exists {
			w.addPID(pid, comm)
		}
	}
}

func (w *Watcher) addPID(pid uint32, comm string) {
	w.targetPIDs[pid] = comm
	if w.pidMap != nil {
		val := uint8(1)
		_ = w.pidMap.Put(pid, val)
	}
	w.log.Info("tracking PID %d (%s)", pid, comm)
}

func (w *Watcher) removePID(pid uint32) {
	comm := w.targetPIDs[pid]
	delete(w.targetPIDs, pid)
	if w.pidMap != nil {
		_ = w.pidMap.Delete(pid)
	}
	w.log.Info("stopped tracking PID %d (%s)", pid, comm)
}

func (w *Watcher) isTargetTool(comm string) bool {
	for _, tool := range w.cfg.Interactive.TargetTools {
		if comm == tool || strings.HasPrefix(comm, tool) {
			return true
		}
	}
	return false
}

func (w *Watcher) readComm(pid uint32) string {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(data))
}

// ============================================================================
// Обробка подій з ring buffer
// ============================================================================

func (w *Watcher) processEvent(raw []byte) {
	if len(raw) < int(unsafe.Sizeof(bpfEvent{})) {
		return
	}

	var event bpfEvent
	if err := binary.Read(bytes.NewReader(raw), binary.LittleEndian, &event); err != nil {
		w.log.Debug("parse eBPF event: %v", err)
		return
	}

	w.mu.RLock()
	comm, tracked := w.targetPIDs[event.PID]
	w.mu.RUnlock()
	if !tracked {
		return
	}

	dataLen := int(event.DataLen)
	if dataLen > maxDataLen {
		dataLen = maxDataLen
	}
	data := cleanData(string(event.Data[:dataLen]))
	if data == "" {
		return
	}

	user := uidToUsername(event.UID)

	switch event.EventType {
	case eventTypeRead:
		w.correlator.AddInput(event.PID, comm, user, data)
	case eventTypeWrite:
		if w.cfg.Interactive.CaptureStdout {
			w.correlator.AddOutput(event.PID, data)
		}
	}
}

// ============================================================================
// Утиліти
// ============================================================================

func cleanData(data string) string {
	data = strings.ReplaceAll(data, "\r", "")
	data = strings.TrimSpace(data)

	result := make([]byte, 0, len(data))
	inEscape := false
	for i := 0; i < len(data); i++ {
		if data[i] == 0x1b {
			inEscape = true
			continue
		}
		if inEscape {
			if (data[i] >= 'a' && data[i] <= 'z') || (data[i] >= 'A' && data[i] <= 'Z') {
				inEscape = false
			}
			continue
		}
		if data[i] == 0 {
			continue
		}
		if data[i] < 32 && data[i] != '\n' && data[i] != '\t' {
			continue
		}
		result = append(result, data[i])
	}
	return strings.TrimSpace(string(result))
}

func uidToUsername(uid uint32) string {
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return fmt.Sprintf("uid:%d", uid)
	}
	target := fmt.Sprintf(":%d:", uid)
	for _, line := range strings.Split(string(data), "\n") {
		if strings.Contains(line, target) {
			parts := strings.SplitN(line, ":", 2)
			if len(parts) > 0 {
				return parts[0]
			}
		}
	}
	return fmt.Sprintf("uid:%d", uid)
}
