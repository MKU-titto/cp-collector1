module github.com/cyber-polygon/cp-collector/watchers/syscall-monitor

go 1.22.5

toolchain go1.22.5

require (
	github.com/cyber-polygon/cp-collector/shared v0.0.0
	github.com/cilium/ebpf v0.15.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	golang.org/x/exp v0.0.0-20240506185415-9bf2ced13842 // indirect
	golang.org/x/sys v0.20.0 // indirect
)

replace github.com/cyber-polygon/cp-collector/shared => ../../shared
