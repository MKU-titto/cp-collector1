package main

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"unsafe"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
	"github.com/cilium/ebpf/ringbuf"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
	"github.com/cyber-polygon/cp-collector/shared/storage"
	"github.com/cyber-polygon/cp-collector/shared/types"
)

// ============================================================================
// Константи — мають відповідати syscall.c
// ============================================================================

const (
	maxArgLen = 256

	scConnect = 1
	scExecve  = 2
	scPtrace  = 3
	scMmap    = 4
	scOpenat  = 5
	scRename  = 6
	scUnlink  = 7
)

// bpfSyscallEvent — відповідає struct syscall_event_t у syscall.c
type bpfSyscallEvent struct {
	PID         uint32
	PPID        uint32 // 0 з eBPF, визначаємо через /proc
	UID         uint32
	SyscallType uint32
	ReturnCode  int32
	Arg1        uint64
	Arg2        uint64
	Comm        [16]byte
	ArgStr      [maxArgLen]byte
}

type Watcher struct {
	cfg    *config.Config
	writer *storage.Writer
	log    *logger.Logger
}

func NewWatcher(cfg *config.Config, writer *storage.Writer, log *logger.Logger) *Watcher {
	return &Watcher{cfg: cfg, writer: writer, log: log}
}

// ============================================================================
// Run
// ============================================================================

func (w *Watcher) Run(ctx context.Context) error {
	spec, err := ebpf.LoadCollectionSpec(w.cfg.Syscall.EBPFObjectPath)
	if err != nil {
		return fmt.Errorf("load eBPF spec %s: %w", w.cfg.Syscall.EBPFObjectPath, err)
	}

	coll, err := ebpf.NewCollection(spec)
	if err != nil {
		return fmt.Errorf("create eBPF collection: %w", err)
	}
	defer coll.Close()

	eventsMap, ok := coll.Maps["sc_events"]
	if !ok {
		return fmt.Errorf("eBPF map 'sc_events' not found")
	}

	links, err := w.attachTracepoints(coll)
	if err != nil {
		return fmt.Errorf("attach tracepoints: %w", err)
	}
	for _, l := range links {
		defer l.Close()
	}

	reader, err := ringbuf.NewReader(eventsMap)
	if err != nil {
		return fmt.Errorf("create ring buffer reader: %w", err)
	}
	defer reader.Close()

	w.log.Info("eBPF loaded, reading syscall events...")

	go func() {
		<-ctx.Done()
		reader.Close()
	}()

	for {
		record, err := reader.Read()
		if err != nil {
			if errors.Is(err, ringbuf.ErrClosed) {
				return nil
			}
			w.log.Error("read ring buffer: %v", err)
			continue
		}
		w.processEvent(record.RawSample)
	}
}

// ============================================================================
// Tracepoint attachment — ВИПРАВЛЕНИЙ API (link.Tracepoint)
// ============================================================================

func (w *Watcher) attachTracepoints(coll *ebpf.Collection) ([]link.Link, error) {
	type tpDef struct {
		progName string
		group    string
		name     string
	}

	defs := []tpDef{
		{"tp_connect", "syscalls", "sys_enter_connect"},
		{"tp_connect_exit", "syscalls", "sys_exit_connect"},
		{"tp_execve", "syscalls", "sys_enter_execve"},
		{"tp_execve_exit", "syscalls", "sys_exit_execve"},
		{"tp_ptrace", "syscalls", "sys_enter_ptrace"},
		{"tp_mmap", "syscalls", "sys_enter_mmap"},
		{"tp_openat", "syscalls", "sys_enter_openat"},
		{"tp_rename", "syscalls", "sys_enter_renameat2"},
		{"tp_unlink", "syscalls", "sys_enter_unlinkat"},
	}

	var links []link.Link

	for _, d := range defs {
		prog, ok := coll.Programs[d.progName]
		if !ok {
			w.log.Debug("eBPF program '%s' not found, skipping", d.progName)
			continue
		}

		l, err := link.Tracepoint(d.group, d.name, prog, nil)
		if err != nil {
			w.log.Warn("attach %s/%s: %v", d.group, d.name, err)
			continue
		}

		links = append(links, l)
		w.log.Info("attached: %s/%s", d.group, d.name)
	}

	if len(links) == 0 {
		return nil, fmt.Errorf("no tracepoints attached")
	}

	return links, nil
}

// ============================================================================
// Обробка подій
// ============================================================================

func (w *Watcher) processEvent(raw []byte) {
	if len(raw) < int(unsafe.Sizeof(bpfSyscallEvent{})) {
		return
	}

	var event bpfSyscallEvent
	if err := binary.Read(bytes.NewReader(raw), binary.LittleEndian, &event); err != nil {
		w.log.Debug("parse eBPF event: %v", err)
		return
	}

	comm := nullTermStr(event.Comm[:])
	if strings.HasPrefix(comm, "cp-") {
		return
	}
	if event.UID == ironUID() {
		return
	}

	// PPID = 0 з eBPF, визначаємо через /proc
	ppid := readPPID(int(event.PID))

	syscallName := w.syscallTypeName(event.SyscallType)
	args := w.formatArgs(event)

	scEvent := types.SyscallEvent{
		BaseEvent:   types.NewBaseEvent("syscall_event", w.cfg.Agent.MachineID, w.cfg.Agent.CTFEventID),
		SyscallName: syscallName,
		PID:         int(event.PID),
		PPID:        ppid,
		Comm:        comm,
		UID:         event.UID,
		ReturnCode:  int(event.ReturnCode),
		Args:        args,
	}

	if err := w.writer.Write(scEvent); err != nil {
		w.log.Error("write syscall event: %v", err)
		return
	}

	switch event.SyscallType {
	case scPtrace:
		w.log.Warn("syscall: %s pid=%d comm=%s args=%s", syscallName, event.PID, comm, args)
	case scExecve:
		w.log.Info("syscall: %s pid=%d comm=%s args=%s", syscallName, event.PID, comm, args)
	}
}

// ============================================================================
// PPID через /proc (надійніше ніж BPF_CORE_READ task_struct)
// ============================================================================

func readPPID(pid int) int {
	data, err := os.ReadFile(fmt.Sprintf("/proc/%d/status", pid))
	if err != nil {
		return 0
	}
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "PPid:") {
			fields := strings.Fields(line)
			if len(fields) >= 2 {
				ppid, _ := strconv.Atoi(fields[1])
				return ppid
			}
		}
	}
	return 0
}

// ============================================================================
// Форматування
// ============================================================================

func (w *Watcher) syscallTypeName(scType uint32) string {
	switch scType {
	case scConnect:
		return "connect"
	case scExecve:
		return "execve"
	case scPtrace:
		return "ptrace"
	case scMmap:
		return "mmap"
	case scOpenat:
		return "openat"
	case scRename:
		return "rename"
	case scUnlink:
		return "unlink"
	default:
		return fmt.Sprintf("syscall_%d", scType)
	}
}

func (w *Watcher) formatArgs(event bpfSyscallEvent) string {
	argStr := nullTermStr(event.ArgStr[:])

	switch event.SyscallType {
	case scConnect:
		family := event.Arg1
		port := event.Arg2
		if family == 2 {
			ip := formatIPv4(argStr)
			return fmt.Sprintf("AF_INET %s:%d", ip, port)
		} else if family == 10 {
			return fmt.Sprintf("AF_INET6 [%s]:%d", argStr, port)
		}
		return fmt.Sprintf("family=%d port=%d", family, port)
	case scExecve:
		return argStr
	case scPtrace:
		reqName := ptraceRequestName(event.Arg1)
		return fmt.Sprintf("request=%s target_pid=%d", reqName, event.Arg2)
	case scMmap:
		protStr := mmapProtStr(event.Arg1)
		return fmt.Sprintf("prot=%s flags=0x%x", protStr, event.Arg2)
	case scOpenat:
		return fmt.Sprintf("path=%s flags=0x%x", argStr, event.Arg1)
	case scRename:
		return fmt.Sprintf("old=%s", argStr)
	case scUnlink:
		return fmt.Sprintf("path=%s", argStr)
	default:
		return argStr
	}
}

func formatIPv4(raw string) string {
	if len(raw) >= 4 {
		ip := net.IPv4(raw[0], raw[1], raw[2], raw[3])
		return ip.String()
	}
	return raw
}

func ptraceRequestName(req uint64) string {
	switch req {
	case 0:
		return "PTRACE_TRACEME"
	case 16:
		return "PTRACE_ATTACH"
	case 17:
		return "PTRACE_DETACH"
	case 24:
		return "PTRACE_SYSCALL"
	case 31:
		return "PTRACE_SEIZE"
	default:
		return fmt.Sprintf("0x%x", req)
	}
}

func mmapProtStr(prot uint64) string {
	var parts []string
	if prot&0x1 != 0 {
		parts = append(parts, "PROT_READ")
	}
	if prot&0x2 != 0 {
		parts = append(parts, "PROT_WRITE")
	}
	if prot&0x4 != 0 {
		parts = append(parts, "PROT_EXEC")
	}
	if len(parts) == 0 {
		return "PROT_NONE"
	}
	return strings.Join(parts, "|")
}

func nullTermStr(b []byte) string {
	idx := bytes.IndexByte(b, 0)
	if idx >= 0 {
		return string(b[:idx])
	}
	return string(b)
}

var _ironUID uint32 = 0xFFFFFFFF

func ironUID() uint32 {
	if _ironUID != 0xFFFFFFFF {
		return _ironUID
	}
	data, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return 0xFFFFFFFF
	}
	for _, line := range strings.Split(string(data), "\n") {
		if strings.HasPrefix(line, "iron:") {
			parts := strings.Split(line, ":")
			if len(parts) >= 3 {
				uid, err := strconv.ParseUint(parts[2], 10, 32)
				if err == nil {
					_ironUID = uint32(uid)
					return _ironUID
				}
			}
		}
	}
	return 0xFFFFFFFF
}
