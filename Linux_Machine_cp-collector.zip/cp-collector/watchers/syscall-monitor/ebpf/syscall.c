// syscall.c — eBPF програма для моніторингу критичних системних викликів.
//
// Перехоплює:
//   - connect    (мережеві з'єднання)
//   - execve     (запуск програм)
//   - ptrace     (дебаг/інжекція)
//   - mmap       (map з PROT_EXEC — shellcode)
//   - openat     (відкриття чутливих файлів)
//   - renameat2  (перейменування файлів)
//   - unlinkat   (видалення файлів)
//
// Компіляція:
//   clang -O2 -g -target bpf -D__TARGET_ARCH_x86 \
//     -I/usr/include/bpf -c syscall.c -o syscall.o

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>
#include <bpf/bpf_core_read.h>

#define MAX_ARG_LEN 256

// Типи подій — мають відповідати Go-стороні
#define SC_CONNECT 1
#define SC_EXECVE  2
#define SC_PTRACE  3
#define SC_MMAP    4
#define SC_OPENAT  5
#define SC_RENAME  6
#define SC_UNLINK  7

// Структура події для ring buffer
struct syscall_event_t {
    __u32 pid;
    __u32 ppid;
    __u32 uid;
    __u32 syscall_type;
    __s32 return_code;
    __u64 arg1;
    __u64 arg2;
    char  comm[16];
    char  arg_str[MAX_ARG_LEN];
};

// Тимчасове зберігання між enter/exit
struct pending_t {
    __u32 syscall_type;
    __u64 arg1;
    __u64 arg2;
    char  arg_str[MAX_ARG_LEN];
};

// --------------------------------------------------------------------------
// BPF Maps
// --------------------------------------------------------------------------

// Ring buffer для передачі подій у userspace
struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 24); // 16 MB
} sc_events SEC(".maps");

// Per-task зберігання між enter та exit
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 8192);
    __type(key, __u64);
    __type(value, struct pending_t);
} pending SEC(".maps");

// --------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------

static __always_inline __u64 pid_tgid(void) {
    return bpf_get_current_pid_tgid();
}

static __always_inline __u32 get_pid(void) {
    return pid_tgid() >> 32;
}

static __always_inline __u32 get_ppid(void) {
    struct task_struct *task = (void *)bpf_get_current_task();
    __u32 ppid = 0;
    bpf_probe_read_kernel(&ppid, sizeof(ppid),
        &task->real_parent->tgid);
    return ppid;
}

// Відправляє подію в ring buffer (для syscalls без exit — execve enter, ptrace, etc.)
static __always_inline void emit_event(
    __u32 syscall_type, __u64 arg1, __u64 arg2,
    const char *arg_str, __u32 arg_str_len, __s32 ret)
{
    struct syscall_event_t *event = bpf_ringbuf_reserve(&sc_events,
        sizeof(struct syscall_event_t), 0);
    if (!event)
        return;

    event->pid = get_pid();
    event->ppid = get_ppid();
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->syscall_type = syscall_type;
    event->return_code = ret;
    event->arg1 = arg1;
    event->arg2 = arg2;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));

    if (arg_str && arg_str_len > 0) {
        __u32 len = arg_str_len;
        if (len > MAX_ARG_LEN)
            len = MAX_ARG_LEN;
        bpf_probe_read_user(event->arg_str, len & (MAX_ARG_LEN - 1), arg_str);
    }

    bpf_ringbuf_submit(event, 0);
}

// --------------------------------------------------------------------------
// connect — sys_enter_connect / sys_exit_connect
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_connect")
int tp_connect(struct trace_event_raw_sys_enter *ctx) {
    // args: fd, sockaddr*, addrlen
    __u64 sockaddr_ptr = ctx->args[1];
    if (!sockaddr_ptr)
        return 0;

    // Читаємо перші 2 байти — sa_family
    __u16 family = 0;
    bpf_probe_read_user(&family, sizeof(family), (void *)sockaddr_ptr);

    // Тільки AF_INET (2) та AF_INET6 (10)
    if (family != 2 && family != 10)
        return 0;

    struct pending_t p = {};
    p.syscall_type = SC_CONNECT;
    p.arg1 = family;

    if (family == 2) {
        // struct sockaddr_in: family(2) + port(2) + addr(4)
        __u16 port = 0;
        bpf_probe_read_user(&port, sizeof(port), (void *)(sockaddr_ptr + 2));
        p.arg2 = __builtin_bswap16(port); // network byte order → host

        // IP address (4 bytes)
        bpf_probe_read_user(p.arg_str, 4, (void *)(sockaddr_ptr + 4));
    } else if (family == 10) {
        // struct sockaddr_in6: family(2) + port(2) + flow(4) + addr(16)
        __u16 port = 0;
        bpf_probe_read_user(&port, sizeof(port), (void *)(sockaddr_ptr + 2));
        p.arg2 = __builtin_bswap16(port);

        bpf_probe_read_user(p.arg_str, 16, (void *)(sockaddr_ptr + 8));
    }

    __u64 key = pid_tgid();
    bpf_map_update_elem(&pending, &key, &p, BPF_ANY);

    return 0;
}

SEC("tracepoint/syscalls/sys_exit_connect")
int tp_connect_exit(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = pid_tgid();
    struct pending_t *p = bpf_map_lookup_elem(&pending, &key);
    if (!p)
        return 0;

    // Пропускаємо localhost з'єднання (127.0.0.1)
    if (p->arg1 == 2) {
        unsigned char *ip = (unsigned char *)p->arg_str;
        if (ip[0] == 127)
            goto cleanup;
    }

    // Пропускаємо порт 0 (bind, не connect)
    if (p->arg2 == 0)
        goto cleanup;

    emit_event(SC_CONNECT, p->arg1, p->arg2,
        p->arg_str, (p->arg1 == 2) ? 4 : 16, (__s32)ctx->ret);

cleanup:
    bpf_map_delete_elem(&pending, &key);
    return 0;
}

// --------------------------------------------------------------------------
// execve — sys_enter_execve / sys_exit_execve
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_execve")
int tp_execve(struct trace_event_raw_sys_enter *ctx) {
    // args: filename, argv, envp
    const char *filename = (const char *)ctx->args[0];
    if (!filename)
        return 0;

    struct pending_t p = {};
    p.syscall_type = SC_EXECVE;
    bpf_probe_read_user_str(p.arg_str, MAX_ARG_LEN, filename);

    __u64 key = pid_tgid();
    bpf_map_update_elem(&pending, &key, &p, BPF_ANY);

    return 0;
}

SEC("tracepoint/syscalls/sys_exit_execve")
int tp_execve_exit(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = pid_tgid();
    struct pending_t *p = bpf_map_lookup_elem(&pending, &key);
    if (!p)
        return 0;

    emit_event(SC_EXECVE, 0, 0, p->arg_str, MAX_ARG_LEN, (__s32)ctx->ret);

    bpf_map_delete_elem(&pending, &key);
    return 0;
}

// --------------------------------------------------------------------------
// ptrace — sys_enter_ptrace (без exit, записуємо одразу)
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_ptrace")
int tp_ptrace(struct trace_event_raw_sys_enter *ctx) {
    // args: request, pid, addr, data
    __u64 request = ctx->args[0];
    __u64 target_pid = ctx->args[1];

    emit_event(SC_PTRACE, request, target_pid, NULL, 0, 0);
    return 0;
}

// --------------------------------------------------------------------------
// mmap — sys_enter_mmap (фільтруємо PROT_EXEC)
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_mmap")
int tp_mmap(struct trace_event_raw_sys_enter *ctx) {
    // args: addr, len, prot, flags, fd, offset
    __u64 prot = ctx->args[2];
    __u64 flags = ctx->args[3];

    // Тільки якщо є PROT_EXEC (0x4)
    if (!(prot & 0x4))
        return 0;

    // Ігноруємо MAP_ANONYMOUS без PROT_WRITE (стандартне завантаження .so)
    // Записуємо тільки PROT_WRITE|PROT_EXEC (shellcode) або file-backed EXEC
    if ((flags & 0x20) && !(prot & 0x2)) // MAP_ANONYMOUS && !PROT_WRITE
        return 0;

    emit_event(SC_MMAP, prot, flags, NULL, 0, 0);
    return 0;
}

// --------------------------------------------------------------------------
// openat — sys_enter_openat (фільтруємо чутливі файли)
// --------------------------------------------------------------------------

// Чутливі шляхи перевіряються на Go-стороні для гнучкості.
// eBPF записує всі openat для цікавих директорій.
SEC("tracepoint/syscalls/sys_enter_openat")
int tp_openat(struct trace_event_raw_sys_enter *ctx) {
    // args: dfd, filename, flags, mode
    const char *filename = (const char *)ctx->args[1];
    __u64 flags = ctx->args[2];
    if (!filename)
        return 0;

    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, filename);

    // Фільтруємо: тільки чутливі шляхи
    // /etc/shadow, /etc/passwd, /etc/sudoers, /root/
    // Проста перевірка першого символа
    if (path[0] != '/')
        return 0;

    // /etc/s (shadow, sudoers), /etc/p (passwd), /root
    int interesting = 0;
    if (path[1] == 'e' && path[2] == 't' && path[3] == 'c' && path[4] == '/') {
        // /etc/shadow, /etc/passwd, /etc/sudoers, /etc/ssh
        if (path[5] == 's' || path[5] == 'p') // shadow, sudoers, ssh, passwd
            interesting = 1;
    }
    if (path[1] == 'r' && path[2] == 'o' && path[3] == 'o' && path[4] == 't')
        interesting = 1; // /root/...
    if (path[1] == 'p' && path[2] == 'r' && path[3] == 'o' && path[4] == 'c')
        return 0; // /proc — занадто шумно, пропускаємо

    if (!interesting)
        return 0;

    emit_event(SC_OPENAT, flags, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

// --------------------------------------------------------------------------
// renameat2 — перейменування файлів
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_renameat2")
int tp_rename(struct trace_event_raw_sys_enter *ctx) {
    // args: olddfd, oldname, newdfd, newname, flags
    const char *oldname = (const char *)ctx->args[1];
    if (!oldname)
        return 0;

    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, oldname);

    emit_event(SC_RENAME, 0, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

// --------------------------------------------------------------------------
// unlinkat — видалення файлів
// --------------------------------------------------------------------------

SEC("tracepoint/syscalls/sys_enter_unlinkat")
int tp_unlink(struct trace_event_raw_sys_enter *ctx) {
    // args: dfd, pathname, flag
    const char *pathname = (const char *)ctx->args[1];
    if (!pathname)
        return 0;

    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, pathname);

    emit_event(SC_UNLINK, 0, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

char _license[] SEC("license") = "GPL";
