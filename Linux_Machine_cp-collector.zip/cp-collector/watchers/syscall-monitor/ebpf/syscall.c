// syscall.c — eBPF програма для моніторингу критичних системних викликів.
//
// Компіляція:
//   clang -O2 -g -target bpf -D__TARGET_ARCH_x86 \
//     -I/usr/include/bpf -I/usr/include \
//     -c syscall.c -o syscall.o

#include <linux/bpf.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

// ============================================================================
// Ручні визначення kernel struct
// ============================================================================

struct trace_event_raw_sys_enter {
    unsigned short common_type;
    unsigned char  common_flags;
    unsigned char  common_preempt_count;
    int            common_pid;
    long           id;
    unsigned long  args[6];
};

struct trace_event_raw_sys_exit {
    unsigned short common_type;
    unsigned char  common_flags;
    unsigned char  common_preempt_count;
    int            common_pid;
    long           id;
    long           ret;
};

// ============================================================================
// Константи та структури
// ============================================================================

#define MAX_ARG_LEN 256

#define SC_CONNECT 1
#define SC_EXECVE  2
#define SC_PTRACE  3
#define SC_MMAP    4
#define SC_OPENAT  5
#define SC_RENAME  6
#define SC_UNLINK  7

struct syscall_event_t {
    __u32 pid;
    __u32 ppid;
    __u32 uid;
    __u32 syscall_type;
    __s32 return_code;
    __u64 arg1;
    __u64 arg2;
    char  comm[16];
    char  arg_str[MAX_ARG_LEN];
};

struct pending_t {
    __u32 syscall_type;
    __u64 arg1;
    __u64 arg2;
    char  arg_str[MAX_ARG_LEN];
};

// ============================================================================
// BPF Maps
// ============================================================================

struct {
    __uint(type, BPF_MAP_TYPE_RINGBUF);
    __uint(max_entries, 1 << 24);
} sc_events SEC(".maps");

struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __uint(max_entries, 8192);
    __type(key, __u64);
    __type(value, struct pending_t);
} pending SEC(".maps");

// ============================================================================
// Helpers
// ============================================================================

static __always_inline __u64 pid_tgid(void) {
    return bpf_get_current_pid_tgid();
}

static __always_inline __u32 get_pid(void) {
    return pid_tgid() >> 32;
}

// PPID через bpf_get_current_task + bpf_probe_read_kernel
// Offset для task_struct->real_parent->tgid залежить від ядра.
// Безпечніше повертати 0 і визначати PPID на Go-стороні через /proc.
static __always_inline __u32 get_ppid(void) {
    return 0; // PPID визначається на Go-стороні через /proc/<pid>/status
}

static __always_inline void emit_event(
    __u32 syscall_type, __u64 arg1, __u64 arg2,
    const char *arg_str, __u32 arg_str_len, __s32 ret)
{
    struct syscall_event_t *event = bpf_ringbuf_reserve(&sc_events,
        sizeof(struct syscall_event_t), 0);
    if (!event)
        return;

    event->pid = get_pid();
    event->ppid = get_ppid();
    event->uid = bpf_get_current_uid_gid() & 0xFFFFFFFF;
    event->syscall_type = syscall_type;
    event->return_code = ret;
    event->arg1 = arg1;
    event->arg2 = arg2;
    bpf_get_current_comm(&event->comm, sizeof(event->comm));

    if (arg_str && arg_str_len > 0) {
        __u32 len = arg_str_len & (MAX_ARG_LEN - 1);
        if (len == 0) len = 1;
        bpf_probe_read_user(event->arg_str, len, arg_str);
    }

    bpf_ringbuf_submit(event, 0);
}

// ============================================================================
// connect
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_connect")
int tp_connect(struct trace_event_raw_sys_enter *ctx) {
    __u64 sockaddr_ptr = ctx->args[1];
    if (!sockaddr_ptr)
        return 0;
    __u16 family = 0;
    bpf_probe_read_user(&family, sizeof(family), (void *)sockaddr_ptr);
    if (family != 2 && family != 10)
        return 0;

    struct pending_t p = {};
    p.syscall_type = SC_CONNECT;
    p.arg1 = family;
    if (family == 2) {
        __u16 port = 0;
        bpf_probe_read_user(&port, sizeof(port), (void *)(sockaddr_ptr + 2));
        p.arg2 = __builtin_bswap16(port);
        bpf_probe_read_user(p.arg_str, 4, (void *)(sockaddr_ptr + 4));
    } else if (family == 10) {
        __u16 port = 0;
        bpf_probe_read_user(&port, sizeof(port), (void *)(sockaddr_ptr + 2));
        p.arg2 = __builtin_bswap16(port);
        bpf_probe_read_user(p.arg_str, 16, (void *)(sockaddr_ptr + 8));
    }
    __u64 key = pid_tgid();
    bpf_map_update_elem(&pending, &key, &p, BPF_ANY);
    return 0;
}

SEC("tracepoint/syscalls/sys_exit_connect")
int tp_connect_exit(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = pid_tgid();
    struct pending_t *p = bpf_map_lookup_elem(&pending, &key);
    if (!p)
        return 0;
    if (p->arg1 == 2) {
        unsigned char *ip = (unsigned char *)p->arg_str;
        if (ip[0] == 127)
            goto cleanup;
    }
    if (p->arg2 == 0)
        goto cleanup;
    emit_event(SC_CONNECT, p->arg1, p->arg2,
        p->arg_str, (p->arg1 == 2) ? 4 : 16, (__s32)ctx->ret);
cleanup:
    bpf_map_delete_elem(&pending, &key);
    return 0;
}

// ============================================================================
// execve
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_execve")
int tp_execve(struct trace_event_raw_sys_enter *ctx) {
    const char *filename = (const char *)ctx->args[0];
    if (!filename)
        return 0;
    struct pending_t p = {};
    p.syscall_type = SC_EXECVE;
    bpf_probe_read_user_str(p.arg_str, MAX_ARG_LEN, filename);
    __u64 key = pid_tgid();
    bpf_map_update_elem(&pending, &key, &p, BPF_ANY);
    return 0;
}

SEC("tracepoint/syscalls/sys_exit_execve")
int tp_execve_exit(struct trace_event_raw_sys_exit *ctx) {
    __u64 key = pid_tgid();
    struct pending_t *p = bpf_map_lookup_elem(&pending, &key);
    if (!p)
        return 0;
    emit_event(SC_EXECVE, 0, 0, p->arg_str, MAX_ARG_LEN, (__s32)ctx->ret);
    bpf_map_delete_elem(&pending, &key);
    return 0;
}

// ============================================================================
// ptrace
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_ptrace")
int tp_ptrace(struct trace_event_raw_sys_enter *ctx) {
    __u64 request = ctx->args[0];
    __u64 target_pid = ctx->args[1];
    emit_event(SC_PTRACE, request, target_pid, NULL, 0, 0);
    return 0;
}

// ============================================================================
// mmap (тільки PROT_EXEC + PROT_WRITE — shellcode)
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_mmap")
int tp_mmap(struct trace_event_raw_sys_enter *ctx) {
    __u64 prot = ctx->args[2];
    __u64 flags = ctx->args[3];
    if (!(prot & 0x4))
        return 0;
    if ((flags & 0x20) && !(prot & 0x2))
        return 0;
    emit_event(SC_MMAP, prot, flags, NULL, 0, 0);
    return 0;
}

// ============================================================================
// openat (тільки чутливі шляхи)
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_openat")
int tp_openat(struct trace_event_raw_sys_enter *ctx) {
    const char *filename = (const char *)ctx->args[1];
    __u64 flags = ctx->args[2];
    if (!filename)
        return 0;
    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, filename);
    if (path[0] != '/')
        return 0;
    int interesting = 0;
    if (path[1] == 'e' && path[2] == 't' && path[3] == 'c' && path[4] == '/') {
        if (path[5] == 's' || path[5] == 'p')
            interesting = 1;
    }
    if (path[1] == 'r' && path[2] == 'o' && path[3] == 'o' && path[4] == 't')
        interesting = 1;
    if (path[1] == 'p' && path[2] == 'r' && path[3] == 'o' && path[4] == 'c')
        return 0;
    if (!interesting)
        return 0;
    emit_event(SC_OPENAT, flags, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

// ============================================================================
// renameat2 / unlinkat
// ============================================================================

SEC("tracepoint/syscalls/sys_enter_renameat2")
int tp_rename(struct trace_event_raw_sys_enter *ctx) {
    const char *oldname = (const char *)ctx->args[1];
    if (!oldname)
        return 0;
    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, oldname);
    emit_event(SC_RENAME, 0, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

SEC("tracepoint/syscalls/sys_enter_unlinkat")
int tp_unlink(struct trace_event_raw_sys_enter *ctx) {
    const char *pathname = (const char *)ctx->args[1];
    if (!pathname)
        return 0;
    char path[MAX_ARG_LEN] = {};
    bpf_probe_read_user_str(path, MAX_ARG_LEN, pathname);
    emit_event(SC_UNLINK, 0, 0, path, MAX_ARG_LEN, 0);
    return 0;
}

char _license[] SEC("license") = "GPL";
