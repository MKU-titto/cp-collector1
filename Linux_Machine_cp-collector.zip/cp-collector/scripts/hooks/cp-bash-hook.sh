#!/bin/bash
# ============================================================================
# Cyber Polygon — Bash hook for shell-watcher
# Встановлюється в /etc/profile.d/cp-bash-hook.sh
#
# Використовує trap DEBUG (preexec) та PROMPT_COMMAND (precmd).
# Надсилає JSON через socat на UNIX socket shell-watcher.
# ============================================================================

# Шлях до socket shell-watcher
_CP_SOCKET="/home/iron/shell-watcher.sock"

# Прапорець щоб уникнути подвійного завантаження
[[ -n "$_CP_HOOK_LOADED" ]] && return
export _CP_HOOK_LOADED=1

# Не завантажуємо для non-interactive shells та для користувача iron
[[ "$-" != *i* ]] && return
[[ "$(whoami)" == "iron" ]] && return

# Перевіряємо наявність socat
if ! command -v socat &>/dev/null; then
    return
fi

# --------------------------------------------------------------------------
# Внутрішні змінні
# --------------------------------------------------------------------------
_CP_CMD_ID=""
_CP_CMD_START_NS=""
_CP_CMD_ACTIVE=0

# --------------------------------------------------------------------------
# __cp_send — надсилає JSON на UNIX socket
# --------------------------------------------------------------------------
__cp_send() {
    local json="$1"
    # Відправляємо асинхронно щоб не блокувати shell
    echo "$json" | socat - UNIX-CONNECT:"$_CP_SOCKET" 2>/dev/null &
    disown 2>/dev/null
}

# --------------------------------------------------------------------------
# __cp_preexec — викликається ПЕРЕД виконанням кожної команди
# Використовує trap DEBUG
# --------------------------------------------------------------------------
__cp_preexec() {
    # Уникаємо рекурсії — не логуємо PROMPT_COMMAND та внутрішні команди
    local cmd="$BASH_COMMAND"

    # Пропускаємо якщо це PROMPT_COMMAND або наша внутрішня функція
    [[ "$cmd" == "__cp_precmd" ]] && return
    [[ "$cmd" == __cp_* ]] && return
    [[ "$cmd" == _cp_* ]] && return
    [[ "$cmd" == "echo "* && "$cmd" == *"socat"* ]] && return

    # Пропускаємо якщо вже є активна команда (subshell, pipe тощо)
    [[ $_CP_CMD_ACTIVE -eq 1 ]] && return

    _CP_CMD_ACTIVE=1
    _CP_CMD_ID="${$}_$(date +%s%N)"
    _CP_CMD_START_NS=$(date +%s%N)

    # JSON для START
    local user
    user="$(whoami)"
    local pwd_escaped
    pwd_escaped=$(printf '%s' "$PWD" | sed 's/"/\\"/g')
    local cmd_escaped
    cmd_escaped=$(printf '%s' "$cmd" | sed 's/"/\\"/g' | head -c 4096)

    __cp_send "{\"action\":\"start\",\"cmd_id\":\"$_CP_CMD_ID\",\"command\":\"$cmd_escaped\",\"shell\":\"bash\",\"user\":\"$user\",\"pwd\":\"$pwd_escaped\"}"
}

# --------------------------------------------------------------------------
# __cp_precmd — викликається ПІСЛЯ виконання кожної команди
# Через PROMPT_COMMAND
# --------------------------------------------------------------------------
__cp_precmd() {
    local exit_code=$?

    # Якщо немає активної команди — нічого робити
    [[ $_CP_CMD_ACTIVE -eq 0 ]] && return

    _CP_CMD_ACTIVE=0

    # Рахуємо тривалість
    local duration_ms=0
    if [[ -n "$_CP_CMD_START_NS" ]]; then
        local now_ns
        now_ns=$(date +%s%N)
        duration_ms=$(( (now_ns - _CP_CMD_START_NS) / 1000000 ))
    fi

    __cp_send "{\"action\":\"end\",\"cmd_id\":\"$_CP_CMD_ID\",\"exit_code\":$exit_code,\"duration_ms\":$duration_ms}"

    _CP_CMD_ID=""
    _CP_CMD_START_NS=""
}

# --------------------------------------------------------------------------
# Встановлюємо hooks
# --------------------------------------------------------------------------

# DEBUG trap — preexec
trap '__cp_preexec' DEBUG

# PROMPT_COMMAND — precmd (додаємо до існуючого, не перезаписуємо)
if [[ -z "$PROMPT_COMMAND" ]]; then
    PROMPT_COMMAND="__cp_precmd"
elif [[ "$PROMPT_COMMAND" != *"__cp_precmd"* ]]; then
    PROMPT_COMMAND="__cp_precmd;$PROMPT_COMMAND"
fi
