#!/bin/zsh
# ============================================================================
# Cyber Polygon — Zsh hook for shell-watcher
# Встановлюється в /etc/zsh/zshrc.d/cp-zsh-hook.zsh
#
# Використовує zsh native preexec/precmd hooks.
# Надсилає JSON через socat на UNIX socket shell-watcher.
# ============================================================================

# Шлях до socket shell-watcher
_CP_SOCKET="/home/iron/shell-watcher.sock"

# Прапорець щоб уникнути подвійного завантаження
[[ -n "$_CP_HOOK_LOADED" ]] && return
export _CP_HOOK_LOADED=1

# Не завантажуємо для non-interactive shells та для користувача iron
[[ ! -o interactive ]] && return
[[ "$(whoami)" == "iron" ]] && return

# Перевіряємо наявність socat
if ! command -v socat &>/dev/null; then
    return
fi

# --------------------------------------------------------------------------
# Внутрішні змінні
# --------------------------------------------------------------------------
typeset -g _CP_CMD_ID=""
typeset -g _CP_CMD_START_NS=""

# --------------------------------------------------------------------------
# __cp_send — надсилає JSON на UNIX socket
# --------------------------------------------------------------------------
__cp_send() {
    local json="$1"
    { echo "$json" | socat - UNIX-CONNECT:"$_CP_SOCKET" } 2>/dev/null &!
}

# --------------------------------------------------------------------------
# preexec — викликається ПЕРЕД виконанням кожної команди
# Zsh передає команду як $1
# --------------------------------------------------------------------------
__cp_preexec() {
    local cmd="$1"

    # Пропускаємо внутрішні команди
    [[ "$cmd" == __cp_* ]] && return
    [[ "$cmd" == _cp_* ]] && return

    _CP_CMD_ID="${$}_$(date +%s%N)"
    _CP_CMD_START_NS=$(date +%s%N)

    # Escape JSON
    local user
    user="$(whoami)"
    local pwd_escaped="${PWD//\"/\\\"}"
    local cmd_escaped="${cmd//\"/\\\"}"
    # Обрізаємо довгі команди
    cmd_escaped="${cmd_escaped:0:4096}"

    __cp_send "{\"action\":\"start\",\"cmd_id\":\"$_CP_CMD_ID\",\"command\":\"$cmd_escaped\",\"shell\":\"zsh\",\"user\":\"$user\",\"pwd\":\"$pwd_escaped\"}"
}

# --------------------------------------------------------------------------
# precmd — викликається ПІСЛЯ виконання кожної команди
# --------------------------------------------------------------------------
__cp_precmd() {
    local exit_code=$?

    # Якщо не було preexec — нічого робити
    [[ -z "$_CP_CMD_ID" ]] && return

    # Рахуємо тривалість
    local duration_ms=0
    if [[ -n "$_CP_CMD_START_NS" ]]; then
        local now_ns
        now_ns=$(date +%s%N)
        duration_ms=$(( (now_ns - _CP_CMD_START_NS) / 1000000 ))
    fi

    __cp_send "{\"action\":\"end\",\"cmd_id\":\"$_CP_CMD_ID\",\"exit_code\":$exit_code,\"duration_ms\":$duration_ms}"

    _CP_CMD_ID=""
    _CP_CMD_START_NS=""
}

# --------------------------------------------------------------------------
# Реєструємо hooks через zsh hook system
# --------------------------------------------------------------------------
autoload -Uz add-zsh-hook
add-zsh-hook preexec __cp_preexec
add-zsh-hook precmd __cp_precmd
