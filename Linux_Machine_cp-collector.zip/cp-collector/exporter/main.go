// exporter — утиліта для збору та пакування логів усіх watchers після CTF.
//
// Створює архів:
//   /home/iron/exports/<machine_id>_<event_id>_<timestamp>.tar.gz
//
// Вміст архіву:
//   manifest.json          — метадані: machine_id, event_id, watchers, stats
//   logs/                  — всі .cplog.gz файли по папках watchers
//   files/                 — перехоплені файли (fs-monitor copies)
//
// Використання:
//
//	cp-exporter -config /home/iron/config/config.yaml
//	cp-exporter -config /home/iron/config/config.yaml -output /tmp/export.tar.gz
package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
)

const (
	toolName = "exporter"
	version  = "3.0.0"
)

func main() {
	configPath := flag.String("config", "/home/iron/config/config.yaml", "Path to config file")
	outputPath := flag.String("output", "", "Custom output path (default: auto-generated in exports dir)")
	showVersion := flag.Bool("version", false, "Show version and exit")
	flag.Parse()

	if *showVersion {
		fmt.Printf("cp-%s %s\n", toolName, version)
		os.Exit(0)
	}

	log := logger.New(toolName)
	log.Info("starting %s v%s", toolName, version)

	cfg, err := config.Load(*configPath)
	if err != nil {
		log.Error("load config: %v", err)
		os.Exit(1)
	}

	exporter := NewExporter(cfg, log)

	archivePath, err := exporter.Export(*outputPath)
	if err != nil {
		log.Error("export failed: %v", err)
		os.Exit(1)
	}

	// Розмір архіву
	stat, _ := os.Stat(archivePath)
	sizeMB := float64(0)
	if stat != nil {
		sizeMB = float64(stat.Size()) / 1024 / 1024
	}

	log.Info("export complete: %s (%.1f MB)", archivePath, sizeMB)
	fmt.Printf("\nExport complete: %s\n", archivePath)
}
