package main

import (
	"archive/tar"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/cyber-polygon/cp-collector/shared/config"
	"github.com/cyber-polygon/cp-collector/shared/logger"
)

// Exporter збирає логи всіх watchers та пакує в tar.gz.
type Exporter struct {
	cfg *config.Config
	log *logger.Logger
}

// NewExporter створює новий exporter.
func NewExporter(cfg *config.Config, log *logger.Logger) *Exporter {
	return &Exporter{
		cfg: cfg,
		log: log,
	}
}

// ============================================================================
// Manifest — метадані архіву
// ============================================================================

// Manifest — JSON-файл з метаданими експорту.
type Manifest struct {
	Version     string            `json:"version"`
	ExportedAt  string            `json:"exported_at"`
	Agent       ManifestAgent     `json:"agent"`
	Watchers    []ManifestWatcher `json:"watchers"`
	Files       ManifestFiles     `json:"files"`
	TotalEvents int64             `json:"total_events"`
	TotalSizeMB float64           `json:"total_size_mb"`
}

// ManifestAgent — інформація про агента.
type ManifestAgent struct {
	Type       string `json:"type"`
	Version    string `json:"version"`
	MachineID  string `json:"machine_id"`
	CTFEventID string `json:"ctf_event_id"`
}

// ManifestWatcher — статистика по одному watcher.
type ManifestWatcher struct {
	Name      string  `json:"name"`
	LogFiles  int     `json:"log_files"`
	SizeMB    float64 `json:"size_mb"`
	FileNames []string `json:"file_names"`
}

// ManifestFiles — статистика перехоплених файлів.
type ManifestFiles struct {
	Count  int     `json:"count"`
	SizeMB float64 `json:"size_mb"`
}

// ============================================================================
// Export
// ============================================================================

// knownWatchers — список watchers у порядку відображення.
var knownWatchers = []string{
	"shell-watcher",
	"interactive-watcher",
	"browser-watcher",
	"syscall-monitor",
	"proc-monitor",
	"net-sniffer",
	"fs-monitor",
	"auth-monitor",
	"service-monitor",
}

// Export створює tar.gz архів з логами та manifest.
// Якщо outputPath порожній — генерує автоматично.
func (e *Exporter) Export(outputPath string) (string, error) {
	logsDir := e.cfg.Storage.BasePath
	filesDir := e.cfg.Storage.FilesPath
	exportsDir := e.cfg.Export.OutputPath

	// Перевіряємо наявність логів
	if _, err := os.Stat(logsDir); os.IsNotExist(err) {
		return "", fmt.Errorf("logs directory not found: %s", logsDir)
	}

	// Створюємо exports dir якщо не існує
	if err := os.MkdirAll(exportsDir, 0700); err != nil {
		return "", fmt.Errorf("create exports dir: %w", err)
	}

	// Генеруємо шлях архіву
	if outputPath == "" {
		ts := time.Now().UTC().Format("20060102T150405Z")
		filename := fmt.Sprintf("%s_%s_%s.tar.gz",
			e.cfg.Agent.MachineID, e.cfg.Agent.CTFEventID, ts)
		outputPath = filepath.Join(exportsDir, filename)
	}

	e.log.Info("exporting to %s", outputPath)
	e.log.Info("scanning logs: %s", logsDir)
	e.log.Info("scanning files: %s", filesDir)

	// Збираємо статистику по watchers
	watcherStats := e.scanWatchers(logsDir)

	// Збираємо статистику перехоплених файлів
	fileStats := e.scanFiles(filesDir)

	// Підраховуємо загальну статистику
	var totalSize int64
	for _, ws := range watcherStats {
		totalSize += int64(ws.SizeMB * 1024 * 1024)
	}
	totalSize += int64(fileStats.SizeMB * 1024 * 1024)

	// Формуємо manifest
	manifest := Manifest{
		Version:    version,
		ExportedAt: time.Now().UTC().Format(time.RFC3339),
		Agent: ManifestAgent{
			Type:       e.cfg.Agent.Type,
			Version:    e.cfg.Agent.Version,
			MachineID:  e.cfg.Agent.MachineID,
			CTFEventID: e.cfg.Agent.CTFEventID,
		},
		Watchers:    watcherStats,
		Files:       fileStats,
		TotalSizeMB: float64(totalSize) / 1024 / 1024,
	}

	// Створюємо архів
	if err := e.createArchive(outputPath, logsDir, filesDir, manifest); err != nil {
		return "", fmt.Errorf("create archive: %w", err)
	}

	return outputPath, nil
}

// ============================================================================
// Сканування
// ============================================================================

// scanWatchers збирає статистику по кожному watcher.
func (e *Exporter) scanWatchers(logsDir string) []ManifestWatcher {
	var watchers []ManifestWatcher

	for _, name := range knownWatchers {
		watcherDir := filepath.Join(logsDir, name)
		if _, err := os.Stat(watcherDir); os.IsNotExist(err) {
			continue
		}

		ws := ManifestWatcher{Name: name}
		var totalSize int64

		entries, err := os.ReadDir(watcherDir)
		if err != nil {
			e.log.Warn("read %s: %v", watcherDir, err)
			continue
		}

		for _, entry := range entries {
			if entry.IsDir() {
				continue
			}
			info, err := entry.Info()
			if err != nil {
				continue
			}
			ws.LogFiles++
			ws.FileNames = append(ws.FileNames, entry.Name())
			totalSize += info.Size()
		}

		ws.SizeMB = float64(totalSize) / 1024 / 1024

		if ws.LogFiles > 0 {
			e.log.Info("watcher %s: %d files, %.1f MB", name, ws.LogFiles, ws.SizeMB)
			watchers = append(watchers, ws)
		}
	}

	return watchers
}

// scanFiles збирає статистику перехоплених файлів.
func (e *Exporter) scanFiles(filesDir string) ManifestFiles {
	stats := ManifestFiles{}

	if _, err := os.Stat(filesDir); os.IsNotExist(err) {
		return stats
	}

	var totalSize int64

	filepath.Walk(filesDir, func(path string, info os.FileInfo, err error) error {
		if err != nil || info.IsDir() {
			return nil
		}
		stats.Count++
		totalSize += info.Size()
		return nil
	})

	stats.SizeMB = float64(totalSize) / 1024 / 1024

	if stats.Count > 0 {
		e.log.Info("captured files: %d, %.1f MB", stats.Count, stats.SizeMB)
	}

	return stats
}

// ============================================================================
// Створення tar.gz архіву
// ============================================================================

// createArchive пакує logs, files та manifest у tar.gz.
func (e *Exporter) createArchive(outputPath, logsDir, filesDir string, manifest Manifest) error {
	outFile, err := os.Create(outputPath)
	if err != nil {
		return fmt.Errorf("create output file: %w", err)
	}
	defer outFile.Close()

	gzWriter := gzip.NewWriter(outFile)
	defer gzWriter.Close()

	tarWriter := tar.NewWriter(gzWriter)
	defer tarWriter.Close()

	// 1. manifest.json
	manifestJSON, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		return fmt.Errorf("marshal manifest: %w", err)
	}

	if err := e.addBytes(tarWriter, "manifest.json", manifestJSON); err != nil {
		return fmt.Errorf("add manifest: %w", err)
	}
	e.log.Info("added manifest.json")

	// 2. logs/ — всі .cplog.gz файли
	logCount := 0
	for _, ws := range manifest.Watchers {
		watcherDir := filepath.Join(logsDir, ws.Name)

		entries, err := os.ReadDir(watcherDir)
		if err != nil {
			continue
		}

		for _, entry := range entries {
			if entry.IsDir() {
				continue
			}
			srcPath := filepath.Join(watcherDir, entry.Name())
			archivePath := filepath.Join("logs", ws.Name, entry.Name())

			if err := e.addFile(tarWriter, archivePath, srcPath); err != nil {
				e.log.Warn("add %s: %v", srcPath, err)
				continue
			}
			logCount++
		}
	}
	e.log.Info("added %d log files", logCount)

	// 3. files/ — перехоплені файли
	fileCount := 0
	if _, err := os.Stat(filesDir); err == nil {
		filepath.Walk(filesDir, func(path string, info os.FileInfo, err error) error {
			if err != nil || info.IsDir() {
				return nil
			}

			// Відносний шлях від filesDir
			relPath, _ := filepath.Rel(filesDir, path)
			archivePath := filepath.Join("files", relPath)

			if err := e.addFile(tarWriter, archivePath, path); err != nil {
				e.log.Warn("add file %s: %v", path, err)
				return nil
			}
			fileCount++
			return nil
		})
	}

	if fileCount > 0 {
		e.log.Info("added %d captured files", fileCount)
	}

	// 4. checksum.sha256 — SHA256 хеші всіх файлів в архіві
	// (буде обчислений окремо після створення архіву)

	return nil
}

// addFile додає файл з диску до tar архіву.
func (e *Exporter) addFile(tw *tar.Writer, archivePath, srcPath string) error {
	file, err := os.Open(srcPath)
	if err != nil {
		return err
	}
	defer file.Close()

	stat, err := file.Stat()
	if err != nil {
		return err
	}

	header := &tar.Header{
		Name:    archivePath,
		Size:    stat.Size(),
		Mode:    0600,
		ModTime: stat.ModTime(),
	}

	if err := tw.WriteHeader(header); err != nil {
		return err
	}

	_, err = io.Copy(tw, file)
	return err
}

// addBytes додає дані як файл до tar архіву.
func (e *Exporter) addBytes(tw *tar.Writer, name string, data []byte) error {
	header := &tar.Header{
		Name:    name,
		Size:    int64(len(data)),
		Mode:    0600,
		ModTime: time.Now(),
	}

	if err := tw.WriteHeader(header); err != nil {
		return err
	}

	_, err := tw.Write(data)
	return err
}

// ============================================================================
// Утиліти
// ============================================================================

// hashFile обчислює SHA256 файлу.
func hashFile(path string) string {
	f, err := os.Open(path)
	if err != nil {
		return ""
	}
	defer f.Close()

	h := sha256.New()
	if _, err := io.Copy(h, f); err != nil {
		return ""
	}

	return hex.EncodeToString(h.Sum(nil))
}

// humanSize форматує розмір у зручному вигляді.
func humanSize(bytes int64) string {
	if bytes < 1024 {
		return fmt.Sprintf("%d B", bytes)
	}
	if bytes < 1024*1024 {
		return fmt.Sprintf("%.1f KB", float64(bytes)/1024)
	}
	if bytes < 1024*1024*1024 {
		return fmt.Sprintf("%.1f MB", float64(bytes)/1024/1024)
	}
	return fmt.Sprintf("%.1f GB", float64(bytes)/1024/1024/1024)
}

// stripPrefix видаляє prefix і зайвий слеш.
func stripPrefix(path, prefix string) string {
	rel := strings.TrimPrefix(path, prefix)
	return strings.TrimPrefix(rel, "/")
}
