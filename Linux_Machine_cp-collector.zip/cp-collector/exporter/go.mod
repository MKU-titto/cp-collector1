module github.com/cyber-polygon/cp-collector/exporter

go 1.22

require (
	github.com/cyber-polygon/cp-collector/shared v0.0.0
	gopkg.in/yaml.v3 v3.0.1
)

// Локальна залежність на shared packages
replace github.com/cyber-polygon/cp-collector/shared => ../shared
