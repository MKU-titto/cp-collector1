# Cyber Polygon — Linux_Machine v3

Behavioral data collection system for CTF (Capture The Flag) competitions. Installs on target Linux machines and silently records all participant actions — terminal commands, network traffic, file changes, authentication events — to train an AI agent capable of autonomously solving CTF scenarios.

## How it works

The system consists of **9 independent watcher services**, each running as a separate systemd unit. Every watcher monitors a specific data source and writes structured events (JSONL + gzip) to `/home/iron/logs/`. After the CTF, the **exporter** utility packages all collected data into a single `.tar.gz` archive with a `manifest.json`.

All services run as root (required for eBPF, libpcap, /proc access) but store data under a locked-down `/home/iron/` directory inaccessible to CTF participants.

## Services

| Service | Source | What it captures |
|---------|--------|-----------------|
| `cp-shell-watcher` | bash/zsh preexec hooks → UNIX socket | Terminal commands with exit code and duration |
| `cp-interactive-watcher` | eBPF tracepoints (sys_read/sys_write) | Stdin input + stdout response of REPL tools (msfconsole, gdb, python3, mysql, etc.) |
| `cp-browser-watcher` | mitmproxy transparent proxy | HTTP/HTTPS requests with URL, status, body preview |
| `cp-syscall-monitor` | eBPF tracepoints | Critical syscalls: connect, execve, ptrace, mmap, openat, rename, unlink |
| `cp-proc-monitor` | /proc polling | New processes with CTF tool classification (150+ tools, 12 categories) and anomaly detection (webshell spawn, reverse shell, suspicious binaries) |
| `cp-net-sniffer` | libpcap | TCP/UDP connections (inbound + outbound), HTTP parsing, DNS queries, port scan detection |
| `cp-fs-monitor` | inotify (fsnotify) | File changes categorized as upload, config_change, log_deletion, or system_change; SHA256 hashing; optional file copy |
| `cp-auth-monitor` | tail /var/log/auth.log | SSH login/fail, sudo, su, useradd, passwd, groupadd |
| `cp-service-monitor` | systemctl + crontab + dpkg.log | Systemd unit state changes, crontab modifications, package install/remove/upgrade |

Additionally, `cp-exporter` packages all logs and captured files into a single archive for post-CTF analysis.

## Project structure

```
cp-collector/
├── install.sh              # One-command installer
├── shared/                 # Shared Go packages (types, config, storage, logger)
├── watchers/
│   ├── auth-monitor/       # Each watcher: go.mod, main.go, watcher.go, .service
│   ├── fs-monitor/
│   ├── service-monitor/
│   ├── proc-monitor/       # + tools.go (150+ CTF tool classifications)
│   ├── shell-watcher/
│   ├── net-sniffer/        # + http.go, dns.go, scanner.go
│   ├── interactive-watcher/# + correlator.go, ebpf/interactive.c, Makefile
│   ├── syscall-monitor/    # + ebpf/syscall.c, Makefile
│   └── browser-watcher/    # + addon/cp_proxy.py
├── exporter/               # Post-CTF data export utility
├── scripts/hooks/          # Bash/Zsh preexec hooks for shell-watcher
└── configs/                # YAML config template
```

## Installation

**Requirements:** Debian/Ubuntu Linux, root access, internet connection.

**1. Copy the project to the target machine:**

```bash
scp -r cp-collector/ root@TARGET_IP:/opt/
```

**2. Run the installer:**

```bash
cd /opt/cp-collector
sudo bash install.sh --event-id <EVENT_ID>
```

The script will create user `iron`, install all dependencies (Go, clang, llvm, libbpf, libpcap, socat, mitmproxy), compile all modules, deploy binaries to `/home/iron/bin/`, register systemd services, and start everything.

**Options:**

```bash
--event-id <id>      # (required) CTF event identifier
--interface <name>   # Network interface, default: eth0
--skip-browser       # Skip browser-watcher (no mitmproxy)
```

**3. Verify:**

```bash
systemctl list-units 'cp-*' --type=service
```

## Post-CTF data export

```bash
/home/iron/bin/cp-exporter -config /home/iron/config/config.yaml
```

The archive will be saved to `/home/iron/exports/` and contains `manifest.json`, all log files, and captured file copies.

## Useful commands

```bash
systemctl status cp-auth-monitor       # Check one service
journalctl -u cp-net-sniffer -f        # Live logs
systemctl stop cp-*.service            # Stop all services
systemctl restart cp-shell-watcher     # Restart one service
```

## License

Proprietary — Cyber Polygon project.
